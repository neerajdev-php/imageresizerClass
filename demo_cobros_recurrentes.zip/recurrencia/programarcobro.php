<?php
require_once('config.php');
require_once('lib/Pagadito_php_1.6.php');
ini_set("display_errors", true);

//Se inicializa el objeto Pagadito
$Pagadito = new Pagadito(UID, WSK);

//Verificando modo sandbox
if(SANDBOX) $Pagadito->mode_sandbox_on ();

//Se establece una conexi�n con Pagadito
if($Pagadito->connect()){
    
    /*
     * Definir este valor con el TOKEN DE AUTORIZACI�N
     * Este es el valor capturado en el primer pago
     * Valor que representa la cuenta Pagadito a la que se programar� el cobro.
     */
    $oauth_token = "CAMBIAR_ESTE_VALOR";
    
    //Detalles del pago
    $ern        = "987654321";
    $Pagadito->add_detail(1, "Mensualidad", 100);
    
    //Debe definirse la fecha de cobro
    $Pagadito->add_pending_charge($ern, "Pago por paquete premium", "2015-07-07");
    
    //Se env�a la petici�n de cobro programado
    if($Pagadito->recurring_payments($oauth_token))
    {
        /**
         * Se obtiene un array con la informaci�n del cobro incluyendo el
         * token del cobro
         */
        $cobro          = $Pagadito->get_rs_pending_charges();
        /**
         * Este es el valor que representa al cobro programado y el cual se
         * utilizar� para consultar su estdo.
         * GUARDAR ESTE VALOR.
         */
        $token_pending  = $cobro[0]->token_pending;
        $estado         = $cobro[0]->status;
        
        echo "Token de cobro programado: ".$token_pending."<br />";
        echo "Estado: ".$estado."<br />";
    }
}
else
{
    echo $Pagadito->get_rs_code().": ".$Pagadito->get_rs_message();
}