<?php
require_once('config.php');
require_once('lib/Pagadito_php_1.6.php');
ini_set("display_errors", true);

//Definir valor con TOKEN DE COBRO PROGRAMADO
$token_pending = "CAMBIAR_ESTE_VALOR";
$Pagadito = new Pagadito(UID, WSK);

//Verificando modo sandbox
if(SANDBOX) $Pagadito->mode_sandbox_on ();

//Se establece una conexi�n con Pagadito
if($Pagadito->connect())
{
    
    //Se consulta la informaci�n del cobro programado
    if($Pagadito->get_pending_status($token_pending))
    {
        
        //Se obtiene el estado del cobro
        $estado = $Pagadito->get_rs_status();
        echo "Estado: ".$estado;
        
        //si el cobro ha sido efectuado, se obtiene el n�mero de aprobaci�n PG
        //y se obtiene la fecha de cobro
        if($estado == "COMPLETED")
        {
            /**
             * Esta es la referencia de Pago de Pagadito.
             * GUARDAR ESTE VALOR
             */
            $numero_aprobacion_pg   = $Pagadito->get_rs_reference();
            $fecha_cobro            = $Pagadito->get_rs_date_trans();
            
            echo "N&uacute;mero de aprobaci&oacute; PG: ".$numero_aprobacion_pg."<br />";
            echo "Fecha: ".$fecha_cobro."<br />";
        }
    }
}
else
{
    echo $Pagadito->get_rs_code().": ".$Pagadito->get_rs_message();
}