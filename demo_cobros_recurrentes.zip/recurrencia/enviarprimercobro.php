<?php
require_once('config.php');
require_once('lib/Pagadito_php_1.6.php');
ini_set("display_errors", true);

//Se inicializa el objeto Pagadito
$Pagadito = new Pagadito(UID, WSK);

//Verificando modo sandbox
if(SANDBOX) $Pagadito->mode_sandbox_on ();

//Se establece una conexi�n con Pagadito
if($Pagadito->connect()){
    
    //detalles del pago inicial
    $ern        = "123456789"; //este debe un identificador de la transacci�n
    $Pagadito->add_detail(1, "Inscripci&oacute;n", 25);
    $Pagadito->add_detail(1, "Mensualidad", 100);
    
    //Debe enviarse el cobro con fecha de hoy
    $Pagadito->add_pending_charge($ern, "Pago por paquete premium", date("Y-m-d"));
    
    //Habilitar cobros a usuarios sin Cuenta Pagadito
    $Pagadito->enable_pending_payments();
    
    /**
     * Se env�a la petici�n de cobro y de autorizaci�n para cargos autom�ticos
     * Si los datos son correctos se redireccionar� autom�ticamente.
     * En este ejemplo se env�a el segundo par�metro en false para obtener
     * la url y hacer la redirecci�n de forma controlada.
     */
    $url_pago = $Pagadito->authorization_recurring_payments("automatic_charges,initial_payment", false);
    if($url_pago)
    {
        header("location: $url_pago");
        exit();
    }
    else
    {
        echo $Pagadito->get_rs_code().": ".$Pagadito->get_rs_message();
    }
}
else
{
    echo $Pagadito->get_rs_code().": ".$Pagadito->get_rs_message();
}

?>