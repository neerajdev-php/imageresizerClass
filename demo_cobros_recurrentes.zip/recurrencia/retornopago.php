<?php
require_once('config.php');
require_once('lib/Pagadito_php_1.6.php');
ini_set("display_errors", true);

//Se inicializa el objeto Pagadito
$Pagadito = new Pagadito(UID, WSK);

//Verificando modo sandbox
if(SANDBOX) $Pagadito->mode_sandbox_on ();

//Se establece una conexi�n con Pagadito
if($Pagadito->connect())
{
    //Se consulta el token de autorizaci�n
    if($Pagadito->get_oauth_recurring_payments_token($_GET["token"]))
    {
        /*
         * Este valor representa la cuenta pagadito a la que se le hizo el
         * cobro. Tambi�n es el valor con el que se pueden enviar nuevos
         * cobros. GUARDAR ESTE VALOR
         */
        $oauth_token    = $Pagadito->get_rs_oauth_token();
        echo "Token de autorizaci&oacute;n: ".$oauth_token."<br />";

        /*
         * Se obtiene un array con la informaci�n del cobro incluyendo el
         * token del cobro
         */
        $cobro          = $Pagadito->get_rs_pending_charges();
        $token_pending  = $cobro[0]->token_pending;

        //creando una nueva conexi�n para consultar la referencia de pago
        if($Pagadito->connect(UID, WSK))
        {

            //se consulta la informaci�n del pago
            if($Pagadito->get_pending_status($token_pending))
            {
                $estado = $Pagadito->get_rs_status();
                echo "Estado: ".$estado."<br />";
                
                /*
                 * si el cobro ha sido efectuado, se obtiene el n�mero de
                 * aprobaci�n PG la fecha de cobro
                 */
                if($estado == "COMPLETED")
                {
                    /**
                     * Esta es la referencia de Pago de Pagadito.
                     * GUARDAR ESTE VALOR
                     */
                    $numero_aprobacion_pg   = $Pagadito->get_rs_reference();
                    $fecha_cobro            = $Pagadito->get_rs_date_trans();

                    echo "N&uacute;mero de aprobaci&oacute;n PG: ".$numero_aprobacion_pg."<br />";
                    echo "Fecha: ".$fecha_cobro."<br />";
                }
            }
        }
    }
}
else
{
    echo $Pagadito->get_rs_code().": ".$Pagadito->get_rs_message();
}