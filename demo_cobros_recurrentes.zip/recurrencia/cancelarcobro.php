<?php
require_once('config.php');
require_once('lib/Pagadito_php_1.6.php');
ini_set("display_errors", true);

/**
 * Definir valor con TOKEN DE COBRO PROGRAMADO
 * Puenden enviarse a cancelar m�ltiples cobros programados.
 */
$token_pending = array("CAMBIAR_ESTE_VALOR");
$Pagadito = new Pagadito(UID, WSK);

//Verificando modo sandbox
if(SANDBOX) $Pagadito->mode_sandbox_on ();

//Se establece una conexi�n con Pagadito
if($Pagadito->connect())
{
    
    //Se env�a la cancelaci�n del pago programado.
    if($Pagadito->cancel_pending($token_pending))
    {
        echo $Pagadito->get_rs_value()." transacciones canceladas.";
    }
}
else
{
    echo $Pagadito->get_rs_code().": ".$Pagadito->get_rs_message();
}