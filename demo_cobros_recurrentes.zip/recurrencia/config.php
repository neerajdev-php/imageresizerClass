<?php
/**
 * Es un ejemplo de autorizaci�n y env�o de cobros recurrentes a trav�s de la
 * APIPG.
 *
 * config.php
 *
 * Este script es para definir las constantes a usarse en los dem�s scripts.
 * Estas constantes son utilizadas para la comunicaci�n con el WSPG.
 *
 * LICENCIA: �ste c�digo fuente es de uso libre. Su comercializaci�n no est�
 * permitida. Toda publicaci�n o menci�n del mismo, debe ser referenciada a
 * su autor original Pagadito.com.
 *
 * @author      Pagadito.com <soporte@pagadito.com>
 * @copyright   Copyright (c) 2011, Pagadito.com
 * @version     1.0
 * @link        https://dev.pagadito.com/index.php?mod=docs&hac=apipg#php
 */

/**
 * UID es la clave que identifica al Pagadito Comercio en Pagadito
 * WSK es la clave de acceso para conectarse con Pagadito
 *
 * Las 2 constantes est�n definidas para comunicarse con la plataforma SandBox.
 * Al momento de pasar a producci�n, estas deben ser sustituidas por sus
 * equivalentes para conectarse con Pagadito.
 */

define("SANDBOX", TRUE);
if(SANDBOX){
    define("UID", "CAMBIAR_VALOR");
    define("WSK", "CAMBIAR_VALOR");
}
else{
    define("UID", "CAMBIAR_VALOR");
    define("WSK", "CAMBIAR_VALOR");
}

?>
