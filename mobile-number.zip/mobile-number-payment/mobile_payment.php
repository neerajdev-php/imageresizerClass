<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
Plugin Name: WooCommerce Mobile number Gateway
Version:3.0
Author:Rahul Gupta
Plugin URI:notosolutions.com
Description: Mobile number plugin for WooCommerce
*/

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
   add_action( 'plugins_loaded', 'init_mobile_pay_class');
}

function init_mobile_pay_class() {

load_plugin_textdomain('wc-mobile', false, dirname( plugin_basename( __FILE__ ) ) . '/languages');

    /**
	 * Mobile Number Payment Gateway
	 *
	 * Provides a Mobile Payment Gateway.
	 *
	 * @class 		WC_Gateway_mobile
	 * @extends		WC_Gateway_mobile
	 * @version		1.1
	 * @package		WooCommerce/Classes/Payment
	 * @author 		WooThemes
	 */

   class WC_Gateway_Mobile extends WC_Payment_Gateway {
    
            
              public function __construct() {
			$this->id					= 'mobile';
			$this->icon         		= $this->get_plugin_url() . '/assets/images/mobile.png';
			$this->has_fields			= false;
			$this->order_button_text	= __( 'Proceed to Mobile', 'woocommerce' );
			$this->method_title			= __( 'Mobile', 'woocommerce' );
			$this->method_description	= __( 'Mobile works by sending the user to  payment page to enter their payment information.', 'woocommerce' );
			$this->notify_url   		= str_replace( 'https:', 'http:', add_query_arg( 'wc-api', 'WC_Gateway_Smoovpay', home_url( '/' ) ) );
			$this->supports 			= array('products');

			// Load settings
			$this->init_form_fields();
			$this->init_settings();

			// Define user set variables
			$this->title					= $this->get_option( 'title' );
			$this->description				= $this->get_option( 'description' );
			$this->email					= $this->get_option( 'email' );
			$this->receiver_email			        = $this->get_option( 'receiver_email', $this->email );
			$this->debug					= $this->get_option( 'debug' );
			$this->form_submission_method	                = $this->get_option( 'form_submission_method' ) == 'yes' ? true : false;
			$this->page_style				= $this->get_option( 'page_style' );
			

			if ( 'yes' == $this->debug ) {
				$this->log = new WC_Logger();
                $this->log->add( 'mobile', 'Log Test');
			}

			// Actions
			
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

		}
                
                /**
		 * Check if this gateway is enabled and available in the user's country
		 *
		 * @access public
		 * @return bool
		 */
		function is_valid_for_use() {
			if ( ! in_array( get_woocommerce_currency(), apply_filters( 'woocommerce_mobile_supported_currencies', array( 'SGD', 'USD' ) ) ) ) {
				return false;
			}
			return true;
		}

		/**
		 * Admin Panel Options
		 *
		 */
		public function admin_options() {
			if ( $this->is_valid_for_use() ) {
				parent::admin_options();
			} else {
				?>
				<div class="inline error"><p><strong><?php _e( 'Gateway Disabled', 'woocommerce' ); ?></strong>: <?php _e( 'mobile does not support your store currency.', 'woocommerce' ); ?></p></div>
				<?php
			}
		}
                
                
                /**
		 * Initialize Gateway Settings Form Fields
		 *
		 * @access public
		 * @return void
		 */
		public function init_form_fields() {
                 $this->form_fields = include( 'includes/setting-mobile.php' );
		}
                
                public function payment_fields(){
			
		?>
        <table>
        	<tr>
            	<td><label class="" for="mobile_payment_number"><?php echo __( 'Mobile Number', 'woocommerce') ?></label></td>
                <td><input type="text" name="mobile_payment_number" class="input-text" placeholder="Phone Number Eg.(+242023456110)"  style="width: 250px; height: 30px;"/></td>
            </tr>
            
           
           
        </table>
		<?php
	  }
          
          
         
          /**
		 * Process the payment and return the result
		 *
		 * @access public
		 * @param int $order_id
		 * @return array
		 */
	  
	   public function process_payment( $order_id ){
		global $woocommerce,$wpdb;
		$wc_order = new WC_Order( $order_id );
                
                 $grand_total = $wc_order->order_total;
		 $amount = (int)$grand_total;
		 
		  global $wpdb, $current_user;
		 
		 $user_ID     = get_current_user_id();
		 
		 $user_mobile = get_user_meta( $user_ID, 'billing_phone',true);
                 
                 $mobile_no   = $_POST['mobile_payment_number'];
		 
		 $user_email  = $current_user->user_email;
		 
		 $user_name    = $current_user->first_name;
		 
		 $admin_email = get_option( 'admin_email' );
                 
		 if($mobile_no !='')
                 {
			if (isset($mobile_no) && !preg_match('/^\+?([242]{1,3})\)?[-. ]?(0[0-9]{8})$/', $mobile_no))
		        {
		    
		          $woocommerce->add_error(__( '<strong>Error</strong>: Plese Enter Phone Number Starting with Country code +242 and after this 9 more digit starting with 0.', 'woocommerce' ) );
		    
		        }else{
				
				if($mobile_no == $user_mobile)
				{
					
					// Always set content-type when sending HTML email
				 $to        = $user_email;
				 $subject   = 'Payment Pending';
				 $message   = '<meta charset="utf-8" />
<title></title>
<table border="0" width="100%">
	<tbody>
		<tr>
			<td>
			<table align="center" border="0" cellpadding="0" cellspacing="0" style="background:#fff; box-shadow:0 0 10px #ccc;" width="600">
				<tbody>
					<tr>
						<td align="center" style="border-top: 6px solid #566369; border-bottom:solid 1px #f5f5f5;" valign="middle"></td>
					</tr>
					<tr>
						<td>
						<table cellpadding="0" cellspacing="0" width="100%">
							<tbody>
								<tr>
									<td width="15">&nbsp;</td>
									<td width="570">
									<table cellpadding="0" cellspacing="0" width="100%">
										<tbody>
											<tr>
												<td height="15">&nbsp;</td>
											</tr>
											<tr>
												<td width="530">
												<table cellpadding="0" cellspacing="0" width="100%">
													<tbody>
														<tr>
															<td style="font-family:Arial, Helvetica, sans-serif; padding:10px; font-size:13px; color:#ec7475;">
															<table border="0" cellpadding="0" cellspacing="0" width="100%">
																<tbody>
																	<tr>
																		<td align="left" height="30" style="font-size:18px; font-family:Verdana, Geneva, sans-serif; color:#1f7cae; padding-bottom:22px;" valign="middle"><strong>Dear '.$user_name.',</strong></td>
																	</tr>
																	<tr>
																		<td align="left" style="color: #fff;background-color:#1f7cae; border-bottom:solid 1px #8dbfd9;font-size: 17px;height: 40px;line-height: 27px;text-align: center;margin-bottom:22px;" valign="middle">Your payment is pending.Admin will contact you soon</td>
																	</tr>
																	<tr><td>&nbsp;</td></tr>
																	
																	
																	<tr>
																		<td align="left" style="font-family:Arial, Helvetica, sans-serif; font-size:17px;color:#1f7cae;" valign="top">Regards,<br />
																		Photo Printing</td>
																	</tr>
																</tbody>
															</table>
															</td>
														</tr>
													</tbody>
												</table>
												</td>
											</tr>
											<tr>
												<td height="15" style="padding-bottom:15px;">
												<p>*This email account is not monitored. Please do not reply to this email as we will not be able to read and respond to your messages.</p>
												</td>
											</tr>
										</tbody>
									</table>
									</td>
									<td width="15">&nbsp;</td>
								</tr>
							</tbody>
						</table>
						</td>
					</tr>
					<tr>
						<td align="center" style="padding:5px; background: none repeat scroll 0 0 #333;
    border-top: 1px solid #CCCCCC;color:#fff;" valign="top">
						<p>You have received this message by auto generated e-mail.</p></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>';
				 $headers   = "MIME-Version: 1.0" . "\r\n";
				 $headers  .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				
				// More headers
				$headers = 'From: Photo Printing'.$admin_email."\r\n";
				mail($to,$subject,$message,$headers);
					
					$wc_order->add_order_note( __( 'Mobile Payment Pandding. ' , 'woocommerce' ) );
					$wc_order->payment_complete();
					return array (
					  'result'   => 'success',
					  'redirect' => $this->get_return_url( $wc_order ),
					);
				
				    
				}else{
					
					$woocommerce->add_error( __( 'Your mobile number does not match your registered number.', 'woocommerce' ) );
					
					
				}
                        }
                 }else{
                    
                   $woocommerce->add_error( __( 'Please fill mobile number', 'woocommerce' ) );
                    
                 }
		
                 
                
          }
                /**
		 * Get the plugin url
		 * 
		 * @return string
		 */
		private function get_plugin_url() {			

			if( isset( $this->plugin_url ) )
				return $this->plugin_url;

			if ( is_ssl() ) {
				return $this->plugin_url = str_replace( 'http://', 'https://', WP_PLUGIN_URL ) . "/" . dirname( plugin_basename(__FILE__) );
			} else {
				return $this->plugin_url = WP_PLUGIN_URL . "/" . dirname( plugin_basename(__FILE__) );
			}
		}
                
    }
    
    /**
	* Add the Gateway to WooCommerce
	**/
	function woocommerce_add_mobile_gateway($methods) {
		$methods[] = 'WC_Gateway_Mobile';
		return $methods;
	}
	
	add_filter('woocommerce_payment_gateways', 'woocommerce_add_mobile_gateway' );
}
?>