<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings for SmoovPay Gateway
 */
return array(
    'enabled' => array(
        'title' => __( 'Enable/Disable', 'woocommerce' ),
        'label' => __( 'Enable Mobile', 'woocommerce' ),
        'type' => 'checkbox',
        'desc_tip'    => true,
        'description' => __( 'This controls whether or not this gateway is enabled within WooCommerce.', 'woocommerce' ),
        'default' => 'yes'
    ),
    'title' => array(
        'title' => __( 'Title', 'woocommerce' ),
        'type' => 'text',
        'desc_tip'    => true,
        'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce' ),
        'default' => __( 'Mobile', 'woocommerce' )
    ),
    'description' => array(
        'title' => __( 'Description', 'woocommerce' ),
        'type' => 'text',
        'desc_tip'    => true,
        'description' => __( 'This controls the description which the user sees during checkout.', 'woocommerce' ),
        'default' => __( 'Pay via mobile you can pay with your mobile number if you don?t have a any accout.', 'woocommerce' )
    ),
    'debug' => array(
        'title' => __( 'Debug Log', 'woocommerce' ),
        'type' => 'checkbox',
        'description' => __( 'Enable logging', 'woocommerce' ),
        'default' => get_option( 'debug' )
    ),
    'debug_email' => array(
        'title' => __( 'Who Receives Debug E-mails?', 'woocommerce' ),
        'type' => 'text',
        'desc_tip'    => true,
        'description' => __( 'The e-mail address to which debugging error e-mails are sent when in test mode.', 'woocommerce' ),
        'default' => get_option( 'admin_email' )
    )
);