<?php

if ( ! defined( 'ABSPATH' ) ) {
  exit;
}


/**
 *  Add seller menu items in my account menu
 *  @param menu items array
 *  @return menu item array with seller options if seller
 */

function mp_seller_menu_items_my_account( $items ) {
  global $wpdb;

  $user_id = get_current_user_id();

  $new_items = array();

  $shop_address = get_user_meta( $user_id, 'shop_address', true );

  $page_name = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name ='".get_option('wkmp_seller_page_title')."'");

  $seller_info = $wpdb->get_var("SELECT user_id FROM {$wpdb->prefix}mpsellerinfo WHERE user_id = '" . $user_id . "' and seller_value='seller'");

  if ( $seller_info > 0 ) {
    $new_items['../' . $page_name . '/dashboard'] = __( 'Marketplace', 'marketplace' );
    $new_items['../' . $page_name . '/product-list'] = __( 'Products', 'marketplace' );
    $new_items['../' . $page_name . '/order-history'] = __( 'Order History', 'marketplace' );
    $new_items['../' . $page_name . '/transaction'] = __( 'Transaction', 'marketplace' );
    $new_items['../' . $page_name . '/' . $shop_address . '/shipping'] = __( 'Shipping', 'marketplace' );
    $new_items['../' . $page_name . '/profile/edit'] = __( 'Seller Profile', 'marketplace' );
    $new_items['../' . $page_name . '/notification'] = __( 'Notification', 'marketplace' );
    $new_items['../' . $page_name . '/shop-follower'] = __( 'Shop Followers', 'marketplace' );
    $new_items = apply_filters('mp_woocommerce_account_menu_options', $new_items);
    $new_items['../' . $page_name . '/to'] = __( 'Ask To Admin', 'marketplace' );
  }

  $new_items += $items;

  return $new_items;
}

/**
 *  My account menu for seller pages
 */
function mp_return_wc_account_menu() {
  ?>
  <nav class="woocommerce-MyAccount-navigation">
  	<ul>
  		<?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
  			<li class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?>">
  				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>"><?php echo esc_html( $label ); ?></a>
  			</li>
  		<?php endforeach; ?>
  	</ul>
  </nav>
  <?php
}

/**
 *  account menu shpping style
 */
function mp_shipping_icon_style() {
  global $wpdb;

  $user_id = get_current_user_id();

  $shop_address = get_user_meta( $user_id, 'shop_address', true );

  $page_name = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name ='".get_option('wkmp_seller_page_title')."'");

  $seller_info = $wpdb->get_var("SELECT user_id FROM {$wpdb->prefix}mpsellerinfo WHERE user_id = '" . $user_id . "' and seller_value='seller'");

  if ( $seller_info > 0 ) {
    ?>
    <style type="text/css" media="screen">
    .woocommerce-MyAccount-navigation ul li.woocommerce-MyAccount-navigation-link--<?php echo $page_name.$shop_address; ?>shipping a:before {
      content: "\f0d1";
      font-family: fontawesome;
    }
    </style>
    <?php
  }

}

/**
 *  Add active class to current menu for seller pages
 *  @param classes and endpoints
 *  @return classes
 */
function mp_add_menu_active_class( $classes, $endpoint ) {
  global $wpdb, $wp;

  $page_name = $wpdb->get_var( "SELECT post_name FROM $wpdb->posts WHERE post_name ='" . get_option('wkmp_seller_page_title' ) . "'" );

  if ( is_page( $page_name ) ) {

    $actual_link = ( isset( $_SERVER['HTTPS'] ) ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    $current = str_replace( home_url() . '/', '', $actual_link );

    $endpoint = str_replace( '../', '', $endpoint );

    if ( strpos( untrailingslashit( $current ), $endpoint ) !== false || ( ( get_query_var( 'main_page' ) == 'product' || get_query_var( 'main_page' ) == 'add-product' ) && strpos( $endpoint, 'product-list' ) !== false ) ) {
      $classes[] = 'is-active';
      $count = 0;
    }

    if ( 'dashboard' === $endpoint && ( $key = array_search( 'is-active', $classes ) ) !== false ) {
      unset( $classes[$key] );
    }
  }
  return $classes;
}
