<?php

// view order

global $wpdb;

$order = '';

$order_id = get_query_var('order_id');

$user_id = get_current_user_id();

if ( isset( $_POST['mp-submit-status'] ) ) {
	mp_order_update_status( $_POST );
}

try {
	$order = new WC_Order( $order_id );

	$order_detail_by_order_id = array();

	$get_item = $order->get_items();

	$cur_symbol = get_woocommerce_currency_symbol( $order->get_currency() );

	$order_detail_by_order_id = array();

	foreach ( $get_item as $key => $value ) {
		$product_id = $value->get_product_id();
		$variable_id = $value->get_variation_id();
		$product_total_price = $value->get_data()['total'];
		$qty = $value->get_data()['quantity'];
		$post = get_post( $product_id );

		if( $post->post_author == $user_id ) {
			$order_detail_by_order_id[$product_id][] = array( 'product_name' => $value['name'], 'qty'=>$qty, 'variable_id' => $variable_id, 'product_total_price' => $product_total_price );
		}
	}

	$shipping_method = $order->get_shipping_method();

	$payment_method = $order->get_payment_method_title();

	$total_payment = 0;

	?> <div class="woocommerce-account"> <?php

	apply_filters( 'mp_get_wc_account_menu', 'marketplace' );

	if( ! empty( $order_detail_by_order_id ) ) :

		?>

		<div class="woocommerce-MyAccount-content mp-order-view">

			<div id="order_data_details">

				<a href="<?php echo site_url().'/seller/invoice/'.base64_encode($order_id); ?>" target="_blank" class="button print-invoice"><?php echo __( 'Print Invoice', 'marketplace' ); ?></a>

				<h3><?php echo __('Order', 'marketplace').' #'.$order_id; ?></h3>

				<div class="wkmp_order_data_detail">
					<table>
						<thead>
							<tr>
								<th class="product-name"><?php echo _e("Product", "marketplace"); ?></th>
								<th class="product-total"><?php echo _e("Total", "marketplace"); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php
							foreach ($order_detail_by_order_id as $product_id => $details) {
								for ($i=0; $i < count($details); $i++) {
									$total_payment=floatval($total_payment) + floatval($details[$i]['product_total_price']) + floatval($order->get_total_shipping());
									if($details[$i]['variable_id']==0){
										?>
										<tr class="order_item alt-table-row">
											<td class="product-name">
												<a href=""><?php echo $details[$i]['product_name']; ?></a>
												<strong class="product-quantity">× <?php echo $details[$i]['qty']; ?></strong>
											</td>
											<td class="product-total">
												<?php echo $cur_symbol.$details[$i]['product_total_price']; ?>
											</td>
										</tr>
										<?php
									}else{
										$product=new WC_Product($product_id);
										$attribute=$product->get_attributes();

										$attribute_name='';
										foreach ($attribute as $key => $value) {
											$attribute_name= $value['name'];
										}
										$variation=new WC_Product_Variation($details[$i]['variable_id']);
										$aaa=$variation->get_variation_attributes();

										$attribute_prop= strtoupper($aaa['attribute_'.strtolower($attribute_name)]);
										?>
										<tr class="order_item alt-table-row">
											<td class="product-name">
												<a href="#"><?php echo $details[$i]['product_name']; ?></a>
												<strong class="product-quantity">× <?php echo $details[$i]['qty']; ?></strong>

											</td>
											<td class="product-total">
												<?php echo $cur_symbol.$details[$i]['product_total_price']; ?>
											</td>
										</tr>
										<?php
									}
								}
							}
							?>
						</tbody>
						<tfoot>
							<?php if(!empty($shipping_method)) : ?>
								<tr>
									<th scope="row"><?php echo _e("Shipping", "marketplace"); ?>:</th>
									<td><?php echo $cur_symbol . ( $order->get_total_shipping() ? $order->get_total_shipping() : 0 ); ?></td>
								</tr>
							<?php endif; ?>
							<?php if(!empty($payment_method)) : ?>
								<tr>
									<th scope="row"><?php echo _e("Payment Method", "marketplace"); ?>:</th>
									<td><?php echo $payment_method; ?></td>
								</tr>
							<?php endif; ?>
							<tr class="alt-table-row">
								<th scope="row"><?php echo _e("Total", "marketplace"); ?>:</th>
								<td>
									<span class="amount"><?php echo $cur_symbol.$total_payment; ?></span>
								</td>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
			<header><h3><?php echo _e("Customer details", "marketplace"); ?></h3></header>
			<table class="shop_table shop_table_responsive customer_details">
				<tbody>
					<tr>
						<th><?php echo _e("Email", "marketplace"); ?>:</th>
						<td data-title="Email"><?php echo $order->get_billing_email(); ?></td>
					</tr>
					<tr class="alt-table-row">
						<th><?php echo _e("Telephone", "marketplace"); ?>:</th>
						<td data-title="Telephone"><?php echo $order->get_billing_phone(); ?></td>
					</tr>
				</tbody>
			</table>
			<div class="col2-set addresses">
				<div class="col-1">
					<header class="title">
						<h3><?php echo _e("Billing Address", "marketplace"); ?></h3>
					</header>
					<address>
						<?php
						 	if( empty($order->get_billing_first_name()) && empty($order->get_billing_last_name()) && empty($order->get_billing_address_1()) && empty($order->get_billing_address_2()) && empty($order->get_billing_country()) )
							echo 'No billing address set.';
						?>
						<?php echo $order->get_billing_first_name().' '.$order->get_billing_last_name().'<br>'.$order->get_billing_address_1().'<br>';
						if($order->get_billing_address_2()!=''){
							echo $order->get_billing_address_2().'<br>';
						}
						echo $order->get_billing_city().' - '.$order->get_billing_postcode().'<br>'.$order->get_billing_state().', '.WC()->countries->countries[$order->get_billing_country()]; ?>
					</address>
				</div><!-- /.col-1 -->
				<div class="col-2">
					<header class="title">
						<h3><?php echo _e("Shipping Address", "marketplace"); ?></h3>
					</header>
					<address>
						<?php
							if( empty($order->get_shipping_first_name()) && empty($order->get_shipping_last_name()) && empty($order->get_shipping_address_1()) && empty($order->get_shipping_address_2()) && empty($order->get_shipping_country()) )
								echo 'No shipping address set.';
						?>
						<?php echo $order->get_shipping_first_name().' '.$order->get_shipping_last_name().'<br>'.$order->get_shipping_address_1().'<br>';
						if($order->get_shipping_address_2()!=''){
							echo $order->get_shipping_address_2().'<br>';
						}
		        if($order->get_shipping_country())
						echo $order->get_shipping_city().' - '.$order->get_shipping_postcode().'<br>'.$order->get_shipping_state().', '.WC()->countries->countries[$order->get_shipping_country()]; ?>
					</address>
				</div><!-- /.col-2 -->
			</div>

			<!-- Order status form  -->
			<?php

			$order_status = $query_result = '';

			if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s;", $wpdb->prefix . 'mpseller_orders' ) ) === $wpdb->prefix . 'mpseller_orders' ) {
				$query = $wpdb->prepare( "SELECT order_status from {$wpdb->prefix}mpseller_orders where order_id = '%d' and seller_id = '%d'", $order_id, $user_id );
				$query_result = $wpdb->get_results( $query );
			}

			if ( $query_result ) {
				$order_status = $query_result[0]->order_status;
			}
			if ( ! $order_status) {
				$order_status = get_post_field( 'post_status', $order_id );
			}
			
			?>

			<div class="mp-status-manage-class">
				<header class="title">
					<h3><?php esc_html_e( 'Order Status', 'marketplace' ); ?></h3>
				</header>

				<?php if ( $order_status != 'wc-completed' ): ?>
					<form method="POST">
						<table class="shop_table shop_table_responsive customer_details">
							<tbody>
								<tr>
									<td><label for="mp-status">Status:</label></td>
									<td>
										<select name="mp-order-status" id="mp-status" class="mp-select">
											<?php
											foreach (wc_get_order_statuses() as $key => $value) {
												?>
												<option value="<?php echo $key; ?>" <?php if ( $order_status == $key ) {
													echo 'selected';
												} ?>><?php echo $value; ?></option>
												<?php
											}
											?>
										</select>
									</td>
								</tr>
								<tr>
									<?php
										wp_nonce_field( 'mp_order_status_nonce_action', 'mp_order_status_nonce' );
										echo "<input type='hidden' name='mp-order-id' value={$order_id} />";
										echo "<input type='hidden' name='mp-seller-id' value={$user_id} />";
										echo "<input type='hidden' name='mp-old-order-status' value={$order_status} />";
									?>
									<td><input type="submit" name="mp-submit-status" class="button" value="<?php echo __( 'Save', 'marketplace' ); ?>" /></td>
								</tr>
							</tbody>
						</table>
					</form>
					<?php else: ?>
						<p><?php echo __( 'Status: Order status is completed.', 'marketplace' ); ?></p>
					<?php endif; ?>
			</div>

			<?php

			$args = array(
				'post_id'   => $order_id,
				'orderby'   => 'comment_ID',
				'order'     => 'DESC',
				'approve'   => 'approve',
				'type'      => 'order_note',
			);

			remove_filter( 'comments_clauses', array( 'WC_Comments', 'exclude_order_comments' ), 10, 1 );

			$notes = get_comments( $args );

			add_filter( 'comments_clauses', array( 'WC_Comments', 'exclude_order_comments' ), 10, 1 );

			echo '<div class="mp-order-notes">';

			?><h3><?php esc_html_e( 'Order Notes', 'marketplace' ); ?> </h3> <?php

			echo '<ul class="order_notes">';

			if ( $notes ) {

				foreach ( $notes as $note ) {

					?>
					<li>
						<div class="note_content">
							<?php echo wpautop( wptexturize( wp_kses_post( $note->comment_content ) ) ); ?>
						</div>
						<p class="meta">
							<abbr class="exact-date" title="<?php echo $note->comment_date; ?>"><?php printf( __( 'added on %1$s at %2$s', 'marketplace' ), date_i18n( wc_date_format(), strtotime( $note->comment_date ) ), date_i18n( wc_time_format(), strtotime( $note->comment_date ) ) ); ?></abbr>
							<?php
							if ( __( 'WooCommerce', 'marketplace' ) !== $note->comment_author ) :
								/* translators: %s: note author */
								printf( ' ' . __( 'by %s', 'marketplace' ), $note->comment_author );
							endif;
							?>
						</p>
					</li>
					<?php
				}
			} else {
				echo '<li>' . __( 'There are no notes yet.', 'woocommerce' ) . '</li>';
			}

			echo '</ul>';

			echo '</div>';

			?>

	</div>

	<?php else : ?>

		<h1>Cheating huh ???</h1>
		<p>Sorry, You can't access other seller's orders.</p>

	<?php
	endif;

	?> </div> <?php

} catch (Exception $e) {
	wc_print_notice( $e->getMessage(), 'error' );
}
