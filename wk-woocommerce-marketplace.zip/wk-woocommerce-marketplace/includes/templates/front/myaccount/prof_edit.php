<?php

global $current_user, $wpdb;

$wpmp_obj12 = new MP_Form_Handler();

if ( isset( $_POST['update_profile_submit'] ) ) {
	$wpmp_obj12->profile_edit_redirection();
}

$current_user = get_current_user_ID();

$current_user = get_user_by('ID', $current_user);

if ( $current_user->ID ) {

	$avatar=$wpmp_obj12->get_user_avatar($current_user->ID,'avatar');
	$shop_banner=$wpmp_obj12->get_user_avatar($current_user->ID,'shop_banner');
	$com_logo=$wpmp_obj12->get_user_avatar($current_user->ID,'company_logo');
	$usermeta_row_data=$wpdb->get_results("select * from $wpdb->usermeta where user_id=".$current_user->ID);
	$user_meta_arr=array();
	foreach($usermeta_row_data as $key=>$value)
	{
	 $user_meta_arr[$value->meta_key]=$value->meta_value;
	}
}

$page_name = $wpdb->get_var( "SELECT post_name FROM $wpdb->posts WHERE post_name ='" . get_option( 'wkmp_seller_page_title' ) . "'" );

?> <div class="woocommerce-account"> <?php

apply_filters( 'mp_get_wc_account_menu', 'marketplace' );

?>

<div class="wk_profileupdate woocommerce-MyAccount-content">

	<div class="wkmp_profile_preview_link">
		<a href="<?php echo site_url() . '/' . $page_name . '/store/' . $user_meta_arr['shop_address']; ?>" class="button" target="_blank"><?php echo __( 'View Profile', 'marketplace' ); ?></a>
	</div>

	<form action="" method="post" enctype="multipart/form-data">

		<div class="wkmp-tab-content">

		<div class="wkmp_profileinfo">

				<div class="wkmp_profile_input">
				<label for="wk_username"><?php _e("Username", "marketplace"); ?></label>
				<input type="text" name="wk_username" value="<?php echo $current_user->user_login;?>" id="wk_username" readonly disabled="disabled" /><br>
				<i>Username cannot be changed.</i>
				<input type="hidden" name="wk_user_nonece" value="<?php echo $current_user->user_login;?>" id="wk_user_nonece" readonly />
				<div id=""></div>
				</div>
				<div class="wkmp_profile_input">
				<label for="wk_firstname"><?php _e("First Name", "marketplace"); ?></label>
				<input type="text" value="<?php echo isset($user_meta_arr['first_name'])?$user_meta_arr['first_name']:'';?>" name="wk_firstname" id="wk_firstname" />
				<div id="first_name_error" class="error-class"></div>
				</div>
				<div class="wkmp_profile_input">
				<label for="wk_lastname"><?php _e("Last Name", "marketplace"); ?></label>
				<input type="text" value="<?php echo isset($user_meta_arr['last_name'])?$user_meta_arr['last_name']:'';?>" name="wk_lastname"  id="wk_lastname" />
				<div id="last_name_error" class="error-class"></div>
				</div>
				<div class="wkmp_profile_input">
				<label for="wk_useremail"><?php _e("E-mail", "marketplace"); ?></label>
				<input type="text" value="<?php echo $current_user->user_email;?>" name="user_email" id="wk_useremail" />
				<div class="error-class" id="email_reg_error"></div>
				</div>

				<div class="wkmp_profile_input">
					<label for="wk_store_name"><?php _e("Shop Name", "marketplace"); ?></label>
					<input type="text" placeholder="" value="<?php echo isset($user_meta_arr['shop_name'])?$user_meta_arr['shop_name']:'';?>" name="wk_storename" id="wk_storename" class="wk_loginput"/>
					<div class="error-class" id="seller_storename"></div>
				</div>
				<div class="wkmp_profile_input">
					<label for="wk_shop_add"><?php _e("Shop URL", "marketplace"); ?></label>
					<input type="text" placeholder="Shop Address" value="<?php echo isset($user_meta_arr['shop_address'])?$user_meta_arr['shop_address']:'';?>" name="wk_storeurl" id="wk_storeurl" class="wk_loginput" disabled="disabled" readonly/>
					<div class="error-class" id="seller_storeaddress"></div>
					<i><?php echo __( 'Shop URL cannot be changed.', 'marketplace' ); ?></i>
				</div>
				<div class="wkmp_profile_input">
					<label for="wk_shop_add"><?php esc_html_e( 'Phone Number', 'marketplace' ); ?></label>
					<input type="text" placeholder="Shop Phone Number" value="<?php echo isset( $user_meta_arr['billing_phone'] ) ? $user_meta_arr['billing_phone'] : '' ; ?>" name="wk_storephone" id="wk_storephone" class="wk_loginput"/>
					<div class="error-class" id="seller_storephone"></div>
				</div>
				<div class="wkmp_profile_input">
					<label for="wk_user_address"><?php _e("Address", "marketplace"); ?></label>
					<textarea type="text" placeholder="" name="wk_user_address" id="wk_user_address" class="wk_loginput"><?php echo isset($user_meta_arr['wk_user_address'])?$user_meta_arr['wk_user_address']:'';?></textarea>
					<div class="error-class" id="seller_user_address"></div>
				</div>

		<div class="wkmp_avatar_logo_section">

			<div class="wkmp_profileimg">
				<?php
				if ( isset( $avatar[0]->meta_value ) ) {
					$avatar_thumb_id = ( $user_meta_arr['_thumbnail_id_avatar'] ) ? $user_meta_arr['_thumbnail_id_avatar'] : '';
					echo '<div class="wkmp_editmp_img" id="mp_seller_image"><img src="' . content_url() . '/uploads/' . $avatar[0]->meta_value . '" /><span data-id="' . $avatar_thumb_id . '" data-default="' . WK_MARKETPLACE . 'assets/images/genric-male.png" class="mp-image-remove-icon">x</span><input type="hidden" class="mp-remove-avatar" name="mp-remove-avatar" value="" /></div>';
				} else {
					echo '<div class="wkmp_editmp_img" id="mp_seller_image"><img src="' . WK_MARKETPLACE . 'assets/images/genric-male.png" /></div>';
				}
				?>
				<div class="wkmp-fileUpload wkmp_profile_input">
					<label><?php echo __( 'User Image', 'marketplace' ); ?></label>
					<i><?php echo __( 'Upload image jpeg or png', 'marketplace' ); ?></i>
					<span class="button"><?php _e( 'Upload', 'marketplace' ); ?><input type="file" class="upload mp_seller_profile_img" name="mp_useravatar" id="mp_useravatar" /></span>
				</div>
			</div>

			<div class="wkmp_profile_logo">
				<?php
				if ( $com_logo ) {
					$logo_thumb_id = ( $user_meta_arr['_thumbnail_id_company_logo'] ) ? $user_meta_arr['_thumbnail_id_company_logo'] : '';
					echo '<div class="seller_logo_img" id="seller_com_logo_img"><img src="' . content_url() . '/uploads/' . $com_logo[0]->meta_value . '" /><span data-id="' . $logo_thumb_id . '" data-default="' . WK_MARKETPLACE . 'assets/images/shop-logo.png" class="mp-image-remove-icon">x</span><input type="hidden" class="mp-remove-company-logo" name="mp-remove-company-logo" value="" /></div>';
				} else {
					echo '<div class="seller_logo_img" id="seller_com_logo_img"><img src="' . WK_MARKETPLACE . 'assets/images/shop-logo.png" /></div>';
				}
				?>
				<div class="wkmp-fileUpload wkmp_profile_input">
					<label><?php echo __( 'Shop Logo', 'marketplace' ); ?></label>
					<i><?php echo __( 'Upload image jpeg or png', 'marketplace' ); ?></i>
					<span class="button"><?php _e( 'Upload', 'marketplace' ); ?><input type="file" class="upload Company_Logo" name="mp_company_logo" id="mp_company_logo" /></span>
				</div>
			</div>

		</div>


		<!-- shop banner -->
		<div class=" wkmp_profile_input">
			<label><?php echo __( 'Banner Image', 'marketplace' ); ?></label>
			<div class="banner-checkbox"><input type="checkbox" name="mp_display_banner" id="banner_visibility" value="yes" <?php if ( isset( $user_meta_arr['shop_banner_visibility'] ) && $user_meta_arr['shop_banner_visibility'] == 'yes' ) echo 'checked'; ?> /><label for="banner_visibility"><?php echo __( 'Show banner on seller page', 'marketplace' ); ?></label></div>
			<div class="wkmp_shop_banner">
				<div class="wkmp-fade-banner" id="wkmp_seller_banner">
						<p><?php echo __( 'Upload', 'marketplace' ); ?></p>
				</div>
				<div class="wkmp-fileUpload wkmp_up_shop_banner">
					<span><?php _e("Upload", "marketplace"); ?></span>
					<input type="file" class="upload" name="wk_mp_shop_banner" id="wk_mp_shop_banner"/>
				</div>
				<?php
				if ( $shop_banner ) {
					$banner_thumb_id = ( $user_meta_arr['_thumbnail_id_shop_banner'] ) ? $user_meta_arr['_thumbnail_id_shop_banner'] : '';
					echo '<div class="wk_banner_img" id="wk_seller_banner"><img src="' . content_url() . '/uploads/' . $shop_banner[0]->meta_value . '" /><span title="Remove" data-id="' . $banner_thumb_id . '" data-default="' . WK_MARKETPLACE . 'assets/images/woocommerce-marketplace-banner.png" class="mp-image-remove-icon">x</span><input type="hidden" class="mp-remove-shop-banner" name="mp-remove-shop-banner" value="" /></div>';
				} else {
					echo '<div class="wk_banner_img" id="wk_seller_banner"><img src= "' . WK_MARKETPLACE . 'assets/images/woocommerce-marketplace-banner.png" /></div>';
				}
				?>
			</div>
		</div>
		<!-- shop banner end-->

    <div class="wkmp_profile_input">
       	<label for="wk_marketplace_about_shop"><?php _e("About Shop", "marketplace"); ?></label>
    	<textarea name="wk_marketplace_about_shop" rows="4" id="wk_marketplace_about_shop" class="wk_loginput"><?php echo isset($user_meta_arr['about_shop'])?$user_meta_arr['about_shop']:'';?></textarea>
    </div>

		<h3><b><?php _e("Social Profile", "marketplace"); ?></b></h3>

		<div class="wkmp_profile_input">

			<label for="settings[social][fb]">Facebook Profile ID</label><i> (optional)</i>
			<div class="social-seller-input">
				<input id="settings[social][fb]"  type="text" placeholder="http://" name="settings[social][fb]" value="<?php echo isset($user_meta_arr['social_facebook'])?$user_meta_arr['social_facebook']:'';?>">
			</div>
			<div class="error-class" id="seller_user_address"></div>

		</div>
		<div class="wkmp_profile_input">
			<label for="settings[social][twitter]">Twitter Profile ID</label><i> (optional)</i>
			<div class="social-seller-input">
				<input id="settings[social][twitter]"  type="text" placeholder="http://" name="settings[social][twitter]" value="<?php echo isset($user_meta_arr['social_twitter'])?$user_meta_arr['social_twitter']:'';?>">
			</div>
			<div class="error-class" id="seller_user_address"></div>
		</div>
		<div class="wkmp_profile_input">

			<label for="settings[social][gplus]">Google Plus ID</label><i> (optional)</i>
			<div class="social-seller-input">

				<input id="settings[social][gplus]"  type="text" placeholder="http://" name="settings[social][gplus]" value="<?php echo isset($user_meta_arr['social_gplus'])?$user_meta_arr['social_gplus']:'';?>">

			</div>
			<div class="error-class" id="seller_user_address"></div>
		</div>
		<div class="wkmp_profile_input">
			<label for="settings[social][linked]">Linkedin Profile ID</label><i> (optional)</i>
			<div class="social-seller-input">
				<input id="settings[social][linked]"  type="text" placeholder="http://" name="settings[social][linked]" value="<?php echo isset($user_meta_arr['social_linkedin'])?$user_meta_arr['social_linkedin']:'';?>">
			</div>
			<div class="error-class" id="seller_user_address"></div>
		</div>
		<div class="wkmp_profile_input">
			<label for="settings[social][youtube]">Youtube Profile ID</label><i> (optional)</i>
			<div class="social-seller-input">
				<input id="settings[social][youtube]"  type="text" placeholder="http://" name="settings[social][youtube]" value="<?php echo isset($user_meta_arr['social_youtube'])?$user_meta_arr['social_youtube']:'';?>">
			</div>
			<div class="error-class" id="seller_user_address"></div>
		</div>
	</div>

	<!-- seller paymentmethod -->
	<div class="wkmp_profile_input">
		<?php if(isset($user_meta_arr['mp_seller_payment_method']))
			$stripe_unserialize_data=maybe_unserialize($user_meta_arr['mp_seller_payment_method']);
		?>
		<label for="mp_seller_payment_method"><?php _e( 'Payment Information', 'marketplace' ); ?></label>
		<textarea name="mp_seller_payment_method" placeholder="eg : test@paypal.com"><?php if(isset($stripe_unserialize_data['standard'])) echo $stripe_unserialize_data['standard']; ?></textarea><br /><br />
			<?php $paymet_gateways=WC()->payment_gateways->payment_gateways();
				do_action('marketplace_payment_gateway');
			?>

	</div>

	<div class="wkmp_profile_btn">
		<input type="submit" value="<?php echo __('Update', 'marketplace'); ?>" name="update_profile_submit" id="update_profile_submit" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="<?php echo get_permalink();?>" class="button"><?php _e("Cancel", "marketplace"); ?></a>
	</div>

	<?php wp_nonce_field('edit_profile','wk_user_nonece'); ?>

	</form>
</div>

</div>
