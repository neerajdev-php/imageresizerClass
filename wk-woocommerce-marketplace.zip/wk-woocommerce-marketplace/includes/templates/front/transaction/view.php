<?php
/**
 * This file handles single transaction detail view template.
 *
 * @package Woocommerce Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$order_ids = maybe_unserialize( $order_id );
?>
<div class="woocommerce-account">
	<?php apply_filters( 'mp_get_wc_account_menu', 'marketplace' ); ?>
	<div class="wk-transaction-view woocommerce-MyAccount-content">
		<div class="wk-mp-transaction-info-box">
				<div>
					<h3>
						Transaction Id - <?php echo $transaction_id; ?>
					</h3>
						<div class="box">
							<div class="box-title">
									<h3>Information</h3>
							</div>
							<fieldset>
								<div class="box-content">
										<div class="wk_row">
											<span class="label">Date : </span>
											<span class="value"><?php echo date( 'F j, Y', strtotime( $transaction_date ) ); ?></span>
										</div>
										<div class="wk_row">
											<span class="label">Amount : </span>
											<span class="value"><span class="price"><?php echo wc_price( $amount ); ?></span></span>
										</div>
										<div class="wk_row">
											<span class="label">Type : </span>
											<span class="value"><?php echo $type; ?></span>
										</div>
										<div class="wk_row">
											<span class="label">Method : </span>
											<span class="value"><?php echo $method; ?></span>
										</div>
								</div>
							</fieldset>
						</div>
				</div>
		</div>
		<div class="transaction-details">
			<div class="table-wrapper">
				<h3 class="table-caption">
					Detail
				</h3>
				<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
					<thead>
						<tr>
							<?php foreach ( $columns as $column_id => $column_name ) : ?>
								<th class="woocommerce-orders-table__header woocommerce-orders-table__header-<?php echo esc_attr( $column_id ); ?>"><span class="nobr"><?php echo esc_html( $column_name ); ?></span></th>
							<?php endforeach; ?>
						</tr>
					</thead>

					<tbody>
						<?php
						$i = 0;
						foreach ( $order_ids as $order_id ) :
							$order      = wc_get_order( $order_id );
							$item_count = $order->get_item_count();
							$item_id    = maybe_unserialize( $order_item_id )[ $i ];
							$product_id = wc_get_order_item_meta( $item_id, '_variation_id' ) ? wc_get_order_item_meta( $item_id, '_variation_id' ) : wc_get_order_item_meta( $item_id, '_product_id' );
							$product_name = get_the_title( $product_id );
							$quantity = wc_get_order_item_meta( $item_id, '_qty' );
							$line_total = wc_get_order_item_meta( $item_id, '_line_total' );
							$commission_amount = $admin_rate * $line_total;
							$subtotal = $line_total - $commission_amount;
							?>
							<tr class="woocommerce-orders-table__row woocommerce-orders-table__row--status-<?php echo esc_attr( $order->get_status() ); ?> order">
								<?php foreach ( $columns as $column_id => $column_name ) : ?>
									<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-<?php echo esc_attr( $column_id ); ?>" data-title="<?php echo esc_attr( $column_name ); ?>">

										<?php if ( 'order-id' === $column_id ) : ?>
											<?php echo _x( '#', 'hash before order number', 'woocommerce' ) . $order->get_order_number(); ?>

										<?php elseif ( 'product-name' === $column_id ) : ?>
											<?php echo esc_html( $product_name . '( #' . $product_id . ' )' ); ?>

										<?php elseif ( 'product-quantity' === $column_id ) : ?>
											<?php echo esc_html( $quantity ); ?>

										<?php elseif ( 'total-price' === $column_id ) : ?>
											<?php echo wc_price( $line_total ); ?>

										<?php elseif ( 'commission' === $column_id ) : ?>
											<?php echo wc_price( $commission_amount ); ?>

										<?php elseif ( 'subtotal' === $column_id ) : ?>
											<?php echo wc_price( $subtotal ); ?>

										<?php elseif ( 'order-total' === $column_id ) : ?>
											<?php
											/* translators: 1: formatted order total 2: total order items */
											printf( _n( '%1$s for %2$s item', '%1$s for %2$s items', $item_count, 'woocommerce' ), $order->get_formatted_order_total(), $item_count );
											?>

										<?php endif; ?>
									</td>
								<?php endforeach; ?>
							</tr>
						<?php
						$i++;
						endforeach;
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div
