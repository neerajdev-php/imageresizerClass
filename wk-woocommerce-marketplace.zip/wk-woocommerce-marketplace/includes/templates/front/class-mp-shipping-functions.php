<?php


function manage_shipping(){
    require_once('shipping/shipping-list.php');
}

function add_shipping(){
    require_once('shipping/add-shipping.php');
}

function edit_shipping(){
    require_once('shipping/edit-shipping.php');
}
