<?php
/**
 * Handle frontend forms
 *
 * @class MP_Frontend_Scripts
 * @version 4.7.0
 * @package Marketplace/Classes/
 * @category Class
 * @author webkul
 */
class MP_Frontend_Scripts {

	function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_marketplace_styles' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'add_jquery_libraries' ) );
	}

	public function register_marketplace_styles() {
		wp_register_style( 'marketplace-style', WK_MARKETPLACE . 'style.css', '', '' );
		wp_register_style( 'datatable-css', WK_MARKETPLACE . 'assets/css/datatable.css' );

		wp_enqueue_style( 'marketplace-style' );
		wp_enqueue_style( 'datatable-css' );
	}

	public function add_jquery_libraries() {
		wp_register_script( 'jquery', 'http://code.jquery.com/jquery-1.11.1.min.js' );
		wp_enqueue_script( 'jquery' );

		wp_register_script( 'pagination-js', WK_MARKETPLACE . 'assets/js/pagination_datatable.js' );
		wp_enqueue_script( 'pagination-js' );

		wp_localize_script( 'pagination-js', 'paginationScript',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'ajaxnonce' ),
			)
		);

		wp_register_script( 'datatable-cdn', WK_MARKETPLACE . 'assets/js/datatable-cdn-js.js' );
		wp_enqueue_script( 'datatable-cdn' );

		wp_register_script( 'easy-js', WK_MARKETPLACE . 'assets/js/easying.js' );
		wp_enqueue_script( 'easy-js' );

		wp_register_script( 'bsxlider', WK_MARKETPLACE . 'assets/js/jquery.bxslider.min.js' );
		wp_enqueue_script( 'bsxlider' );

		if ( null !== get_query_var('main_page') && get_query_var('main_page') == 'dashboard' ) {
			wp_enqueue_script( 'google_chart', '//www.google.com/jsapi');

			wp_enqueue_script( 'mp_chart_script', 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js' );

			wp_register_script( 'mp-chart-js', WK_MARKETPLACE . '/assets/js/chart_script.js' );

			wp_enqueue_script( 'mp-chart-js' );

			wp_localize_script( 'mp-chart-js',
				'mp_chart_js',
				array(
					'ajaxurl' => admin_url( 'admin-ajax.php' ),
					'nonce' => wp_create_nonce( 'ajaxnonce' ),
				)
			);
		}
	}
}
new MP_Frontend_Scripts();
