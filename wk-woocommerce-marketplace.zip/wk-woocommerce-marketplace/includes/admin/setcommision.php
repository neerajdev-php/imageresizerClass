<?php

class setCommition {

	function __construct() {

		add_action( 'mp_manage_seller_commission', array( $this, 'mp_manage_seller_commission' ), 10, 1 );

		add_action( 'mp_manage_seller_orders', array( $this, 'mp_manage_seller_orders' ) );

		add_action( 'mp_manage_seller_transactions', array( $this, 'mp_manage_seller_transactions' ) );

		add_action( 'mp_manage_seller_details', array( $this, 'mp_manage_seller_details' ) );

		add_action( 'mp_manage_seller_assign_category', array( $this, 'mp_manage_seller_assign_category' ) );

		// Nav tabs.
		echo '<div class="wrap">';


		$seller_id = '';

		if ( isset( $_GET['sid'] ) && ! empty( $_GET['sid'] ) ) {
			$seller_id = $_GET['sid'];
		}

		if ( ! empty( $seller_id ) ) {
			$user = get_user_by( 'ID', $seller_id );
			if ( $user && in_array( 'wk_marketplace_seller', $user->roles ) ) {
				echo '<nav class="nav-tab-wrapper">';
				$mp_tabs = array(
					'details'         => __( 'Details', 'marketplace' ),
					'orders'          => __( 'Orders', 'marketplace' ),
					'transactions'    => __( 'Transactions', 'marketplace' ),
					'commission'      => __( 'Commission', 'marketplace' ),
					'assign_category'      => __( 'Assign Category', 'marketplace' )
				);

				$mp_tabs = apply_filters( 'marketplace_get_settings_tabs', $mp_tabs );

				$current_tab = empty( $_GET['tab'] ) ? 'orders' : sanitize_title( $_GET['tab'] );

				$this->id = $current_tab;

				foreach ( $mp_tabs as $name => $label ) {
					echo '<a href="' . admin_url( 'admin.php?page=sellers&action=set&tab=' . $name . '&sid=' . $seller_id ) . '" class="nav-tab ' . ( $current_tab == $name ? 'nav-tab-active' : '' ) . '">' . $label . '</a>';
				}

				?>
			</nav>

			<h1 class="screen-reader-text">
				<?php echo esc_html( $mp_tabs[ $current_tab ] ); ?>
			</h1>

			<?php

			do_action( 'mp_manage_seller_' . $current_tab, $seller_id );
		} else {
			echo  '<div class="notice notice-error is-dismissible">';
			echo '<p>Invalid Seller ID.!</p>';
			echo '</div>';
		}
		}

		echo '</div>';

	}

	public function mp_manage_seller_commission( $seller_id ) {

		global $wpdb;

		$sid = ( int ) $seller_id;

		if ( $sid ) {

			if ( isset( $_POST['commision'] ) ) {

				$commision = (int) $_POST['commision'];

				if ( $commision > 0 ) {

					$sql = $wpdb->update(
						"{$wpdb->prefix}mpcommision",
						array(
							'commision_on_seller' => $commision,
						),
						array(
							'seller_id'	=> $sid,
						),
						array(
							'%d'
						),
						array( '%d' )
					);

					if ( $sql ) {

						echo  '<div class="notice notice-success is-dismissible">';
							echo '<p>Commision Rate is updated.!</p>';
						echo '</div>';

					} else {

						echo  '<div class="notice notice-error is-dismissible">';
							echo '<p>Commision value is invalid.!</p>';
						echo '</div>';
					}
				} else {

					echo  '<div class="notice notice-error is-dismissible">';
						echo '<p>Commision value is invalid.!</p>';
					echo '</div>';

				}
			}

			$com_res = $wpdb->get_results( "select * from {$wpdb->prefix}mpcommision  where seller_id=$sid" );
			$cur_symbol = get_woocommerce_currency_symbol( get_option( 'woocommerce_currency' ) );

			if ( $com_res ) {

				if ( is_admin() ) {

					require_once WK_MARKETPLACE_DIR . 'includes/templates/admin/account/seller/manage-commission.php';

				}
			} else {

				echo  '<div class="notice notice-error is-dismissible">';
					echo '<p>Commision id is not valid.!</p>';
				echo '</div>';

			}
		} else {

			echo  '<div class="notice notice-error is-dismissible">';
				echo '<p>Commision id is not valid.!</p>';
			echo '</div>';
		}
	}

	public function mp_manage_seller_orders( $seller_id ) {
		mp_manage_seller_orders( $seller_id );
	}

	public function mp_manage_seller_transactions( $seller_id ) {
		global $transaction, $commission;
		$seller_transaction = $transaction->get( $seller_id );

		if ( isset( $_GET['id'] ) && ! empty( $_GET['id'] ) ) {
			$transaction_id = $_GET['id'];
			$transaction_detail = $transaction->get_by_id( $transaction_id, $seller_id );
			$admin_rate = $commission->get_admin_rate( $seller_id );
			extract( $transaction_detail );

			$columns = apply_filters( 'mp_account_transactions_columns', array(
				'order-id'      => __( 'Order Id', 'woocommerce' ),
				'product-name'    => __( 'Product Name', 'woocommerce' ),
				'product-quantity'   => __( 'Qty', 'woocommerce' ),
				'total-price'   => __( 'Total Price', 'woocommerce' ),
				'commission'   => __( 'Commission', 'woocommerce' ),
				'subtotal'   => __( 'Subtotal', 'woocommerce' ),
			) );

			if ( ! empty( $transaction_detail ) ) {
				require_once WK_MARKETPLACE_DIR . 'includes/templates/admin/account/seller/transaction/view.php';
			} else {
				echo  '<div class="notice notice-error is-dismissible">';
					echo '<p>Invalid Transaction.!</p>';
				echo '</div>';
			}
		} else {
			require_once WK_MARKETPLACE_DIR . 'includes/admin/account/seller/transactions.php';
		}
	}

	public function mp_manage_seller_details( $seller_id ) {
			require_once WK_MARKETPLACE_DIR . 'includes/templates/admin/account/seller/profile.php';
	}

	public function mp_manage_seller_assign_category($seller_id)
	{
			if (isset($_POST['mp_submit_assign_category']) && isset($_POST['wkmp_seller_allowed_categories'])) {
					$true = update_user_meta($seller_id, 'wkmp_seller_allowed_categories', $_POST['wkmp_seller_allowed_categories']);

					if ($true) {
						echo  '<div class="notice notice-success is-dismissible">';
							?><p><?php echo __('Categories saved successfully.', 'marketplace'); ?></p><?php
						echo '</div>';
					}
			}

			$allowed_cat = get_user_meta($seller_id, 'wkmp_seller_allowed_categories', true);

			?>
			<form method="POST" action="">
					<table class="form-table">
		        	<tbody>
									<tr valign="top">
											<th scope="row">
													<label for="wkmp_seller_allowed_categories"><?php echo __('Allowed categories', 'marketplace'); ?></label>
											</th>

											<td class="forminp">
													<select name="wkmp_seller_allowed_categories[]" multiple="true" id="wkmp_allowed_categories_per_seller" data-placeholder="Select categories..." style="min-width:350px;">
															<?php

															$product_categories = get_terms('product_cat', array(
																'hide_empty' => false
															));

															if (!empty($product_categories)) :
																	foreach ($product_categories as $key => $value) : ?>
																			<?php if ($allowed_cat) : ?>
																					<option value="<?php echo $value->slug; ?>" <?php if (in_array($value->slug, $allowed_cat)) {
																						echo 'selected';
																					} ?>><?php echo $value->name; ?></option>
																			<?php else : ?>
																					<option value="<?php echo $value->slug; ?>"><?php echo $value->name; ?></option>
																			<?php endif; ?>
																	<?php endforeach; ?>
															<?php endif; ?>
													</select>
											</td>
									</tr>
							</tbody>
					</table>
					<p><input type="submit" class="button button-primary" name="mp_submit_assign_category" value="<?php echo __('Save', 'marketplace'); ?>" />
			</form>
			<?php
	}

}

new setCommition();
