<?php
/**
 * This file handles list for seller orders.
 *
 * @package Woocommerce Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Seller order list table.
 */
class Seller_Order_List extends WP_List_Table {

	/**
	 * Order List
	 *
	 * @var array Order List.
	 */
	public $order_list;

	/**
	 * Seller ID
	 *
	 * @var int Seller ID.
	 */
	public $seller_id;

	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct(

			array(
				'singular' => 'Seller Order List',
				'plural'   => 'Seller Orders List',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Handles all list functions.
	 */
	public function prepare_items() {

		global $wpdb;

		$columns = $this->get_columns();

		$sortable = $this->get_sortable_columns();

		$hidden = $this->get_hidden_columns();

		$this->process_bulk_action();

		$data = $this->table_data();

		$totalitems = count( $data );

		$user = get_current_user_id();

		$screen = get_current_screen();

		$perpage = $this->get_items_per_page( 'product_per_page', 20 );

		$this->_column_headers = array( $columns, $hidden, $sortable );

		if ( empty( $per_page ) || $per_page < 1 ) {

			$per_page = $screen->get_option( 'per_page', 'default' );

		}

		/**
		 * Handles sort order of data.
		 *
		 * @param array $a Default Order.
		 * @param array $b Result Order.
		 */
		function usort_reorder( $a, $b ) {

			$orderby = ( ! empty( $_REQUEST['orderby'] ) ) ? $_REQUEST['orderby'] : 'order_id'; // If no sort, default to title.

			$order = ( ! empty( $_REQUEST['order'] ) ) ? $_REQUEST['order'] : 'desc'; // If no order, default to asc.

			$result = strnatcmp( $a[ $orderby ], $b[ $orderby ] ); // Determine sort order.

			return ( 'asc' === $order ) ? $result : -$result; // Send final sort direction to usort.

		}

		usort( $data, 'usort_reorder' );

		$totalpages = ceil( $totalitems / $perpage );

		$currentpage = $this->get_pagenum();

		$data = array_slice( $data, ( ( $currentpage - 1 ) * $perpage ), $perpage );

		$this->set_pagination_args( array(

			'total_items' => $totalitems,

			'total_pages' => $totalpages,

			'per_page' => $perpage,

		) );

		$this->items = $data;

	}

	/**
	 * Define the columns that are going to be used in the table
	 *
	 * @return array $columns, the array of columns to use with the table
	 */
	public function get_columns() {
		$columns = array(
			'cb'                  => '<input type="checkbox" />', // Render a checkbox instead of text.
			'order_id'            => __( 'Order Id', 'marketplace' ),
			'product'             => __( 'Product', 'marketplace' ),
			'quantity'            => __( 'Quantity', 'marketplace' ),
			'product_total'       => __( 'Product Total', 'marketplace' ),
			'total_seller_amount' => __( 'Total Seller Amount', 'marketplace' ),
			'total_commission'    => __( 'Total Commission', 'marketplace' ),
			'status'              => __( 'Status', 'marketplace' ),
			'paid_status'         => __( 'Paid Status', 'marketplace' ),
			'action'              => __( 'Action', 'marketplace' ),
		);
		return $columns;
	}

	/**
	 * Default Column name with data goes here.
	 *
	 * @param array  $item Column Array.
	 * @param string $column_name Individual Column Slug.
	 */
	public function column_default( $item, $column_name ) {

		switch ( $column_name ) {
			case 'order_id':
			case 'product':
			case 'quantity':
			case 'product_total':
			case 'total_seller_amount':
			case 'total_commission':
			case 'status':
			case 'paid_status':
			case 'action':
				return $item[ $column_name ];
			default:
				return print_r( $item, true );
		}
	}

	/**
	 * Decide which columns to activate the sorting functionality on
	 *
	 * @return array $sortable, the array of columns that can be sorted by the user
	 */
	public function get_sortable_columns() {
		$sortable = array(
			'order_id' => array( 'order_id', true ),
			'status' => array( 'status', true ),
			'paid_status' => array( 'paid_status', true ),
		);
		return $sortable;
	}

	/**
	 * Hidden Columns.
	 */
	public function get_hidden_columns() {
		return array();
	}

	/**
	 * Checkbox column data.
	 *
	 * @param array $item column data.
	 */
	public function column_cb( $item ) {
		return sprintf( '<input type="checkbox" id="oid_%s" name="oid[]" value="%s" />',$item['id'], $item['id'] );
	}

	/**
	 * Table Data.
	 */
	private function table_data() {

		global $wpdb, $commission;

		$data = array();

		$i = 0;
		$order_id = array();
		$product = array();
		$quantity = array();
		$product_total = array();
		$total_seller_amount = array();
		$total_commission = array();
		$status = array();
		$paid_status = array();

		if ( ! empty( $this->order_list ) ) {

			foreach ( $this->order_list as $value ) {

				$o_id = $value['order_id'];
				$order    = wc_get_order( $o_id );
				$order_status = $order->get_status();
				if ( 'completed' !== $order_status ) {
					continue;
				}
				foreach ( $order->get_items() as $i_key => $i_value ) {
					$i_data = $i_value->get_data();
					$item_id = $i_key;

					if ( 0 !== $i_data['variation_id'] ) {
						$product_id = $i_data['variation_id'];
					} else {
						$product_id = $i_data['product_id'];
					}

					$author = get_post_field( 'post_author', $product_id );

					if ( $author === $this->seller_id ) {
						$order_id[] = $o_id;
						$product[]  = get_the_title( $product_id ) . '( #' . $product_id . ' )';
						$quantity[] = $i_data['quantity'];
						$product_total[] = $i_data['total'];
						$paid_status[] = wc_get_order_item_meta( $item_id, '_paid_status' ) ? wc_get_order_item_meta( $item_id, '_paid_status' ) : 'Not Paid';


						$id[] = $order_id[ $i ] . '-' . $item_id;
						$total_commission[] = $product_total[ $i ] * $commission->get_admin_rate( $this->seller_id );
						$total_seller_amount[] = $product_total[ $i ] - $total_commission[ $i ];

						$status[] = $order->get_status();

						if ( 'paid' === $paid_status[ $i ] ) {
							$action[] = '<button class="button button-primary" class="admin-order-pay" disabled>Paid</button>';
						} else {
							$action[] = '<a href="javascript:void(0)" data-id="' . $id [ $i ] . '" class="page-title-action admin-order-pay">Pay</a>';
						}

						$data[] = array(
							'id'                  => $id [ $i ],
							'order_id'            => $order_id[ $i ],
							'product'             => $product[ $i ],
							'quantity'            => $quantity[ $i ],
							'product_total'       => wc_price( $product_total[ $i ] ),
							'total_seller_amount' => wc_price( $total_seller_amount[ $i ] ),
							'total_commission'    => wc_price( $total_commission[ $i ] ),
							'status'              => $status[ $i ],
							'paid_status'         => $paid_status[ $i ],
							'action'              => $action[ $i ],
						);
						$i++;
					}
				}
			}
		}

		return $data;

	}

	/**
	 * Bulk actions on list.
	 */
	public function get_bulk_actions() {
		$actions = array(
			'pay'    => 'Pay',
		);
		return $actions;
	}

	/**
	 * Process bulk actions.
	 */
	public function process_bulk_action() {
		global $wpdb, $commission, $transaction;

		if ( $this->current_action() === 'pay' ) {
			if ( isset( $_POST['oid'] ) ) {
				if ( is_array( $_POST['oid'] ) && ! empty( $_POST['oid'] ) ) {
					$order_ids = $_POST['oid'];
					$t_order_ids = array();
					$result = '';
					$t_item_ids = array();
					$amount = floatval( 0 );
					foreach ( $order_ids as $ids ) {
						$order_id = explode( '-', $ids )[0];
						$item_id = explode( '-', $ids )[1];
						$t_order_ids[] = $order_id;
						$t_item_ids[] = $item_id;
						$paid_status = wc_get_order_item_meta( $item_id, '_paid_status' );
						if ( ! $paid_status ) {
							$result = $commission->update_seller_commission( $this->seller_id, $item_id );
							$amount += $result;
							wc_update_order_item_meta( $item_id, '_paid_status', 'paid' );
						}
					}
					if ( $amount > 0 ) {
						$response = $transaction->generate( $this->seller_id, $t_order_ids, $t_item_ids, $amount );
					}
				}
			}
		}
	}
}
$sellerorderlist = new Seller_Order_List();
$sellerorderlist->order_list = $order_list;
$sellerorderlist->seller_id = $seller_id;

echo '<div id="notice-wrapper"></div>';

echo '<form id="seller-order-list" method="post">';

$page  = filter_input( INPUT_GET, 'page', FILTER_SANITIZE_STRIPPED );

$paged = filter_input( INPUT_GET, 'paged', FILTER_SANITIZE_NUMBER_INT );

printf( '<input type="hidden" name="page" value="%s" />', $page );

printf( '<input type="hidden" name="seller_id" id="seller_id" value="%s" />', $seller_id );

printf( '<input type="hidden" name="paged" value="%d" />', $paged );



$sellerorderlist->prepare_items(); // this will prepare the items AND process the bulk actions.

$sellerorderlist->display();

echo '</form>';
