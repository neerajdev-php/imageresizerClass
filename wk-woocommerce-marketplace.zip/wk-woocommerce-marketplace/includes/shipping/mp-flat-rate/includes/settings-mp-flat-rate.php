<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = array();

$cost_desc = __( 'Enter a cost (excl. tax) or sum, e.g. <code>10.00 * [qty]</code>.', 'marketplace' ) . '<br/><br/>' . __( 'Use <code>[qty]</code> for the number of items, <br/><code>[cost]</code> for the total cost of items, and <code>[fee percent="10" min_fee="20" max_fee=""]</code> for percentage based fees.', 'marketplace' );

if ( is_admin() ) {
	$settings = array_merge( $settings, array(
		'title' => array(
	    'title' 		=> __( 'Marketplace Flat Rate Shipping', 'marketplace' ),
	    'type' 			=> 'text',
	    'description' 	=> __( 'This controls the title which the user sees during checkout.', 'marketplace' ),
	    'default'		=> __( 'Marketplace Flat Rate Shipping', 'marketplace' ),

	  ),
	) );
}

$settings = array_merge( $settings, array(
  'enabled' => array(
    'title' 		=> __( 'Enable/Disable', 'marketplace' ),
    'type' 			=> 'checkbox',
    'label' 		=> __( 'Enable WooCommerce Marketplace Flat Rate Shipping', 'marketplace' ),
    'default' 		=> 'yes'
  ),
  'tax_status' => array(
    'title' 		=> __( 'Tax status', 'marketplace' ),
    'type' 			=> 'select',
    'class'         => 'wc-enhanced-select',
    'default' 		=> 'taxable',
    'options'		=> array(
      'taxable' 	=> __( 'Taxable', 'marketplace' ),
      'none' 		=> _x( 'None', 'Tax status', 'marketplace' ),
    ),
  ),
  'cost' => array(
    'title' 		=> __( 'Cost', 'marketplace' ),
    'type' 			=> 'text',
    'placeholder'	=> '',
    'description'	=> $cost_desc,
    'default'		=> '0',
    'desc_tip'		=> true,
  ),
) );

return $settings;
