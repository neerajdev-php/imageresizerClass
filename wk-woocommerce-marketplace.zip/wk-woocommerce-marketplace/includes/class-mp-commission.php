<?php
/**
 * This file handles commission related functions.
 *
 * @package Woocommerce Marketplace
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'MP_Commission' ) ) {
	/**
	 * Commision Handler.
	 */
	class MP_Commission {
		/**
		 * Base Function.
		 */
		public function __construct() {
			global $commission;

			$commission = __CLASS__;
		}

		/**
		 * Get Commission per order item.
		 *
		 * @param int $order_id Order ID.
		 * @param int $product_id Product ID.
		 * @param int $quantity Product Quantity.
		 */
		public function get_order_item_commission( $order_id, $product_id, $quantity = '' ) {
			$order = wc_get_order( $order_id );

		}

		/**
		 * Get admin commission rate.
		 *
		 * @param int $seller_id Seller ID.
		 */
		public function get_admin_rate( $seller_id ) {
			global $wpdb;
			$admin_rate = 1;
			$admin_commission = $wpdb->get_results( "select * from {$wpdb->prefix}mpcommision  where seller_id=$seller_id" );

			if ( $admin_commission ) {
				$admin_rate = floatval( $admin_commission[0]->commision_on_seller ) / 100;
			}
			return $admin_rate;
		}

		/**
		 * Update Seller Commission data.
		 *
		 * @param int $seller_id Seller ID.
		 * @param int $item_id Item ID.
		 */
		public function update_seller_commission( $seller_id, $item_id ) {
			$admin_rate = self::get_admin_rate( $seller_id );
			$line_total = wc_get_order_item_meta( $item_id, '_line_total' );
			$pay_amount = $line_total * ( 1 - $admin_rate );
			$response = $this->update( $seller_id, $pay_amount );
			return $pay_amount;
		}

		/**
		 * Seller commision updation.
		 *
		 * @param int $seller_id Seller ID.
		 * @param int $pay_amount Admin Commission Rate.
		 */
		public function update( $seller_id, $pay_amount ) {

			$result = '';

			$seller_id = intval($seller_id);

			if ( ! empty( $seller_id ) && ! empty( $pay_amount ) ) {
				global $wpdb;
				$query  = "select * from {$wpdb->prefix}mpcommision where seller_id=$seller_id";

				$seller_data = $wpdb->get_results( $query );

				if ( ! empty( $seller_data ) ) {

					$remain = intval( $seller_data[0]->seller_total_ammount );

					if ( ( $remain >= $pay_amount ) && ( $pay_amount > 0 ) ) {
						$paid_ammount = $seller_data[0]->paid_amount + $pay_amount;
						$seller_total_ammount = $seller_data[0]->seller_total_ammount - $pay_amount;
						$last_paid_ammount = $pay_amount;
						$seller_money = $seller_data[0]->last_com_on_total - $seller_data[0]->admin_amount;
						$remain_ammount = $seller_money - $paid_ammount;

						// seller total amount.
						$res = $wpdb->update(
							"{$wpdb->prefix}mpcommision",
							array(
								'paid_amount'          => $paid_ammount,
								'seller_total_ammount' => $seller_total_ammount,
								'last_paid_ammount'    => $last_paid_ammount,
							),
							array( 'seller_id' => $seller_id ),
							array(
								'%f',
								'%f',
								'%f',
							),
							array( '%d' )
						);

						if ( $res ) {

							$result  = array(
								'error' => 0,
								'msg' => 'Amount Transfered Successfully.!',
							);

						}
					}
				}
			}

			return $result;
		}
	}
}
