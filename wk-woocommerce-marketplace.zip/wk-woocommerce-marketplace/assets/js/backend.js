var jQuery, formdata
jQuery(document).ready(function () {
  jQuery('#seller-order-list #doaction').on('click', function (e) {
    e.preventDefault()
    formdata = jQuery('#seller-order-list').serialize()
  })
})
