var jQuery
jQuery(document).ready(function () {
	jQuery('.pay-rem-amt').on('click', function () {
		var amtrem = jQuery(this).closest('.payment-modelbox').find('.thickbox_amt_rem').val()
		var paidamt = jQuery(this).closest('.payment-modelbox').find('.thickbox_paid_amt').val()
		var sellermain = jQuery(this).closest('.payment-modelbox').find('.seller_main').val()
		var isChecked = jQuery(this).closest('.payment-modelbox').find('.notify_seller').is(':checked')
		if (isChecked) {
			notifyseller = isChecked
		} else {
			notifyseller = false
		}
		jQuery.ajax({
			type: 'POST',
			url: the_mpadminajax_script.mpajaxurl,
			data: {
				"action":"wk_commission_resetup",
				"amt_rem":amtrem,
				"paid_amt":paidamt,
				"seller_main":sellermain,
				"notify_seller":notifyseller,
				"nonce":the_mpadminajax_script.nonce
			},
			success: function (data) {
						if (data) {
								location.reload()
						}
			}

		})

	})


			var name_regex = /^[a-zA-Z\s-, ]+$/
			var contact_regex = /^[0-9]+$/

			jQuery(document).on("blur","#tmplt_name",function(){
						if(jQuery("#tmplt_name").val()==''){
								jQuery("#tmplt_name").next("span.name_err").text('This field cannot be left blank');
						}
						else{if(!jQuery("#tmplt_name").val().match(name_regex)){
										jQuery("#tmplt_name").next("span.name_err").text('Please enter the valid template name');
								}
								else{
										jQuery("#tmplt_name").next("span.name_err").text('');
							}
						}

		});

		jQuery(document).on("blur","#clr1",function(){
				if(jQuery("#clr1").val()==''){
				jQuery("#clr1").next("span.bsclr_err").text('This field cannot be left blank');

					}
					else{
						jQuery("#clr1").next("span.bsclr_err").text('');
					}
		});

		jQuery(document).on("blur","#clr2",function(){
				if(jQuery("#clr2").val()==''){
				jQuery("#clr2").next("span.bdclr_err").text('This field cannot be left blank');

					}
					else{
						jQuery("#clr2").next("span.bdclr_err").text('');
					}
		});

		jQuery(document).on("blur","#clr3",function(){
				if(jQuery("#clr3").val()==''){
				jQuery("#clr3").next("span.bkclr_err").text('This field cannot be left blank');

					}
					else{
						jQuery("#clr3").next("span.bkclr_err").text('');
					}
		});
				jQuery(document).on("blur","#clr4",function(){
				if(jQuery("#clr4").val()==''){
				jQuery("#clr4").next("span.txclr_err").text('This field cannot be left blank');

					}
					else{
						jQuery("#clr4").next("span.txclr_err").text('');
					}
		});


jQuery("form#emailtemplate input").on('focus',function(evt) {
		jQuery('span.required').remove();
});

 jQuery("form#emailtemplate").on('submit',function(evt){

					var t_name=jQuery('.tmplt_name').val();
					var t_clr1=jQuery('#clr1').val();
					var t_clr2=jQuery('#clr2').val();
					var t_clr3=jQuery('#clr3').val();
					var t_clr4=jQuery('#clr4').val();
					var error = 0

					var name_regex = /^[a-zA-Z0-9\s-, ]+$/;
					var contact_regex = /^[0-9]+$/;

					jQuery('span.required').remove();
					if(t_name=='' || t_clr1=='' || t_clr2=='' || t_clr3=='' || t_clr4=='') {
							if(t_name==''){
									jQuery('.tmplt_name').after('<span class="required">Please enter template name.</span>');
									return false;
							 }
							 else{

								 if(!name_regex.test(t_name)){
										 jQuery('.tmplt_name').after('<span class="required">Please enter the valid template name.</span>');
										 return false;
								 }

							 }

							 if(t_clr1==''){
									jQuery('#clr1').after('<span class="required">Please select the base color.</span>');
									return false;
							}
							 if(t_clr2==''){
									jQuery('#clr2').after('<span class="required">Please select the body color.</span>');
									return false;
							}
							 if(t_clr3==''){
									jQuery('#clr3').after('<span class="required">Please select the background color.</span>');
									return false;
							}
							if(t_clr4==''){
									jQuery('#clr4').after('<span class="required">Please select the text color.</span>');
									return false;
							}
							if(t_width==''){
									jQuery('.width_err').after('<br><span class="required">Please enter the page width.</span>');
									return false;
							}
							else{
									if((!b_contact.match(contact_regex))){
										 jQuery('.width_err').after('<span class="required">Please enter the valid page width.</span>');
										 return false;
									}
							}
							evt.preventDefault();
					}
					else{
							if(!name_regex.test(t_name)){
									 jQuery('.tmplt_name').after('<span class="required">Please enter the valid template name.</span>');
									 evt.preventDefault();
							}
					}
 });
	jQuery('a.wk_seller_app_button').click(function(){
		var seller_status=this.id;
		var elm = jQuery(this);
		var status =  confirm("Are you sure you want to update the status of seller");
		if ( status ) {
				 jQuery.ajax({
							type: 'POST',
							url: the_mpadminajax_script.mpajaxurl,
							data: {"action": "wk_admin_seller_approve", "seller_app":seller_status},
							beforeSend : function(){
									elm.addClass('mp-disabled');
									elm.attr('href','');
							},
							success: function(data){
								var sel_data=data.split(':');

									if(sel_data[1]==0) {

										var this_sel_id='wk_seller_approval_mp'+sel_data[0]+'_mp1';
										this_sel_id=this_sel_id.replace(/\s+/g, '');
										jQuery('#'+seller_status).text('Disapprove');
										jQuery('#'+seller_status).attr('id',this_sel_id);

									}
									else {

											var this_sel_id='wk_seller_approval_mp'+sel_data[0]+'_mp0';
											this_sel_id=this_sel_id.replace(/\s+/g, '');
											jQuery('#'+seller_status).text('Approve');
											jQuery('#'+seller_status).attr('id',this_sel_id);

									}

									// elm.removeClass("mp-diabled");

							}
					});

				}
			});/* seller product sorting */

	if (jQuery(".return-seller select").length) {
		jQuery(".return-seller select").select2()
	}

	jQuery('select#role').on('change', function() {

		if (jQuery(this).val() == 'wk_marketplace_seller') {
			jQuery('.mp-seller-details').show();
			jQuery('#org-name').focus();
		}
		else {
			jQuery('.mp-seller-details').hide();
		}

	});

	jQuery('#org-name').on('focusout', function() {
				var value = jQuery(this).val().toLowerCase().replace(/-+/g, '').replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
				if (value == '') {
					jQuery('#seller-shop-alert-msg').removeClass('text-success').addClass('text-danger').text("Please fill shop name.");
					jQuery('#org-name').focus();
				}
				else {
					jQuery('#seller-shop-alert-msg').text("");
				}
				jQuery('#seller-shop').val(value);
		});

		jQuery('#seller-shop').on('focusout', function() {
				var self = jQuery(this);
				jQuery.ajax({
						type: 'POST',
						url: the_mpadminajax_script.mpajaxurl,
						data: {"action": "wk_check_myshop","shop_slug":self.val(),"nonce":the_mpadminajax_script.nonce},
						success: function(response)
						{
								if ( response == 0){
										jQuery('#seller-shop-alert').removeClass('text-success').addClass('text-danger');
										jQuery('#seller-shop-alert-msg').removeClass('text-success').addClass('text-danger').text("Not Available");
									}
								else if(response == 2){
										jQuery('#seller-shop-alert').removeClass('text-success').addClass('text-danger');
										jQuery('#seller-shop-alert-msg').removeClass('text-success').addClass('text-danger').text("Already Exists");
										jQuery('#org-name').focus();
									}
								else {
										jQuery('#seller-shop-alert').removeClass('text-danger').addClass('text-success');
										jQuery('#seller-shop-alert-msg').removeClass('text-danger').addClass('text-success').text("Available");
								}
						}
				});

		});

				 jQuery(document).ready(function($){

			 jQuery("#uploadButton").click(function(event) {

						var frame = wp.media({
						title: 'Select or Upload Media Of Your Chosen Persuasion',
						button: {
						text: 'Use this media'
						},
						multiple: false
						});

						frame.on( 'select', function() {
								var attachment = frame.state().get('selection').first().toJSON();
								jQuery("#img_url").val(attachment.url);
						});
						frame.open();
		});

});
jQuery(document).ready(function($){

		// Add Color Picker to all inputs that have 'color-field' class
		$(function() {
				$('#clr1').wpColorPicker();
				$('#clr2').wpColorPicker();
				$('#clr3').wpColorPicker();
				$('#clr4').wpColorPicker();
		});

});


		/* commission payment and seller payment */
		//jQuery('.alternate').on("click",".column-pay_action",function(){
		jQuery('tbody').on("click",".column-pay_action .pay",function(){

			var seller_com_id=jQuery(this).attr('id');

			if(seller_com_id){

				jQuery.ajax({
					type: 'POST',
					url: the_mpadminajax_script.mpajaxurl,
					data: {"action": "marketplace_statndard_payment", "seller_id":seller_com_id,"nonce":the_mpadminajax_script.nonce},
					success: function(data) {
						jQuery('#com-pay-ammount').html(data);
						jQuery('#com-pay-ammount').css('display','block');
						jQuery('<div class="standard-pay-backdrop">&nbsp;</div>').appendTo('body');
					}

				});

			}


		});

			jQuery('#com-pay-ammount').on('click','.standard-pay-close',function(){
							jQuery('#com-pay-ammount').hide();
							jQuery( "div" ).remove( ".standard-pay-backdrop" );
						});

			jQuery('#com-pay-ammount').on('click','#MakePaymentbtn',function(evt){

				var remain_ammount=jQuery('#com-pay-ammount').find('#mp_remain_ammount').val();
				var pay_ammount=jQuery('#com-pay-ammount').find('#mp_paying_ammount').val();
				var seller_acc=jQuery('#com-pay-ammount').find('#mp_paying_acc_id').val();
				pay_ammount = parseInt( pay_ammount );

				if( ( parseInt(remain_ammount) < parseInt( pay_ammount ) ) || ( pay_ammount <= 0 || pay_ammount == '' ) || isNaN( pay_ammount ) ) {

					if( isNaN( pay_ammount ) ) {

						jQuery('#com-pay-ammount').find('#mp_paying_ammount_error').text('Enter valid amount');

					}else{

						jQuery('#com-pay-ammount').find('#mp_paying_ammount_error').text('Sorry Account Balance is Low');

					}

				} else {

						jQuery.ajax({
							type: 'POST',
							url: the_mpadminajax_script.mpajaxurl,
							data: {"action": "marketplace_mp_make_payment", "seller_acc":seller_acc,"pay":pay_ammount,"nonce":the_mpadminajax_script.nonce},
							beforeSend : function (){

									jQuery("#MakePaymentbtn").val("Processing...").attr('disabled','true');

							},
							success: function(data) {

									if( data ) {

											if( data.error != undefined ) {

													if( data.error == 1 ){

															jQuery("#MakePaymentbtn").val("Error");
															jQuery(".wkmp-modal-footer").prepend("<p class='mp-error'>"+data.msg+"</p>");
															window.setTimeout(function(){
																location.reload();
															}, 2000);

													} else if( data.error == 0 ){

															jQuery("#MakePaymentbtn").val("Success");
															jQuery(".wkmp-modal-footer").prepend("<p class='mp-success'>"+data.msg+"</p>");

															window.setTimeout(function(){
																location.reload();
															}, 2000);


													}

											}

									}

								}

						});
				}

			})

		setTimeout(function(){
			jQuery('#wk_payment_success').remove();
		}, 5000);
		/* commission payment and seller payment */
});

jQuery(document).ready(function () {
	jQuery('.admin-order-pay').on('click', function () {
		var order_pay = jQuery(this)
		var id = jQuery(this).data('id')
		var seller_id = jQuery('#seller_id').val()
		if ( id && seller_id ) {
			jQuery.ajax({
				type: 'POST',
				url: the_mpadminajax_script.mpajaxurl,
				data: {
					"action": "mp_order_manual_payment",
					"id": id,
					"seller_id": seller_id,
					"nonce": the_mpadminajax_script.nonce
				},
				beforeSend : function (){
						order_pay.html('Processing...').attr('disabled', 'true')
				},
				success: function (response) {
					if ( response == 'done' ) {
						order_pay.replaceWith('<button class="button button-primary" disabled>Paid</button>')
						jQuery( '#notice-wrapper' ).html( '<div  class="notice notice-success is-dismissible"><p>Payment has been successfully done.</p></div>' )
					} else if ( response == 'Already Paid' ) {
						order_pay.replaceWith('<button class="button button-primary" disabled>Paid</button>')
						jQuery( '#notice-wrapper' ).html( '<div  class="notice notice-error is-dismissible"><p>Payment has been already done.</p></div>' )
					}
				},
			})
		}
	})

	// product seller assign in bulk
	if (jQuery('#mp-product-seller-select-list').length) {
		jQuery('#mp-product-seller-select-list').select2();
	}

	if (jQuery('#wkmp_seller_allowed_product_types').length) {
		jQuery('#wkmp_seller_allowed_product_types').select2();
		jQuery('#wkmp_seller_allowed_categories').select2();
	}

	if (jQuery('#wkmp_allowed_categories_per_seller').length) {
		jQuery('#wkmp_allowed_categories_per_seller').select2();
	}
})
