jQuery(document).ready(function() {
	function close_accordion_section_fnc() {
		jQuery('.accordion .accordion-section-title').removeClass('active');
		jQuery('.accordion .accordion-section-content').slideUp(300).removeClass('open');
	}
	load_accordion();
	function load_accordion(){
		   var renderData = $('#loadAccordion');
			renderData.text('Loading data from JSON source...');	
		
		$.ajax({
			 type: "GET",
			 url: "accordion.json",
			 success: function(result)
			 {
			 console.log(result.blocks);
			 var output='<div class="accordion">';	   
			 for (var i in result.blocks)
			 {
			     
			  var accordionId='accordion-'+i;
			  var activeClass= '';
			  if(i==0){
			      activeClass='active';
			  }
			  output+='<div class="accordion-section">';
			  output+='<a class="accordion-section-title '+activeClass+'" href="#'+accordionId+'">'+result.blocks[i].heading+'</a>';
			  output+='<div id="'+accordionId+'" class="accordion-section-content '+activeClass+'">';
			  output+='<p>'+result.blocks[i].content+'</p>';
			  output+='</div>';
			  output+='</div>';
			 }
			 output+="</div>";			 
			 renderData.html(output);
			 }
		 });
		
	}
	jQuery('body').on('click','.accordion-section-title', function(e) {
		// Grab current anchor value
		var currentAttrValue = jQuery(this).attr('href');

		if(jQuery(e.target).is('.active')) {
			close_accordion_section_fnc();
		}else {
			close_accordion_section_fnc();

			// Add active class to section title
			jQuery(this).addClass('active');
			// Open up the hidden content panel
			jQuery('.accordion ' + currentAttrValue).slideDown(300).addClass('open'); 
		}

		e.preventDefault();
	});
});