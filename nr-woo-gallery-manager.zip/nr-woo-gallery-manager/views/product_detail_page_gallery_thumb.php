<!-- Place somewhere in the <body> of your page -->
<div id="wgm_carousel" class="flexslider">
  <ul class="slides">
   <?php foreach( $attachment_ids as $attachment_id ) 
        {
        // Display the image URL
         $fullImagesAr = wp_get_attachment_image_src( $attachment_id,'thumbnail' ); 
         $fullImages = $fullImagesAr[0];
        // Display Image instead of URL
         //  echo wp_get_attachment_image($attachment_id, 'full');
         ?>
          <li>
            <img src="<?php echo $fullImages; ?>" />
          </li>
      <?php  } ?>
    <!-- items mirrored twice, total of 12 -->
  </ul>
</div>