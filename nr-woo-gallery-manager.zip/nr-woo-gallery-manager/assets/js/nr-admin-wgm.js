   jQuery(function(){

  jQuery('body').on('submit','#wgm_form',function(){
   	  var formData=jQuery(this).serialize();
      jQuery.ajax({
         type:"POST",
         url: nrWooObj.ajaxurl,
         data:formData,
         beforeSend:function(){
         	jQuery('.loading').show();
         },
         success:function(data){
         	jQuery('.loading').hide();
         	jQuery('.message').text(data);
         }

         });
      return false;
      });   
   });