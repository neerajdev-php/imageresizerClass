jQuery(function(){

   jQuery('#wgm_carousel').flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: false,
        slideshow: false,
        itemWidth: 210,
        itemMargin: 5,
        asNavFor: '#wgm_slider'
      });

      jQuery('#wgm_slider').flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: false,
        slideshow: false,
        sync: "#wgm_carousel",
        start: function(slider){
          $('body').removeClass('loading');
        }
      });

});