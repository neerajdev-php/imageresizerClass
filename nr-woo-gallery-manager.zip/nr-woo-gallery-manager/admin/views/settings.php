<?php 
   $settings = unserialize(get_option('wgm_settings'));
   $settings= !empty($settings['wgm']) ? $settings['wgm'] : array();
 ?>

<form name="wgm_form" id="wgm_form">
<div class="message"></div>

<table class="form-table">
   <tbody>
      <tr valign="top">
         <th scope="row" class="titledesc">
            <label for="product_gallery_enable">Override Product Gallery?</label>
            <span class="woocommerce-help-tip"></span>						
         </th>
         <td class="forminp">
            <input type="checkbox" name="wgm[product_gallery_enable]" <?php if($settings['product_gallery_enable']=="on"){?>checked="checked"  <?php } ?> > 
            <small>If you enabled then it product gallery in single page will override with new gallery.</small>			
         </td>
      </tr>

      <tr valign="top">
         <th scope="row" class="titledesc">
            <label for="product_gallery_enable">Shortcode</label>
            <span class="woocommerce-help-tip"></span>                  
         </th>
         <td class="forminp">
              <code>[PRODUCT_GALLERY_VIEWER]</code>
            <small>You can display product gallery separately using this shortcode in product text editor.</small>        
         </td>
      </tr>

   </tbody>
</table>
<input type="submit" name="submit" id="submit_wgm" value="Save" class="button-primary">
<input type="hidden" name="action" value="wgm_save_settings">
<div class="loading" style="display: none;">Please Wait...</div>
</form>