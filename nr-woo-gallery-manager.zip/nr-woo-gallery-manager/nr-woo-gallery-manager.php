<?php 
/*
Plugin Name: NR Woo Gallery Manager
Plugin URI: http://nrtechwebsolution.com
Description: This plugin will give you many galleries option for woocommerce products.
Author: Neeraj Chaturvedi
Text Domain: nr-plugins
Version: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Author URI: http://nrtechwebsolution.com
*/
if ( ! defined( 'NR_PLUGIN_URL' ) ) {
define( 'NR_PLUGIN_URL', plugins_url( '/', __FILE__ ) );
}

if ( ! defined( 'NR_FRONT_URL' ) ) {
define( 'NR_FRONT_URL', get_template_directory()."/Nr_WGM/views/" );
}



if ( ! defined( 'NR_PLUGIN_ASSETS_URL' ) ) {
define( 'NR_PLUGIN_ASSETS_URL', NR_PLUGIN_URL . 'assets/' );
}
class Nr_Woo_Galley_Manager{

		function __construct(){
                //add_action( 'woocommerce_before_single_product_summary', 'wooswipe_woocommerce_show_product_thumbnails', 20 );

				//override_product_gallery

				add_action('wp_ajax_wgm_save_settings',array($this,'wgm_save_settings'));
				add_action('wp_ajax_nopriv_wgm_save_settings',array($this,'wgm_save_settings'));

			    add_action('admin_menu', array($this,'register_custom_menu'),99);

			    add_action( 'woocommerce_before_single_product_summary',array($this,'override_product_gallery'), 20 );
				add_action( 'wp_enqueue_scripts', array($this,'nr_load_script') );
				add_action( 'admin_enqueue_scripts', array($this,'nr_load_script_admin')  );
				add_shortcode( 'PRODUCT_GALLERY_VIEWER', array($this,'render_tpl_product_gallery_detail_page') );
			}

			public function register_custom_menu() {
			    add_submenu_page( 'woocommerce', 'Woo Gallery Manager', 'Woo Gallery Manager', 'manage_options', 
			    	'wgm_custom_submenu',array($this,'wgm_custom_submenu') );
			}
			public function wgm_custom_submenu() {
					echo '<h3>Woo Gallery Manager</h3>';
					include("admin/views/settings.php");
			}

	/**
		 * Javascript for Load More
		 *
		 */

		public function nr_load_script_admin(){
			wp_enqueue_script( 'nr-admin-wgm-js', plugins_url('assets/js/nr-admin-wgm.js', __FILE__), array( 'jquery' ), '1.0', true );
			$args = array(
				'ajaxurl'   => admin_url( 'admin-ajax.php' ),
			);	
			wp_localize_script( 'nr-admin-wgm-js', 'nrWooObj', $args );
		}

		public function nr_load_script() {
			global $wp_query;
			$args = array(
				'url'   => admin_url( 'admin-ajax.php' ),
			);	
			wp_enqueue_style( 'nr-woo-css', NR_PLUGIN_ASSETS_URL . 'css/flexslider.css' );				
			wp_enqueue_script( 'nr-woo-js', NR_PLUGIN_ASSETS_URL . 'js/jquery.flexslider.js', array( 'jquery' ), '1.0', true );

			wp_enqueue_script( 'nr-custom-wgm-js', NR_PLUGIN_ASSETS_URL . 'js/custom_wgm.js', array( 'jquery' ), '1.0', true );	
			wp_localize_script( 'nr-woo-js', 'nrWooObj', $args );

			
		}
		public function override_product_gallery(){

			$settings= $this->get_options();
			if($settings['product_gallery_enable']=="on"){
                global $post;
				$product_id = $post->ID;
				$product = new WC_product($product_id);
				$attachment_ids = $product->get_gallery_image_ids();
				$html='';
				ob_start();
				if(  file_exists(NR_FRONT_URL."product_detail_page_gallery_shortcode.php")){
					include(NR_FRONT_URL."product_detail_page_gallery_shortcode.php");
				}else{
					include("views/product_detail_page_gallery_shortcode.php");
				}
				
				$html.=ob_get_contents(); 
				ob_get_clean();
				echo  $html;
			}else{
				return true;
			}


		}

    	public function render_tpl_product_gallery_detail_page(){
    			global $post;
				$product_id = $post->ID;
				$product = new WC_product($product_id);
				$attachment_ids = $product->get_gallery_image_ids();
				$html='';
				ob_start();
				if(  file_exists(NR_FRONT_URL."product_detail_page_gallery_shortcode.php")){
					include(NR_FRONT_URL."product_detail_page_gallery_shortcode.php");
				}else{
					include("views/product_detail_page_gallery_shortcode.php");
				}
				
				$html.=ob_get_contents(); 
				ob_get_clean();
				return $html;
    	}


    	public function wgm_save_settings(){
    		unset($_POST['action']);
    		
    		if(update_option('wgm_settings',serialize($_POST))){
    			echo "Settings saved!";
    		}else{
    			echo "Opps something went wrong,Please try again.";
    		}
    		
    		die;
    	}

    public function get_options(){
    	  $settings = unserialize(get_option('wgm_settings'));
          $settings= !empty($settings['wgm']) ? $settings['wgm'] : array();
          return $settings;
    }	
}

$nrWooObjs=new Nr_Woo_Galley_Manager();
$wgm_settings= $nrWooObjs->get_options();
add_action('init','remove_actions_dev');
function remove_actions_dev(){
	global $wgm_settings;

	if( $wgm_settings['product_gallery_enable']=="on"){
		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images',20 );
	}	
}

?>