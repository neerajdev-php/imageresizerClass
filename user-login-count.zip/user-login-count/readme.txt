=== Plugin Name ===
Contributors: tkgupta
Tags: users, login,count
Requires at least: 3.2
Tested up to: 4.9.6


Add a sortable column to the users list to show user login count.

== Description ==

This plugin adds a new, sortable, column to the users lists, which shows the user login count they login.


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the `user-login-count` directory to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.



== Frequently Asked Questions ==



== Screenshots ==

1. Sample output
