import { Component, OnInit ,OnDestroy } from '@angular/core';
import { Customer } from '../customer';
import { DataService } from '../data.service';

import * as $ from 'jquery';
import 'datatables.net';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss']
})
export class CustomersComponent implements OnInit {

  customers: Customer[];
  

 
  
  constructor(private dataService: DataService) { }

   getCustomers() {
     return this.dataService.getCustomers()
        .then(customers => this.customers = customers,
        
        );
	}

  ngOnInit() {

    this.getCustomers();

  }


  


}
