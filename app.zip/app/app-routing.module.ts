import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';     // Add this
import { AboutComponent } from './about/about.component';  // Add this
import { ContactComponent } from './contact/contact.component';  // Add this
import { CustomersComponent } from './customers/customers.component';  // Add this
import { CustomerDetailsComponent } from './customer-details/customer-details.component';

import { LoginComponent } from './login/login.component';  // Add this
import { RegisterComponent } from './register/register.component';  // Add this

const routes: Routes = [
  { path: '',component: HomeComponent},
  { path: 'about/:id',component: AboutComponent},
  { path: 'contact',component: ContactComponent},
  { path: 'users',component: CustomersComponent},
  { path: 'detail/:id', component: CustomerDetailsComponent },
  { path: 'login',component: LoginComponent},
  { path: 'register', component: RegisterComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
