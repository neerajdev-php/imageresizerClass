import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl,Validators,FormBuilder} from '@angular/forms';
import { DataService } from '../data.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  registerform: FormGroup;
  fullName: FormControl;
  email: FormControl;
  contact: FormControl;
  address:FormControl;
  password: FormControl;
  
  constructor(private fb: FormBuilder , private dataService: DataService) { 

  }

  ngOnInit() {
  	this.createFormControls();
    this.createForm();
    }

  createFormControls() {
    this.fullName = new FormControl('', Validators.required);
    this.email = new FormControl('', [
      Validators.required,
      Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
    ]);
   

    this.contact = new FormControl('', [
      Validators.required,
      Validators.maxLength(12),
      Validators.pattern('[0-9]*'),
    ]);



    this.address = new FormControl('', Validators.required);
    this.password = new FormControl('', [
      Validators.required,
      Validators.minLength(8)
    ]);

    
  }

  createForm() {
    this.registerform = new FormGroup({
      name: new FormGroup({
        fullName: this.fullName,
       }),
      email: this.email,
      contact: this.contact,
      address: this.address,
      password: this.password,
     
    });
  }

  onSubmit() {

 	if (this.registerform.valid) {
 		 
 		addUser(){
		 this.dataService.addUser(this.registerform.value)
          .subscribe(data => {alert("Succesfully Added Product details")},
	          Error => {alert("failed while adding product details")})
		}
    }

   this.registerform.reset();
  }

}
