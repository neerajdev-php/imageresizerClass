export class Customer {

  id                 : number;
  full_name          : string;
  user_specification : string;
  user_expertise     : string;
  thumb_image        : string;
  address            : string;
  email_id			 : string;
  mobile			 : string;
  user_experience	 : string;
  user_fellowships	 : string;
  user_highlights	 : string;
  user_image	     : string;
  user_languages	 : string;

}
