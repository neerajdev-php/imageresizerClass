import { Component, OnInit, Input } from '@angular/core';
import { Customer } from '../customer';
import { DataService } from '../data.service';
import { ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.scss']
})
export class CustomerDetailsComponent implements OnInit {

	customer = new Customer() ;
  submitted = false;

  constructor(

  	private dataService: DataService,
    private route: ActivatedRoute,
    private location: Location

  ) { }

 ngOnInit(): void {
   
  this.route.params.forEach((params: Params) => {
      if (params['id'] !== undefined) {
        let id = +params['id'];
        this.dataService.getCustomer(id)
            .then(customer => this.customer = customer);
      } 
    });
  }

  goBack(): void {
    this.location.back();
  }

}
