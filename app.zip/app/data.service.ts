import { Injectable } from '@angular/core';
import { Headers, Http ,Response } from '@angular/http';
import { ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { Observable } from 'rxjs';

import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private customersUrl = 'userList'; 
  private customersdetailsUrl = 'details'; 
  private registrationUrl = 'register'; 
  private headers = new Headers({'Content-Type': 'application/json'});

 constructor(private http: Http) { }

  // Get all customers
  getCustomers(): Promise<Customer[]> {
    return this.http.get(this.customersUrl)
               .toPromise()
               .then(response => response.json().data as Customer[])
               .catch(this.handleError);
  }

  // get user details

  getCustomer(id): Promise<Customer> {
    let postData = new FormData();
    postData.append('user_id' , id);
   return this.http.post(this.customersdetailsUrl,postData)
      .toPromise()
      .then(response => response.json().data as Customer)
      .catch(this.handleError);
  }

  // user register here 

  addUser(data){

      console.log(data);
      console.log(222);
      return this.http.post(this.registrationUrl,data)
      .map((response: Response) =>
      {
        console.log (response.json());
      })
  }

    private handleError(error: any): Promise<any> {
    console.error('Error', error); // for demo purposes only
    return Promise.reject(error.message || error);
  }

}
