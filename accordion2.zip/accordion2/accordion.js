jQuery(document).ready(function() {
	/*Close accordion on click*/
	function close_accordion_section_fnc() {
		jQuery('.accordion .accordion-section-title').removeClass('active');
		jQuery('.accordion .accordion-section-title i').removeClass('icon_open').addClass('icon_close');
		jQuery('.accordion .accordion-section-content').slideUp(300).removeClass('open');
	}

	/*Load very first time load*/
	load_accordion();
	function load_accordion(){
		   var renderData = $('#loadAccordion');
			renderData.text('Loading data from JSON source...');	
		
		$.ajax({
			 type: "GET",
			 url: "accordion.json",
			 success: function(result)
			 {
			 console.log(result.blocks);
			 var output='<div class="accordion">';	   
			 for (var i in result.blocks)
			 {
			     
			  var accordionId='accordion-'+i;
			  var activeClass= '';
			  var activeIconClass= '';
			  var activeIconText= '';
			  if(i==0){
			      activeClass='active';
			      activeIconClass='icon_open';
			      activeIconText='';
			  }else{
			  	  activeIconClass='icon_close';
			      activeIconText='';
			  }

			  console.log(activeIconText);
			  output+='<div class="accordion-section">';
			  output+='<a class="accordion-section-title '+activeClass+'" href="#'+accordionId+'">'+result.blocks[i].heading+'<i class="icon_commnon '+activeIconClass+'">'+activeIconText+'</i></a>';
			  output+='<div id="'+accordionId+'" class="accordion-section-content '+activeClass+'">';
			  output+='<p>'+result.blocks[i].content+'</p>';
			  output+='</div>';
			  output+='</div>';
			 }
			 output+="</div>";			 
			 renderData.html(output);
			 }
		 });
		
	}
	jQuery('body').on('click','.accordion-section-title', function(e) {
		// Grab current anchor value
		var currentAttrValue = jQuery(this).attr('href');

		if(jQuery(e.target).is('.active')) {
			close_accordion_section_fnc();
		}else {
			close_accordion_section_fnc();

			// Add active class to section title
			jQuery(this).addClass('active');
			jQuery(this).children('i').removeClass('icon_close');
			jQuery(this).children('i').removeClass('icon_open');
			jQuery(this).children('i').addClass('icon_open');
			// Open up the hidden content panel
			jQuery('.accordion ' + currentAttrValue).slideDown(300).addClass('open'); 
		}

		e.preventDefault();
	});
});