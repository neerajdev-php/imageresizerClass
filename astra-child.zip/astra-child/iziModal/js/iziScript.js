
function confirm_moda(){
  var status = confirm("Are you sure?");
  return status;
}

jQuery(function($) 
{
  jQuery('#invite-anyone-personal-li a').attr('href','javascript:void(0)');
  jQuery("#shop-personal-li a").attr('target', '_blank');
  jQuery('#menu-item-21631 a').attr('href','javascript:void(0)');
  jQuery('#create-personal-li a').attr('href','javascript:void(0)');

var ajaxurl= rwbObj.ajaxurl;
var getLogoUrl=jQuery('#header-logo').find('img').attr('src');

    function tmce_setContent(content, editor_id, textarea_id) {
      if ( typeof editor_id == 'undefined' ) editor_id = wpActiveEditor;
      if ( typeof textarea_id == 'undefined' ) textarea_id = editor_id;
      
      if ( jQuery('#wp-'+editor_id+'-wrap').hasClass('tmce-active') && tinyMCE.get(editor_id) ) {
        return tinyMCE.get(editor_id).setContent(content);
      }else{
        return jQuery('#'+textarea_id).val(content);
      }
    }



    $('[data-popup-close]').on('click', function(e)  {
        var targeted_popup_class = 'popup-1';
        $('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
 
        e.preventDefault();
    });
   jQuery('body').on('click','.dropdown-activity-meta-icon',function(){
        var $this= jQuery(this);
        jQuery('.activity-meta,.acomment-options').hide();
         $this.addClass('dropdown-activity-active');
        $this.next().show();
   });

   jQuery('body').on('click','.dropdown-activity-active',function(){
        var $this= jQuery(this);
        jQuery('.activity-meta,.acomment-options').hide();
                $this.removeClass('dropdown-activity-active');
        $this.next().hide();
   });



if(jQuery('#single_booking_box').length){
  
  jQuery('.event_add_btn').click(function(){
    jQuery('#single_booking_box').show();
    jQuery  ('html, body').animate({
        scrollTop: $("#single_booking_box").offset().top
    }, 2000);
  });
  jQuery('.close_booking_box').click(function(){         
             jQuery('#single_booking_box').hide();
             jQuery('html, body').animate({
                    scrollTop: $(".event-custom-header-box").offset().top
                }, 2000);
    });
}
           // jQuery('.radio-toggle').toggleInput();



/*
  setTimeout(function(){
    console.log('ss');
      var getMonthName= jQuery('.fc-center').text();
      var el1 = document.querySelector('.fc-prev-button');

      // here we create an adjacent element from the string of HTML,
      // the 'afterend' argument states that this adjacent element
      // follows the el1 node, rather than preceding it or appearing
      // within:
      el1.insertAdjacentHTML('afterend', '<div class="fc-month-name"><h2>'+getMonthName+'</h2></div>');
      var getButtonsDiv= jQuery('.fc-button-group').html();
      jQuery('.fc-center').html(getButtonsDiv);
      jQuery('.fc-button-group').html('');


  },700);
*/
    jQuery('body').on('click','.action_toggle',function(){
      jQuery(this).removeClass('action_toggle').addClass('action_remove_toggle');
      jQuery(this).next().show();
        
    });
    jQuery('body').on('click','.action_remove_toggle',function(){
      jQuery(this).removeClass('action_remove_toggle').addClass('action_toggle');
      jQuery(this).next().hide();
        
    });




    jQuery('#menu-main-navigation').slicknav({
      label:'',
      closedSymbol: '&#9658;',
      openedSymbol: '&#9660;',
      brand:'<a href="/" target="_self" itemprop="url"><img class="fl-photo-img wp-image-19944 size-full" src="'+getLogoUrl+'" alt="logo" itemprop="image" height="111" width="558" sizes="(max-width: 558px) 100vw, 558px"></a>',
      afterOpen:function(){
         if(!jQuery('.slicknav_nav').hasClass('slicknav_hidden')){
            jQuery('.slicknav_icon').html('<span>X</span>');
         }
      },
      afterClose:function(){
         if(jQuery('.slicknav_nav').hasClass('slicknav_hidden')){
            jQuery('.slicknav_icon').html('<span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span>');
         }
      },
    });   

   /* notifaction code here */
  jQuery('.mark_read_unread a').click(function(){

      var  type  = jQuery(this).attr('data-action');
      var  userId  = jQuery(this).attr('data-id');
      var  noti_id = [];
      jQuery('.notification-check').each(function(){
         noti_id.push(jQuery(this). val());       
      });
      if(noti_id.length){
         jQuery.ajax({
         type: "post",
         dataType:'json',
         data: "action=custom_mark_read_unread_notification&type="+type+"&userId="+userId+"&noti_id="+noti_id,
         url: ajaxurl,       
          success: function( data ) {
           if(data.msg == 'sucess'){            
              jQuery('.notification-check').each(function(){
                  var fadeoutId  = jQuery(this). val();
                  jQuery('.hide_noti_'+fadeoutId).fadeOut('slow');            
                  });
                 location.reload();            }

          }
      });
      }else{
        jQuery('.mark_read_unread a').attr("disabled", true);
      }
  });
  jQuery('.delete_all_read_unread a').click(function(){    
      var  userId  = jQuery(this).attr('data-id');
      var  noti_id = [];
      jQuery('.notification-check').each(function(){
         noti_id.push(jQuery(this). val());       
      });

    //if(confirm_modal()){

      if(noti_id.length){
         jQuery.ajax({
         type: "post",
         dataType:'json',
         data: "action=custom_delete_read_unread_notification&noti_id="+noti_id+"&userId="+userId,
         url: ajaxurl,       
          success: function( data ) {
           if(data.msg == 'sucess'){            
              jQuery('.notification-check').each(function(){
                  var fadeoutId  = jQuery(this). val();
                  jQuery('.hide_noti_'+fadeoutId).fadeOut('slow');            
                  });
                 location.reload();
              }
          }
       });
      }else{
        jQuery('.delete_all_read_unread a').attr("disabled", true);
      }

    //}

  });

  /* delete inbox and sent message here */
  jQuery('.delete_all_read_unread_message a').click(function(){
      var  userId     = jQuery(this).attr('data-user');
      var  message_id = [];
      jQuery('.message-check').each(function(){
         message_id.push(jQuery(this). val());       
      });
       //if(confirm_modal()){
      if(message_id.length){
         jQuery.ajax({
         type: "post",
         data: "action=custom_delete_message&message_id="+message_id+"&userId="+userId,
         url: ajaxurl,       
          success: function( data ) {
           if(data ==  '1'){            
                location.reload();
              }
          }
      });
      }else{
        jQuery('.delete_all_read_unread_message a').attr("disabled", true);
      }
    //}


    });

    jQuery('.edit_news_section').click(function(){
      jQuery('.my_custom_news_edit_button').toggle();
    });

    jQuery('.edit_events_front > a').click(function(){
      jQuery('.event_meta_actions').toggle();
    });


    jQuery('a.prevoius_page').click(function(){
      parent.history.back();
      return false;
    });

  /* delete user created topic */
  jQuery('.remove_forum_topic a').click(function(){
     var topic_id   = jQuery(this).attr('data-id');
        //if(confirm_modal()){
            jQuery.ajax({
                 type: "post",
                 data: "action=custom_delete_user_created_topic&topic_id="+topic_id,
                 url: ajaxurl,       
                 success: function( data ) { 
                        window.location= rwbObj.profile_forums;
                      }
                    });
         // }
    });


  /* delete user created event */
  jQuery('.delete_em_single').click(function(){
     var post_id   = jQuery(this).attr('data-post-id');
     var event_id   = jQuery(this).attr('data-em-id');
         //if(confirm_modal()){
          jQuery.ajax({
             type: "post",
             data:{
              action: "custom_delete_user_created_event",
              post_id: post_id,
              event_id:event_id,
             },
             url: ajaxurl,       
             success: function( data ) {
                    location.reload();
                  }
                });
         //}
    }); 
    jQuery('#latest_photo').owlCarousel({
              loop:true,
              margin:5,
              responsiveClass:true,
              responsive:{
                  0:{
                      items:2,
                      nav:true
                  },
                  600:{
                      items:5,
                      nav:false
                  },
                  1000:{
                      items:8,
                      nav:true,
                      loop:false
                  }
              }
          });

        /* slider sponsor */

        /*jQuery(document).ready(function() {


          jQuery('.owl-carousel').owlCarousel({
                        loop:true,
                        items : 4, 
                        margin:20,
                        autoplay: true,
                        autoplayTimeout: 3000,
                        responsiveClass:true,
                        autoWidth:true,               
        });

      }); */


        jQuery(document).ready(function() {
 
            jQuery("#owl-demo").owlCarousel({
                items : 4, //10 items above 1000px browser width
                autoplay: true,
                autoplayTimeout: 3000,
                margin:20,                                                                  
                loop:true,
                itemsDesktop : [1000,4], //5 items between 1000px and 901px
                itemsDesktopSmall : [900,1], // betweem 900px and 601px
                itemsTablet: [600,1], //2 items between 600 and 0;
                itemsMobile : false // itemsMobile disabled - inherit from itemsTablet option
            });
 
});




/* Add Friend Request Js code*/

  jQuery('.add_custom_friends >a').click(function(){ 
    jQuery('.add_friend').val("");
    jQuery('#popup_add_friend_code .popup').show();
    jQuery('#popup_add_friend_code .popup_label').text('Add New Friend').show();
    return false;
  });

  jQuery('body').on('submit','#add_friend',function()
  {
    jQuery('.alert-empty').hide();
    var name = jQuery('#search-box').val();
    if(name == '' || name == 'undefined')
    {
      jQuery('.alert-empty').show();
      jQuery('.alert-empty').text('Please Fill Username').addClass('alert alert-red');
      return false;
    }
    var formData = new FormData(jQuery(this)[0]);
    jQuery('.error_alredy').text('');
    jQuery.ajax({
        type:"POST",
        url: ajaxurl,
        data:formData,
        dataType: "json",
        async: false,
      cache: false,
      dataType: "json",
      contentType: false,
      processData: false,
        success:function(res){
          if(res.status == 'fail')
          {
            jQuery('.error_alredy').text(res.msg).addClass('alert alert-red');
          }else{
            jQuery('.sucess_asdded').text(res.msg).addClass('alert alert-blue');
          }
        }
    });
    return false;
  });
jQuery('body').on('click','#add_friend',function()
  {
    jQuery('.alert-empty').hide();
    /*jQuery('.error_alredy').hide();
    jQuery('.sucess_asdded').hide();*/
  });

  jQuery( "#search-box" ).autocomplete(
  {
    source: function( request, response ) 
    {
      jQuery('#search-box').addClass('image_loader_friend');
            jQuery.ajax({
              type : 'POST',
                url: ajaxurl,
                data:{
                  action : "get_custom_user_name_auto",
                  uname:request.term
                },
                success: function(data) 
                {
                  jQuery('#search-box').removeClass('image_loader_friend');
                  data = jQuery.parseJSON(data);
                    response(data.items);
                },
                error: function(data) 
                {
                  jQuery('#search-box').removeClass('image_loader_friend');
                }
            });
        },
    minLength: 1,
    open: function() {},
    close: function() {},
    focus: function(event,ui) {},
    select: function(event, ui){
      jQuery('#userid').val(ui.item.id);
    }
  });


/* Add Friend Request Js code*/


/*Add Friend Share code*/
jQuery('.share_post_activity').click(function(){ 
    var pid  = jQuery(this).attr('data-id');
    jQuery('.add_friend1_uname').val("");
    jQuery('#shareId').val(pid);
    jQuery('#popup_add_friend_share .popup').show();
    jQuery('#popup_add_friend_share .popup_label').text('Share post to Friend').show();
    return false;
  });

  jQuery('body').on('submit','#add_share',function()
  {
    jQuery('.alert-empty').hide();
    var name = jQuery('#search-box1').val();
    var actId = jQuery('#return_activity_id').val();
    jQuery('.sucess_asdded').text("");
    if(actId !=''){

      jQuery('.alert-empty').show();
      jQuery('.alert-empty').text('you have already Shared this post').addClass('alert alert-red');
      return false;
    }
    if(name == '' || name == 'undefined')
    {
      jQuery('.alert-empty').show();
      jQuery('.alert-empty').text('Please Fill Username').addClass('alert alert-red');
      return false;
    }
    var formData = new FormData(jQuery(this)[0]);
    jQuery('.error_alredy').text('');
    jQuery.ajax({
        type:"POST",
        url: ajaxurl,
        data:formData,
        dataType: "json",
        async: false,
      cache: false,
      dataType: "json",
      contentType: false,
      processData: false,
        success:function(res){
          if(res.status == 'fail')
          {
            jQuery('.error_alredy').text(res.msg).addClass('alert alert-red');
          }else{
            jQuery('#add_share')[0].reset()
            jQuery('#return_activity_id').val(res.returnId);
            jQuery('.sucess_asdded').text(res.message).addClass('alert alert-blue');
          }
        }
    });
    return false;
  });


jQuery('body').on('click','#add_share',function()
  {
    jQuery('.alert-empty').hide();
    /*jQuery('.error_alredy').hide();
    jQuery('.sucess_asdded').hide();*/
  });

  jQuery( "#search-box1" ).autocomplete(
  {
    source: function( request, response ) 
    {
      jQuery('#search-box1').addClass('image_loader_friend');
            jQuery.ajax({
              type : 'POST',
                url: ajaxurl,
                data:{
                  action : "get_custom_user_name_auto",
                  uname:request.term
                },
                success: function(data) 
                {
                  jQuery('#search-box1').removeClass('image_loader_friend');
                  data = jQuery.parseJSON(data);
                    response(data.items);
                },
                error: function(data) 
                {
                  jQuery('#search-box1').removeClass('image_loader_friend');
                }
            });
        },
    minLength: 1,
    open: function() {},
    close: function() {},
    focus: function(event,ui) {},
    select: function(event, ui){
      jQuery('#userid1').val(ui.item.id);
    }
  });


/*Add Friend Share code*/

/*Add/Edit News code*/
jQuery('.add_new_news').click(function(){ 
      //jQuery('#request_new_message_section').addClass('hide_section');
        //jQuery('#popup_add_edit_discount_code').removeClass('hide_section');
         tmce_setContent('', 'news_description', 'news_description');
        jQuery('.update_code_news').val("");
              jQuery('.type_code_news').val("");
        jQuery('.edit_news_title').val("");
              jQuery('.news_cate').val("");
              jQuery('.edit_news_desc').val("");
              jQuery('.edit_news_logo').attr('src',"");
        jQuery('#news_logo').prop('required',true);
        jQuery('#popup_add_edit_news_code .popup').show();
        jQuery('#popup_add_edit_news_code .popup_label').text('Add New').show();
        //jQuery('#popup_add_edit_discount_code .popup_sub_label').text('Become a part of Tri community!');

      return false;
     });

      jQuery('body').on('submit','#news_add_edit',function(){
      var formData = new FormData(jQuery(this)[0]);
      jQuery.ajax({
            type:"POST",
            url: ajaxurl,
            data:formData,
            dataType: "json",
            async: false,
          cache: false,
          dataType: "json",
          contentType: false,
          processData: false,
            beforeSend:function(){
              jQuery('#popup_add_edit_news_code .popup_warnings').addClass('ast-alert-info').text('Please wait...');
            },
            success:function(res){
              console.log(res);
              if(res.status=="fail"){
                           jQuery('#popup_add_edit_news_code .popup_warnings').removeClass('ast-alert-info').addClass('ast-alert-danger').text(res.message);
              }else{
                 jQuery('#popup_add_edit_news_code .popup_warnings').removeClass('ast-alert-info').removeClass('ast-alert-danger').addClass('ast-alert-success').text(res.message);

                  jQuery('#news_add_edit')[0].reset();
                jQuery('#popup_add_edit_news_code .popup_label').hide();     
                  jQuery('#popup_add_edit_news_code .popup_sub_label').hide();              
                    jQuery('#request_new_message_section').removeClass('hide_section');
                    jQuery('.news_join_section').addClass('hide_section');
                window.location.reload();
              }
              
            }
        });
        return false;
     });
  jQuery('body').on('click','.news_edit',function(){

           var id1    = jQuery(this).attr('data-id');
           var type1  = jQuery(this).attr('data-type');

           jQuery.ajax({
               type:"POST",
               url: ajaxurl,
               dataType: "json",
               data: {"action": "update_fronten_news_data", 'id':id1 },
               success:function(res){
                  if(res.status=="fail"){
                  }else{
                       jQuery('.update_code_news').val(id1);
                       jQuery('.type_code_news').val(type1);
                       jQuery('.edit_news_title').val(res.news_title);
                       jQuery('.news_cate').val(res.news_cat).prop('selected', true);                    

                        /* var activeEditorNews = tinyMCE.get('news_description');
                         activeEditorNews.setContent(res.news_desc);*/
                          tmce_setContent(res.news_desc, 'news_description', 'news_description');

                       jQuery('.edit_news_logo').attr('src',res.news_image);
                       jQuery('#news_logo').removeAttr("required");
                       jQuery('#popup_add_edit_news_code .popup').show();
                       jQuery('#popup_add_edit_news_code .popup_label').text('Update News').show();
                  }
               }
           });

          return false;
       }); 

      jQuery('.news_delete').click(function(){
         var id    = jQuery(this).attr('data-id');
         //if(confirm_modal()){ 
           jQuery.ajax({
               type:"POST",
               url: ajaxurl,
               dataType: "json",
               data: {"action": "delete_news_data", 'id':id },
               success:function(res){
                  console.log(res);
                  if(res.status=="fail"){
                  }else{
                     jQuery('.hide_news_'+id).fadeOut('slow');
                     window.location.reload();
                  }
               }
           });
       //}
      });

/*Add/Edit News code*/

/*Login Code*/

    function getUrlVars() {
        var vars = {};
        var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi,    
        function(m,key,value) {
          vars[key] = value;
        });
        return vars;
      }
        paramsObj= getUrlVars();

        //console.log(paramsObj);
    
      if( paramsObj.err=='not_exist' || paramsObj.err=='not_exist#_=_' || paramsObj.err=='not_exist#' ){

        jQuery('#popup_login > .popup').show();

        jQuery('#popup_login .popup_warnings').addClass('ast-alert-danger').text('You are not authorized');

      }

        jQuery('.bp-login-nav > a').click(function(){
          //alert('sss');
          //return false;
        jQuery('#popup_login .popup_warnings').text('');
        jQuery('#popup_login .popup_label').text('Login').show();
        jQuery('#popup_login .popup_sub_label').text('');
        jQuery('#login_frm_section').removeClass('hide_section');       
        jQuery('#forget_frm_section').addClass('hide_section');
        jQuery('#forget_message_section').addClass('hide_section');

        jQuery('#popup_login > .popup').show();
        return false;
     });

     jQuery('.forget_pass_btn').click(function(){
      jQuery('#popup_login .popup_warnings').text('');
      var sectionId=jQuery(this).data('section');
        jQuery(sectionId).removeClass('hide_section');
        jQuery('#login_frm_section').addClass('hide_section');
        jQuery('#popup_login .popup_label').text('Forgot your password?').show();
        jQuery('#popup_login .popup_sub_label').text("Don't worry, we all forget things.");
       return false;
     });
/*     jQuery('.login_pass_btn').click(function(){
      jQuery('#popup_login .popup_warnings').text('');
      var sectionId=jQuery(this).data('section');
        jQuery(sectionId).removeClass('hide_section');
        jQuery('#forget_frm_section').addClass('hide_section');
        jQuery('#popup_login .popup_label').text('Login').show();
        jQuery('#popup_login .popup_sub_label').text('');
       return false;
     });
*/
     jQuery('body').on('submit','#login_frm',function(){
      jQuery('#popup_login .popup_warnings').text('');
        var formData= jQuery(this).serialize();
        jQuery.ajax({
            type:"POST",
            url: ajaxurl,
            data:formData,
            dataType: "json",
            beforeSend:function(){
              jQuery('#popup_login .popup_warnings').addClass('ast-alert-info').text('Please wait...');
            },
            success:function(res){
              console.log(res);
              if(res.status=="fail"){
                           jQuery('#popup_login .popup_warnings').removeClass('ast-alert-info').addClass('ast-alert-danger').text(res.message);
              }else{
                jQuery('#popup_login .popup_warnings').removeClass('ast-alert-danger').addClass('ast-alert-success').text('Redirecting to account..');
                setTimeout(function(){

                  window.location=res.url;
                },400);
              }
              
            }
        });
        return false;
     });

     jQuery('body').on('submit','#forget_frm',function(){
       jQuery('#popup_login .popup_warnings').text('');
        var formData= jQuery(this).serialize();
        jQuery.ajax({
            type:"POST",
            url: ajaxurl,
            data:formData,
            dataType: "json",
            beforeSend:function(){
              jQuery('#popup_login .popup_warnings').addClass('ast-alert-info').text('Please wait...');
            },
            success:function(res){
              if(res.status=="fail"){
                           jQuery('#popup_login .popup_warnings').removeClass('ast-alert-info').addClass('ast-alert-danger').text(res.message);
              }else{
                jQuery('#popup_login .popup_warnings').hide();
                jQuery('#popup_login .popup_label').hide();
                jQuery('#popup_login .popup_sub_label').hide();
                  jQuery('#login_frm_section,#forget_frm_section').addClass('hide_section');
                jQuery('#forget_message_section').removeClass('hide_section');
              }
              
            }
        });
        return false;
     });

     jQuery('.popup_close,popup-close').click(function(){
        jQuery('.popup').hide();
        window.reload();
     });

/*Login Code*/

if(jQuery("#bbp_forum_parent_id").length){

  jQuery("#bbp_forum_parent_id option:first").val('-1');

}

  
  /* delete forum thread*/


   
  jQuery('.forum_delete').click(function(){
     var forum_id   = jQuery(this).attr('data-id');


    //if(confirm_modal()){
            jQuery.ajax({
                 type: "post",
                 data: "action=custom_delete_user_created_forum&forum_id="+forum_id,
                 url: ajaxurl,       
                 success: function( data ) {
                  if(data == '1'){
                   jQuery('.hide_delete_forum_'+forum_id).fadeOut('slow');
                        location.reload();
                        }
                      }
                    });
         // }
    });

  /* remove member from group from frontend */
   

  jQuery('.member_delete_from_group').click(function(){

     var userid     = jQuery(this).attr('data-member');
     var groupid    = jQuery(this).attr('data-group');

     if(confirm("Are you sure you want to remove from chapter")){


        jQuery.ajax({
               type:"POST",
               url: ajaxurl,
               dataType: "json",
               data: {"action": "delete_member_from_chapter_from_frontend", 'userid':userid,'groupid':groupid},
               success:function(res){
                  
                  if(res.status=="fail"){
                  }else{
                     jQuery('#remove_mem_'+userid).fadeOut('slow');
                     window.location.reload();
                  }
               }
           });


      }

  });


  /* delete forum thread*/

   jQuery("#PageOpenTimer").TimeCircles({ 

    time: {
        Days: { color: "#d2113e" },
        Hours: { color: "#d2113e" },
        Minutes: { color: "#d2113e" },
        Seconds: { color: "#d2113e" }
    },
    direction: "Counter-clockwise",
    fg_width: 0.02,
    circle_bg_color: "#d0d7df",
    text_size: 0.10

  });
  

});

/* 
 // Initialize Firebase

 var config = {
    apiKey: "AIzaSyBq95sPe8O92ID2QyJdLr8DKNjLkXrPsAw",
    authDomain: "teamrwbpushnotification.firebaseapp.com",
    databaseURL: "https://teamrwbpushnotification.firebaseio.com",
    projectId: "teamrwbpushnotification",
    storageBucket: "teamrwbpushnotification.appspot.com",
    messagingSenderId: "876604016817"
  };
  firebase.initializeApp(config);
  const messaging = firebase.messaging();
  messaging.requestPermission()
  .then(function() {
    console.log('Notification permission granted.');
    return messaging.getToken();
  })
  .then(function(token) {
    console.log("token:"+token);
    console.log(token); // Display user token
      if(token){
              $.ajax({
                type:'POST',
                url:ajaxurl,
                data:{token : token,action:"save_pushtoken"},
                success:function(data){
                    //$("#msg").html(data);
                }
            }); 
      }


  })
  .catch(function(err) { // Happen if user deney permission
    console.log('Unable to get permission to notify.', err);
  });

  messaging.onMessage(function(payload){
    console.log('onMessage',payload);
  });*/



 