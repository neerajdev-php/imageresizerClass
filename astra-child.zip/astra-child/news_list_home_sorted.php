<?php 
// the query
global $wp_query;
$userId  = get_current_user_id();
$args=array(
			'post_type'       =>'post',
			'posts_per_page'  => 5,
			'post_status'     => 'publish',
			'order'			  => 'DESC'
		);

$the_query = new WP_Query( $args );
//echo $the_query->request;
if ( $the_query->have_posts() ) : 
?>
<div class="home_news_list_container">
	<div class="home_latest_news_list">
		<div class="home_news_head"><h2 class="text-center" ">SPECIALIZED PROGRAMS</h2></div>
		<?php
			$html_upcoming='';
			global $post;
			if($the_query->have_posts())
			{
				$i=1;
		   		while ( $the_query->have_posts() ) : $the_query->the_post();
				$post_id='';
				$post='';
				$start_date='';
				$post= $the_query->post;
                setup_postdata($post); 
               	$post_id= $post->ID;	   
               	$eventData= get_actual_event_id($post_id);  
               	$em_id= $eventData->event_id;
				$start_date = get_the_date('D, F d, Y h:i a');
			 	$nonImageContent='';
			 	if($i == 1){
			 		$html_upcoming.='<div class="home_repeat-news home_repeat-news_big">'; 
	                	$html_upcoming.='<div class="home_news_list_thumb">';
	                        $feat_image_url = wp_get_attachment_url( get_post_thumbnail_id() );
	                        $html_upcoming.='<a href="'.get_the_permalink().'"><img src="'.$feat_image_url.'" class="img_responsive"></a>';
	                   	$html_upcoming.='</div>'; 
						$html_upcoming.='<div class="home_news_list_header">';
							$html_upcoming.='<div class="home_news_date_head">'.$start_date."</div>";
							$html_upcoming.='<div class="home_news_title_head"> <a href="'.get_the_permalink().'">'. get_the_title()."</a></div>";
						$html_upcoming.='</div>'; 
					$html_upcoming.='</div>';
			 	}
			 	else{
	                $html_upcoming.='<div class="home_repeat-news">'; 
	                	$html_upcoming.='<div class="home_news_list_thumb">';
	                        $feat_image_url = wp_get_attachment_url( get_post_thumbnail_id() );
	                        $html_upcoming.='<a href="'.get_the_permalink().'"><img src="'.$feat_image_url.'" class="img_responsive"></a>';
	                   	$html_upcoming.='</div>'; 
						$html_upcoming.='<div class="home_news_list_header">';
							$html_upcoming.='<div class="home_news_date_head">'.$start_date."</div>";
							$html_upcoming.='<div class="home_news_title_head"> <a href="'.get_the_permalink().'">'. get_the_title()."</a></div>";
						$html_upcoming.='</div>'; 
					$html_upcoming.='</div>'; 
				}
            	$i++;
            	endwhile; 
		  		echo $html_upcoming; 
		  	}
		?>
	</div>
	<?php wp_reset_postdata(); ?>
</div>
<?php endif; ?>