<?php 
/** 
 * The template for displaying all single posts.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Astra
 * @since 1.0.0
 */

get_header(); ?>
<div class="event-custom-top-header">

		<?php astra_primary_content_top(); ?>

		<main id="main" class="site-main" role="main">
		

		<?php
		while ( have_posts() ) :
			the_post();

			$post_id= $post->ID;
			$start_date= get_post_meta($post_id,'_event_start_date',true);
			$end_date= get_post_meta($post_id,'_event_end_date',true);
			$location_id =get_post_meta($post_id,'_location_id',true);
			$event_id =get_post_meta($post_id,'_event_id',true);
			$LocationObj= get_location_by_id($location_id);
			$post_thumbnail_id = get_post_thumbnail_id( $post_id );
			$image_attributes = wp_get_attachment_image_src( $post_thumbnail_id );
			//pr($image_attributes);
			
			$fund=0;
			$fund= get_fund_details_event($event_id);
			$fund= sprintf('%.2f', floatval($fund));
			$participants= get_total_participents_event($event_id);
			$participantsCount=0;
			$participantsCount=count($participants);



?>


    <div class="event-custom-header-box">
    <div class="custom-container">
	<header class="entry-header <?php astra_entry_header_class(); ?>">

		<?php //astra_single_header_top(); ?>

		<div class="event_image_box">
		<span class="event_image_span">

		    <?php

				if ( has_post_thumbnail() ) {
				    the_post_thumbnail();
				}
				else {
				    echo '<img src="' . get_bloginfo( 'stylesheet_directory' ) 
				        . '/images/thumbnail-default.jpg" />';
				}
				?>
				</span>
		</div>



		<div class="event_title">	
		<span class="event_title_date_box"><?php echo $LocationObj->location_town; ?> — <?php echo date('F d, Y',strtotime(get_post_meta($post_id,'_event_start_date',true)));  ?></span>	
		 <div class="event_title_top"> <?php the_title(); ?></div>
		<div class="event_add_event">
		<a href="#" class="event_add_btn">Add to My Events</a>
		</div>
		</div>

		<?php 
		$user = wp_get_current_user();
		$role = ( array ) $user->roles;
		if (in_array('administrator', $role))
		{

		?>

	   <div class="event_register">
		 <a href="<?php echo site_url('create-new-event');?>" class="event_regsiter_btn">Register</a>
		</div>


		<?php 
		}

		//astra_blog_post_thumbnai_and_title_order(); ?>

		<?php //astra_single_header_bottom(); ?>

	</header><!-- .entry-header -->
	</div>
	</div>

<div class="article-bg">
<div class="custom-container">

<article itemtype="http://schema.org/CreativeWork" itemscope="itemscope" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

<div <?php astra_blog_layout_class( 'single-layout-1' ); ?>>

	<div class="entry-content clear" itemprop="text">



		<div class="event-details"><h2>Event Details  

		<?php 

			if(is_user_logged_in()){
		?>

		<a style="float:right; font-size: 20px;" class="fist_iteram_btn edit_partner_section share_post_activity" data-id="<?php echo $post_id;?>">Share</a></h2>

			<?php } ?>	

		</div>
		<?php 

		//   pr($post);



	      the_content(); ?>

		<div class="event_meta_data">
				<div class="event_meta_entry_box">
					<div class="event_meta_icon">
					<i class="event_meta_icon_date"></i>
					<div class="event_meta_entry_col">
					Date:
					  <p><?php echo date('F d, Y',strtotime($start_date))  ?> & <?php echo date('F d, Y',strtotime($end_date))  ?></p>
					  </div>
					  </div>					
				</div>				
				<div class="event_meta_entry_box">		
					<div class="event_meta_icon">
					<i class="event_meta_icon_map"></i>
					<div class="event_meta_entry_col">
					Location:-<a href="javascript:void(0);" class="open_map" > Check on map</a>
					<?php //echo do_shortcode('[locations_map location="'.$location_id.'"]');


						echo do_shortcode('[event_map_popup location_id="'.$location_id.'" event_id="'.$event_id.'"]');

					?>
					<p><?php echo $LocationObj->location_name; ?></p>
					</div>   
					</div>
				</div>
		  </div>
			<div class="event_meta_data_extra">
			  <div class="event_meta_data_extra_header">National Records</div>
                <div class="ast-row">
                  <div class="ast-col-sm-6 ast-col-lg-6 ast-col-sm-6 ast-md-sm-6 ast-col-xs-12">
	                  <div class="event_meta_entry">
							<div class="event_meta_icon"><i class="event_meta_icon_fund"></i><span>Fundraising: $ <?php echo $fund; ?></span></div>
						</div>
                  </div>
                  <div class="ast-col-sm-6 ast-col-lg-6 ast-col-sm-6 ast-md-sm-6 ast-col-xs-12">
	                  <div class="event_meta_entry">
							<div class="event_meta_icon"><i class="event_meta_icon_candidate"></i><span>Participants: <?php echo $participantsCount; ?></span>  <a href="javascript:void(0);" class="open_popup_participants"><i class="right_arrow"></i></a>						
							</div>
					   </div>	
                  </div>
               </div>
			</div>

		<?php
			astra_edit_post_link(

				sprintf(
					/* translators: %s: Name of current post */
					esc_html__( 'Edit %s', 'astra' ),
					the_title( '<span class="screen-reader-text">"', '"</span>', false )
				),
				'<span class="edit-link">',
				'</span>'
			);
		?>

		<?php astra_entry_content_after(); ?>

		<?php
			wp_link_pages(
				array(
					'before'      => '<div class="page-links">' . esc_html( astra_default_strings( 'string-single-page-links-before', false ) ),
					'after'       => '</div>',
					'link_before' => '<span class="page-link">',
					'link_after'  => '</span>',
				)
			);
		?>
	</div><!-- .entry-content .clear -->
</div>

</article><!-- #post-## -->
</div>
<?php
			 //$em_itinerary= get_itinerary_by_id($post_id);
			 $em_itinerary=  get_post_meta($post_id,'schedular',true);
?>

    <div class="event_itineray_data_extra">
                  <div class="custom-container">
                   <div class="itineray_header">Schedule for <?php echo date('F d, Y',strtotime($start_date))  ?></div>

                   <?php if($em_itinerary){ ?>
                   <?php foreach ($em_itinerary as $key => $value) {
                   	   if(strtotime($value['date']) == strtotime($start_date)){

                   	   	$hrs= get_time_difference($value['start'],$value['end']);
                   	   	?>
                    <div class="event_repeat_itineray">
                       <div class="itineray_title"><?php echo $value['title']; ?></div>
                       <div class="itineray_meta_container">
                       	  <div class="itineray_meta_start"><span>Start</span><p><?php echo $value['start']; ?></p><i class="right_arrow"></i></div>
                       	  <div class="itineray_meta_end"><span>Cutoff (<?php echo $hrs; ?> Hrs)</span><p><?php echo $value['end']; ?></p></div>
                       </div>
                    </div>
                    <?php } 
                      }
                    ?>
                    <?php } ?>
                  </div>


                  <div class="custom-container">
                   <div class="itineray_header">Schedule for <?php echo date('F d, Y',strtotime($end_date))  ?></div>
                   <?php if($em_itinerary){ ?>
                   <?php foreach ($em_itinerary as $key => $value) {
                   	   if(strtotime($value['date']) == strtotime($end_date)){

	                   $hrs= get_time_difference($value['start'],$value['end']);
                   	   	?>

                    <div class="event_repeat_itineray">
                       <div class="itineray_title"><?php echo $value['title']; ?></div>
                       <div class="itineray_meta_container">
                       	  <div class="itineray_meta_start"><span>Start</span><p><?php echo $value['start']; ?></p><i class="right_arrow"></i></div>
                       	  <div class="itineray_meta_end"><span>Cutoff (<?php echo $hrs; ?> Hrs)</span><p><?php echo $value['end']; ?></p></div>
                       </div>
                    </div>
                    <?php } 
                      }
                    ?>
                    <?php } ?>
            </div>
      </div>    

</div>


		<?php endwhile; ?>
	

		</main><!-- #main -->

		<?php astra_primary_content_bottom(); ?>

	</div><!-- #primary -->

<?php get_footer(); ?>
