<?php 
// the query
global $wp_query;

//$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;

$authorID = get_current_user_id();
$args = array(
    'post_type' => 'attachment',
    'posts_per_page' => 50,
    'post_status' => 'inherit',
    'author' => $authorID, // any parent
    'post_mime_type'=>'image/jpeg',
    'orderby'=> 'ID'
    ); 

$the_query = new WP_Query( $args );
/*echo $the_query->request;*/
?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.carousel.css">

<?php if ( $the_query->have_posts() ) : ?>

	<div class="latest-photo-owl-carousel owl-theme owl-carousel" id="latest_photo">
	
		<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
	
			<?php $imgUrl = wp_get_attachment_image_src( get_the_ID(), 'thumbnail', true ); ?>

		    <div class="item"><img src="<?php echo $imgUrl[0]; ?>" style="height: 200px;width:200px;"></div>

		<?php endwhile; ?>

	</div>


<?php  wp_reset_postdata(); ?>

<?php else : ?>
	<!-- <p><?php //esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p> -->
<?php endif; ?>

