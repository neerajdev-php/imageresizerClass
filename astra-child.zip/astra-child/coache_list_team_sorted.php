<?php 
// the query
global $wp_query;
$userId  = get_current_user_id();
$args=array(
	'post_type'       =>'coaches',
	'posts_per_page'  => 3,
	'post_status'     => 'publish',
	'order' 		  => 'ASC'
	);

$the_query = new WP_Query( $args );
//echo $the_query->request;
if ( $the_query->have_posts() ) : 
?>
<div class="home_coaches_list_container">
	<div class="home_latest_coaches_list">
		<div class="home_coaches_head"><h2 class="text-center" style="display: block !important;">Our Coaches</h2></div>
		<?php
			$html_upcoming='';
			global $post;
			if($the_query->have_posts())
			{
		   		while ( $the_query->have_posts() ) : $the_query->the_post();
				$post_id='';
				$post='';
				$start_date='';
				$post= $the_query->post;
                setup_postdata($post); 
               	$post_id= $post->ID;	   
               	$eventData= get_actual_event_id($post_id);  
               	$em_id= $eventData->event_id;
				$start_date= get_post_meta($post_id,'_event_start_date',true);
				
	                $html_upcoming.='<div class="home_repeat-coaches">'; 
	                $html_upcoming.='<div class="home_coaches_list_thumb">';
	                        $feat_image_url = wp_get_attachment_url( get_post_thumbnail_id() );
	                        $html_upcoming.='<a href="'.get_the_permalink().'"><img src="'.$feat_image_url.'" class="img_responsive"></a>';
	                $html_upcoming.='</div>'; 
					$html_upcoming.='<div class="home_coaches_list_header_custom">';
					$html_upcoming.='<div class="home_coaches_list_header">';
						//$html_upcoming.='<div class="home_event_date_head">'.date('F d, Y',strtotime($start_date))."</div>";
						$html_upcoming.='<div class="home_coaches_title_head"> <a href="'.get_the_permalink().'">'. get_the_title()."</a></div>";
					$html_upcoming.='</div>'; 
					$html_upcoming.='</div>'; 
						$html_upcoming.='<div class="home_coaches_content_head">'. get_the_content()."</div>";
					
					$html_upcoming.='</div>'; 
				
            	endwhile; 
		  		echo $html_upcoming; 
		  	}
		?>
	</div>
	<?php wp_reset_postdata(); ?>
</div>
<?php endif; ?>