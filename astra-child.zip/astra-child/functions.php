<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:
         
if ( !function_exists( 'child_theme_configurator_css' ) ):
    function child_theme_configurator_css() {
  
      wp_enqueue_style( 'chld_thm_cfg_child', trailingslashit( get_stylesheet_directory_uri() ) . 'style.css', array( 'astra-theme-css' ) );

        wp_enqueue_style( 'new-custom', trailingslashit( get_stylesheet_directory_uri() ) . 'new_custom.css');

        
        wp_enqueue_style( 'owl-carousel-min', trailingslashit( get_stylesheet_directory_uri() ) . 'slider/owl.carousel.min.css');

           wp_enqueue_style( 'mobile-menu', trailingslashit( get_stylesheet_directory_uri() ) . 'mobile-menu/slicknav.css');   
        wp_enqueue_style( 'TimerCountdown-css', trailingslashit( get_stylesheet_directory_uri() ) . 'iziModal/js/TimeCircles.css'); 
     

        wp_enqueue_script( 'mobile-menu-js',  trailingslashit( get_stylesheet_directory_uri() ) . 'mobile-menu/jquery.slicknav.min.js', array( 'astra-theme-js' ),true); 
        
        wp_enqueue_script( 'carousel22',  trailingslashit( get_stylesheet_directory_uri() ) . 'slider/owl.carousel.js', array( 'astra-theme-js' ),true);

          wp_enqueue_script( 'TimerCountdown-js',  trailingslashit( get_stylesheet_directory_uri() ) . 'iziModal/js/TimeCircles.js', array( 'astra-theme-js' ) );

       wp_enqueue_script( 'recaptcha', 'https://www.google.com/recaptcha/api.js', array( 'astra-theme-js' ),true );
      /* wp_enqueue_script( 'firebasejs', 'https://www.gstatic.com/firebasejs/4.9.1/firebase.js', array( 'astra-theme-js' ),true );*/




/*
     wp_enqueue_script( 'bp-parent-js', trailingslashit( get_stylesheet_directory_uri() ) . 'buddypress/js/buddypress.js', array( 'astra-theme-js' ) );
*/
      /* wp_enqueue_style( 'iziModalCssToggleinput', trailingslashit( get_stylesheet_directory_uri() ) . 'iziModal/css/jquery.toggleinput.css', array( 'astra-theme-css' ) );*/
/*		wp_enqueue_script( 'iziModalJsSlim', trailingslashit( get_stylesheet_directory_uri() ) . 'iziModal/js/jquery-3.2.1.slim.min.js', array( 'astra-theme-js' ) );

		wp_enqueue_script( 'iziModalJsToggleinput', trailingslashit( get_stylesheet_directory_uri() ) . 'iziModal/js/jquery.toggleinput.js', array( 'astra-theme-js' ) );	*/	

	
				wp_enqueue_script( 'iziModalJsScript2',  get_stylesheet_directory_uri() . '/iziModal/js/iziScript.js', array( 'astra-theme-js' ) );
				// Localize the script with new data
         $profileURl=  home_url( '/members/' . bp_core_get_username( get_current_user_id() ) . '/settings/' );
        $profileForums=  home_url( '/members/' . bp_core_get_username( get_current_user_id() ) . '/forums/' );
				$translation_array = array(
				'ajaxurl' => admin_url('admin-ajax.php'),
				'site_url' => site_url(),
				'nonce' => wp_create_nonce('ajaxnonce'),
				'profile_url'=>$profileURl,
        'profile_forums'=>$profileForums,
        'logo'=>'',
				);
				wp_localize_script( 'iziModalJsScript2', 'rwbObj', $translation_array );
    }
endif;
add_action( 'wp_enqueue_scripts', 'child_theme_configurator_css' );

// END ENQUEUE PARENT ACTION


// Setup Discount code tab for BuddyPress profile
function add_discount_code_tab() {
	global $bp;
	
	bp_core_new_nav_item( array(
		'name'                  => 'Discount Codes',
		'slug'                  => 'discount-codes',
		'parent_url'            => $bp->displayed_user->domain,
		'parent_slug'           => $bp->profile->slug,
		'screen_function'       => 'discount_codes_screen',			
		'position'              => 199,
		'default_subnav_slug'   => 'discount-codes'
	) );
}

add_action( 'bp_setup_nav', 'add_discount_code_tab', 100 );



function add_shop_tab() {
	global $bp;
	
	bp_core_new_nav_item( array(
		'name'                  => 'Shop',
		'slug'                  => 'shop',
		'parent_url'            => $bp->displayed_user->domain,
		'parent_slug'           => $bp->profile->slug,
		'screen_function'       => 'shop_screen',			
		'position'              => 200,
		'default_subnav_slug'   => 'shop'
	) );
}

add_action( 'bp_setup_nav', 'add_shop_tab', 100 );


function shop_screen() {
    add_action( 'bp_template_title', 'discount_codes_screen_title' );
    add_action( 'bp_template_content', 'discount_codes_screen_content' );
    //wp_redirect('https://wattieinkcustom.com/collections/rwb');
    //wp_redirect('https://mybikeshop.com/');
    wp_redirect('https://www.clubpack.org/excelmultisport-store/');
    die;
  
}





function discount_codes_screen() {
    add_action( 'bp_template_title', 'discount_codes_screen_title' );
    add_action( 'bp_template_content', 'discount_codes_screen_content' );
    bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}

function discount_codes_screen_title() { 

  $html  = '<h3>Discount Codes</h3><span class="add_discount_code"><a href="javascript:void(0)">New code</a></span>';

  //echo $html; 
	//echo 'Discount Codes <span class="add_discount_code"><a href="">New code</a></span>';
}

function discount_codes_screen_content() { 
   get_template_part( 'template-parts/discount', 'code' );
}

/*********** Create New User Big Commerce Custom Code Start ***************/

add_action( 'user_register', 'mycode_registration_save', 10, 1 );
function mycode_registration_save( $user_id ) {

	$userName     = $_POST['signup_username'];
	$fullName     = $_POST['field_1'];
	$emailAddress = $_POST['signup_email'];
	$password     = $_POST['signup_password'];
	
    $userdata = array(
        'user_login'   => $userName,
        'user_email'   => $emailAddress,
        'display_name' => $fullName,
        'user_pass'    => $password
    );
	
	/*********** Create New User Big Commerce Custom Code Start ***************/
	wpAddSameUserIntoBigCommerce($userdata);
	/*********** Create New User Big Commerce Custom Code End ***************/
}

function wpAddSameUserIntoBigCommerce($userdata){
	if($userdata){
		$first_name		= '';
		$last_name		= '';
		$user_login 	= $userdata['user_login'];
		$user_email 	= $userdata['user_email'];
		$display_name 	= $userdata['display_name'];
		$password 		= $userdata['user_pass'];
		if($display_name){
			$exp = explode(" ",$display_name);
			if($exp[0]){
				$first_name = $exp[0];
			}else{
				$first_name	= ' ';
			}
			if($exp[1]){
				$last_name = $exp[1];
			}else{
				$last_name	= ' ';
			}
		}
		//Call curl for add customer on bigcommerce
		if($user_email){
			$array = array(
							"first_name"		=>	$first_name,
							"last_name"			=>	$last_name,
							"email"				=>	$user_email,
							"customer_group_id"	=>	"1",
							"_authentication"=>array("password" => $password)
						);
			$data_string = json_encode($array);  
			$api_url = 'https://store-usekt91sc8.mybigcommerce.com/api/v2/customers'; //live
			//$api_url = 'https://store-2a192ntvwu.mybigcommerce.com/api/v2/customers'; //local
			//$api_url = 'https://store-rq4pvgmb00.mybigcommerce.com/api/v2/customers'; //local again
			$ch = curl_init();
			curl_setopt( $ch, CURLOPT_URL, $api_url );
			curl_setopt( $ch, CURLOPT_HTTPHEADER, array ('Accept: application/json', 'Content-Type:application/json') );
			curl_setopt( $ch, CURLOPT_VERBOSE, 0 );
			//curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, 'GET');
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);  
			curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
			curl_setopt( $ch, CURLOPT_USERPWD, "wordpressbig:0d9bf129d8ccaa6d89e9646f8a3869cebea8c07e" ); // live
			//curl_setopt( $ch, CURLOPT_USERPWD, "ramlal:0107ccaeb5177570948fad855e011bbb45c7bc9a" ); //local
			/*curl_setopt( $ch, CURLOPT_USERPWD, "jitpatil:b1964431dee2b53ea915f3f5c0e817f9a4f9c3b8
" );*/ //local again 
			curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );
			$response = curl_exec( $ch );
			$result = json_decode($response);
		}
	}
}
/*add_filter( 'bp_email_use_wp_mail', '__return_true' );*/

 require get_theme_file_path( '/lib/PushNotification.php' );
 require get_theme_file_path( '/functions/core_function.php' );
 require get_theme_file_path( '/functions/core_news_function.php' );
 require get_theme_file_path( '/lib/cutsom-fields/custom-fields-init.php' );

/*********** Create New User Big Commerce Custom Code Start ***************/

function nav_replace_wpse_189788($item_output, $item) {
  //  var_dump($item_output, $item);
  if ('Profile' == $item->title) {  
  $url= bp_loggedin_user_domain( '/' );	
    if (is_user_logged_in()) { 
    	
      return '<div class="lastProContainer"> <div class="loggedInProFileImage" data-key="profile">'.get_avatar( get_current_user_id(), 64 ).'</div><a href="'.$url.'" style="color: #8a92a1;">Profile</a></div>';
    }else{
      return '<div class="lastProContainer"> <div class="loggedInProFileImage" data-key="profile">'.get_avatar( get_current_user_id(), 64 ).'</div><a href="'.$url.'" style="color: #8a92a1;">Profile</a></div>';
    }
  }


  if ('Request to Join' == $item->title) {  
   $url= bp_loggedin_user_domain( '/' );	
    if (is_user_logged_in()) {    
      $url= bp_loggedin_user_domain( '/' );		
      $url= $url."settings";
      return '<a href="'.$url.'">Settings</a>';
    }else{
      return '<a href="#" class="request_join_me" >Request to Join</a>';
    }
  }


  if ('Log Out' == $item->title) {  
     return '<a href="'.wp_logout_url( home_url() ).'">Log Out</a>';
  }

    if ('Get Involved' == $item->title) {  
     return '';
  }

  



  return $item_output;
}
add_filter('walker_nav_menu_start_el','nav_replace_wpse_189788',10,2);




if(!function_exists('pr')){
	function pr($obj){ 
	 $ip= array('111.93.121.26');
	 $currentIp=$_SERVER['REMOTE_ADDR'];
	 if(in_array($currentIp, $ip)){
		 echo '<pre>';
		    print_r($obj);
		 echo '</pre>';
	 }
	}
}

function bpex_hide_profile_menu_tabs() {

		/*bp_core_remove_nav_item( 'profile' );
		bp_core_remove_nav_item( 'settings' );*/

		//bp_core_remove_nav_item( 'messages');
		//bp_core_remove_nav_item( 'friends');
		//bp_core_remove_nav_item( 'groups' );

}
add_action( 'bp_setup_nav', 'bpex_hide_profile_menu_tabs', 15 );



add_action('bp_setup_nav', 'we4_profile_menu_tabs', 201);
function we4_profile_menu_tabs(){
	global $bp;
/*	$bp->bp_nav['activity']['position'] = 100;
    $bp->bp_nav['Photos']['position'] = 10;*/

  unset( $bp->bp_nav['profile'] );
 // unset( $bp->bp_nav['settings'] );
  if(!current_user_can('administrator')) {
     unset($bp->bp_nav['invite-anyone']);
   }


//pr($bp);
$bp->bp_nav['groups']['name'] = 'My Chapters';
$bp->bp_nav['events']['name'] = 'My Events';
$bp->bp_nav['mediapress']['name'] = 'My Gallery';


}


function tricks_change_bp_tag_position()
{
global $bp;

$bp->bp_nav['activity']['position'] = 10;
$bp->bp_nav['notifications']['position'] = 20;
$bp->bp_nav['forums']['position'] = 30;
$bp->bp_nav['groups']['position'] = 40;
$bp->bp_nav['gallery']['position'] = 50;
$bp->bp_nav['anyone-personal']['position'] = 50;
$bp->bp_nav['posts']['position'] = 60;
$bp->bp_nav['blogs']['position'] = 70;
$bp->bp_nav['friends']['position'] = 80;
}
add_action( 'bp_init', 'tricks_change_bp_tag_position', 999 );





function wpse31748_exclude_menu_items( $items, $menu, $args ) {
    // Iterate over the items to search and destroy
    foreach ( $items as $key => $item ) {
    	if(!is_front_page()){
    		 if ( $item->object_id == 20480 ){ unset( $items[$key] ); }
    		 if ( $item->object_id == 20481 ){ unset( $items[$key] ); }
    	}       
    }
    return $items;
}

add_filter( 'wp_get_nav_menu_items', 'wpse31748_exclude_menu_items', null, 3 );



add_action( 'widgets_init', 'theme_slug_widgets_init' );
function theme_slug_widgets_init() {
    register_sidebar( array(
        'name' => __( 'Invite Sidebar ', 'theme-slug' ),
        'id' => 'inviteme_1',
        'description' => __( 'This will use to invite any one .', 'theme-slug' ),
        'before_widget' => '<li id="%1$s" class="invicePopDv widget %2$s">',
	    'after_widget'  => '</li>',
	    'before_title'  => '<h2 class="widgettitle">',
	    'after_title'   => '</h2>',
    ) );
}

function testSendMail(){
	$ip= array('111.93.121.26');
	 $currentIp=$_SERVER['REMOTE_ADDR'];
	 if(in_array($currentIp, $ip)){
       var_dump(mail('mail@gmail.com','Test Mail','sss'));
	 }
	
}

function wpdocs_custom_excerpt_length( $length ) {
    return 30;
}
add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length', 999 );

function create_invite_anyone_html(){
   $html='';
   ob_start();
   /*	require get_template_directory() . '/template-parts/inviteHTML/invite_anyone_form.php';*/
   	 require get_theme_file_path( '/template-parts/inviteHTML/invite_anyone_form.php' );
   $html.=ob_get_contents();
   ob_get_clean();
   return $html;
}
add_shortcode('INVITE_POPUP','create_invite_anyone_html');


function login_signup_popup001(){
   $html='';
   ob_start();
   	 require get_theme_file_path( '/template-parts/inviteHTML/login_signup_popup.php' );
   $html.=ob_get_contents();
   ob_get_clean();

   return $html;
}
add_shortcode('LOGIN_POPUP','login_signup_popup001');


function create_html_for_news_list_home(){
   $html='';
   ob_start();
     include( get_stylesheet_directory() . '/news_list_home_sorted.php');
     $html.=ob_get_contents();
    ob_get_clean();
    return $html;

}
add_shortcode('LATEST-NEWS','create_html_for_news_list_home');


function gallery_upload001(){
   $html='';
   ob_start();
   	 require get_theme_file_path( '/template-parts/inviteHTML/gallery_upload.php' );
   $html.=ob_get_contents();
   ob_get_clean();

   return $html;
}
add_shortcode('gallery_upload_popup','gallery_upload001');

function create_html_reset_pass_form(){

   $html='';
   ob_start();
      require get_theme_file_path( '/template-parts/reset-pass.php' );

     $html.=ob_get_contents();
    ob_get_clean();
    return $html; 

}
add_shortcode('reset-pass-form','create_html_reset_pass_form');


function create_html_request_join(){

   $html='';
   ob_start();
      require get_theme_file_path( '/template-parts/inviteHTML/request_to_join.php' );
     $html.=ob_get_contents();
    ob_get_clean();
    return $html; 

}
add_shortcode('request_join_form','create_html_request_join');

function create_html_add_album(){

   $html='';
   ob_start();
      require get_theme_file_path( '/template-parts/inviteHTML/add_new_album.php' );
     $html.=ob_get_contents();
    ob_get_clean();
    return $html; 

}
add_shortcode('add_new_album','create_html_add_album');



function create_html_regsiter_invited001(){

   $html='';
     ob_start();
      require get_theme_file_path( '/template-parts/inviteHTML/signup_invite.php' );
     $html.=ob_get_contents();
    ob_get_clean();
    return $html; 

}
add_shortcode('regsiter_invited','create_html_regsiter_invited001');




function create_event_map_popup_html( $atts ){
  $attr = shortcode_atts( array(
        'location_id' => '',
        'event_id' => '',
    ), $atts );


  $location_id= $attr['location_id'];
  $event_id= $attr['event_id'];
   $html='';
   ob_start();
   require get_theme_file_path( '/template-parts/inviteHTML/single_event_map_popup.php' );
/*   	require get_stylesheet_directory_uri() . '/template-parts/inviteHTML/single_event_map_popup.php';*/
   $html.=ob_get_contents();
   ob_get_clean();
   return $html;
}
add_shortcode('event_map_popup','create_event_map_popup_html');

function create_html_for_events_list_home(){
   $html='';
   ob_start();
     include( get_stylesheet_directory() . '/event_list_home_sorted.php');
     $html.=ob_get_contents();
    ob_get_clean();
    return $html;

}
add_shortcode('LATEST-EVENT','create_html_for_events_list_home');

function create_html_for_coache_list_team(){
   $html='';
   ob_start();
     include( get_stylesheet_directory() . '/coache_list_team_sorted.php');
     $html.=ob_get_contents();
    ob_get_clean();
    return $html;

}
add_shortcode('OUR-COACHES','create_html_for_coache_list_team');

/* contact map popup  code */

function create_contact_map_popup_html( ){
 
   $html='';
   ob_start();
   require get_theme_file_path( '/template-parts/inviteHTML/contact_map.php' );
/*    require get_stylesheet_directory_uri() . '/template-parts/inviteHTML/single_event_map_popup.php';*/
   $html.=ob_get_contents();
   ob_get_clean();
   return $html;
}
add_shortcode('contact_map_popup','create_contact_map_popup_html');



function include_invitecode(){
if (!is_singular('event') ) {
	echo do_shortcode('[INVITE_POPUP]');
   }

 if(!is_user_logged_in()){
 	echo do_shortcode('[LOGIN_POPUP]');
   echo do_shortcode('[request_join_form]');
   echo do_shortcode('[regsiter_invited]');
 }
 if(is_user_logged_in()){
   echo do_shortcode('[gallery_upload_popup]');
   echo do_shortcode('[add_new_album]');
}
 

}
add_action('wp_footer','include_invitecode');

function wpse27856_set_content_type(){
    return "text/html";
}


/*add_filter( 'wp_mail_from_name', 'custom_wp_mail_from_name' );*/
function custom_wp_mail_from_name( $original_email_from ) {
  return 'Excel Multisport';
}


function wo_email_from_extend($email){
    return 'support@teamrwbtri.clubpack.org';
}



/*  add_filter( 'wp_mail_content_type','wpse27856_set_content_type' );
  add_filter( 'wp_mail_from','wo_email_from_extend');*/


add_action('wp_ajax_send_invit_email','send_invit_email');
add_action('wp_ajax_nopriv_send_invit_email','send_invit_email');
function send_invit_email(){
	
	global $bp,$wpdb;
	$nonce = $_POST['nonce'];


 	// Verify nonce field passed from javascript code
    if ( ! wp_verify_nonce( $nonce, 'ajaxnonce' ) )
        die ( 'Busted!');
	$email   =  sanitize_email($_POST['email']);
	$recipientName   =  $_POST['recipient_name'];
	$recipientRole   =  $_POST['user_role'];
    $error   = '';
    $message = '';
		if($email !=''){


      if ( email_exists( $email ) ) {

        $error = 'Email is already exists.';
    
      }else{  	

       	$to           = $email;
    	$subject1     = get_option('option_email_subject');
    	$site_name    = get_option('blogname');
    	$logoUrl      = site_url().'/wp-content/uploads/2017/10/logo.png';
    	$slogo        = '<img src="'.$logoUrl.'">';
    	$current_user = wp_get_current_user();
    	$sender_profile_link = bp_core_get_userlink($current_user->ID,false,true);
    	$pLInk = '<a href="'.$sender_profile_link.'">Click here</a>';
    	$Sname 		  = $current_user->user_firstname.' '.$current_user->user_lastname;
    	$subject2      = str_replace('%site_name%', $site_name, $subject1);
    	$subject = $subject2; 
      $invit_accept_link  =   site_url('register-invite').'?action=accept-invitation&email='.$email.'&invitee_name='.$recipientName.'&recipientRole='.$recipientRole;
      $opt_out_link       =   site_url('register-invite').'?action=opt-out&email='.$email.'&invitee_name='.$recipientName.'&recipientRole='.$recipientRole;

    	$acceptLink = '<a href="'.$invit_accept_link.'">Click here</a>';
    	$optLink    = '<a href="'.$opt_out_link.'">Click here</a>';

    	$from              = get_option('admin_email');
		$html              = get_option('special_content');
		$invitName         = str_replace('%sender_name%', $Sname, $html);
		$site_name         = str_replace('%site_name%', $site_name, $invitName);
		$visitSenderName   = str_replace('%sender_name%', $Sname, $site_name);
		$profileVisit      = str_replace('%profile_link%', $pLInk, $visitSenderName);
		$acceptLink        = str_replace('%accept_link%', $acceptLink, $profileVisit);
		$final             = str_replace('%opt_out%', $optLink, $acceptLink);
	  $body = $final;





		$contact_errors = false;
		// write the email content
	    $header .= "MIME-Version: 1.0" . "\r\n";
	    $header .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	    $header .= "From:" . $from;

	    $subject = "=?utf-8?B?" . base64_encode($subject) . "?=";
        add_filter( 'bp_email_use_wp_mail', '__return_true' );
        add_filter( 'wp_mail_content_type','wpse27856_set_content_type' );
        add_filter( 'wp_mail_from','wo_email_from_extend');


	   if( !mail($to, $subject,  $body, $header) ) {
           $contact_errors = true;
       }

      $groups    = ! empty( $_POST['invite_anyone_groups'] ) ? $_POST['invite_anyone_groups'] : array();
	   $subject3  = $subject2.'-'.$email;
	   $res       = invite_anyone_record_invitation( $bp->loggedin_user->id, $email, $body, $groups, $subject3, '' );

       do_action( 'sent_email_invite', $bp->loggedin_user->id, $email, $groups );
	   $message = 'You invitation has been sent successfully!';
   }

	}else{

    	$error = 'Please fill valid details';
	}
	if($error == ''){
		$response = array('status' => 'sent' , 'message' => $message);
    }else{
		$response = array('status' => 'fail' , 'message' => $error);
    }
	echo json_encode($response);
exit;
}
?>
<?php
// create custom plugin settings menu
add_action('admin_menu', 'my_cool_plugin_create_menu');

function my_cool_plugin_create_menu() {

	//create new top-level menu
	add_menu_page('Invit Email template', 'Invit Email template', 'manage_options', 'invit_email', 'my_cool_plugin_settings_page');

	//call register settings function
	add_action( 'admin_init', 'register_my_cool_plugin_settings' );
}


function register_my_cool_plugin_settings() {
	//register our settings
	//register_setting( 'my-cool-plugin-settings-group', 'new_option_name' );
	//register_setting( 'my-cool-plugin-settings-group', 'some_other_option' );
	register_setting( 'my-cool-plugin-settings-group', 'option_email_subject' );
	register_setting( 'my-cool-plugin-settings-group', 'special_content' );
}

function my_cool_plugin_settings_page() {
?>
<div class="wrap">
<h1>Invitation Email Template</h1>

<form method="post" action="options.php">
    <?php settings_fields( 'my-cool-plugin-settings-group' ); ?>
    <?php do_settings_sections( 'my-cool-plugin-settings-group' ); ?>
    <table class="form-table">
    <tr>
    	<td>Subject</td>
    	<td><input type="text" name="option_email_subject" value="<?php echo get_option('option_email_subject');?>" style="width:100%"></td>
	</tr>
    <tr>
        <td colspan="2">
        <?php 
        	 $content =  get_option('special_content');
             wp_editor( $content, 'special_content', $settings = array('textarea_rows'=> '10') );

        ?>
        </td>
    </tr>
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
<?php }
/*function wpse27856_set_content_type(){
    return "text/html";
}
add_filter( 'wp_mail_content_type','wpse27856_set_content_type' );

add_filter( 'wp_mail_from_name', 'my_mail_from_name' );
function my_mail_from_name( $name ) {
    return "My Name";
}

add_filter( 'wp_mail_from', 'my_mail_from' );
function my_mail_from( $email ) {
    return "change-this-to-your-email-address";
}*/

function invite_CustomField($post_id){      	
	if(isset($_POST['invite_send'])){

		  $data=array('name'=>$_POST['recipient_name'],'role'=>$_POST['user_role']);
		 //  update_post_meta($post_id,$_POST[''],);
	}
}
add_action( 'save_post', 'invite_CustomField' ); 

/*add_action('bp_core_activated_user', 'bp_custom_registration_role',10 , 3);
function bp_custom_registration_role($user_id, $key, $user) {
     $userdata = array();
    $userdata['ID'] = $user_id;
   if(isset($_POST['signup_profile_role'])){ 
		   $userdata['role'] =  strtolower($_POST['signup_profile_role']);
		   wp_update_user($userdata);
        }
    }*/

add_action( 'user_register', 'myplugin_registration_save11', 10, 1 );

function myplugin_registration_save11( $user_id ) {
     $userdata = array();
    $userdata['ID'] = $user_id;
        if(isset($_POST['signup_profile_role'])){ 
   	           $user = new WP_User($user_id);
   	           update_user_meta($user_id,'custom_role',$_POST['signup_profile_role']);
		       $user->set_role($_POST['signup_profile_role']);
        }
}



// define the bp_get_displayed_user_nav_activity callback 
function filter_bp_get_displayed_user_nav_activity( $array ) { 
    // make filter magic happen here... 


	return; 
}; 
// add the filter 
add_filter( 'bp_get_displayed_user_nav_settings', 'filter_bp_get_displayed_user_nav_activity', 10, 1 ); 





function add_icon_to_buddydeletebtn($link){
 
   $link= str_replace('Delete', '<i class="icon-del"></i>Delete',  $link);

 return $link;

}

add_filter('bp_get_activity_delete_link','add_icon_to_buddydeletebtn');




remove_action( 'wp_ajax_activity_mark_fav', 'bp_dtheme_mark_activity_favorite' );
remove_action( 'wp_ajax_nopriv_activity_mark_fav', 'bp_dtheme_mark_activity_favorite' );

remove_action( 'wp_ajax_activity_mark_unfav', 'bp_dtheme_unmark_activity_favorite' );
remove_action( 'wp_ajax_nopriv_activity_mark_unfav', 'bp_dtheme_unmark_activity_favorite' );

function custom_like_text(){
	// Bail if not a POST action
	if ( 'POST' !== strtoupper( $_SERVER['REQUEST_METHOD'] ) )
		return;

	if ( bp_activity_add_user_favorite( $_POST['id'] ) )
		_e( '<i class="icon-unfav"></i>Unfavorite', 'buddypress' );
	else
		_e( '<i class="icon-fav"></i>Favorite', 'buddypress' );

	exit;
}

function custom_unlike_text(){
	// Bail if not a POST action
	if ( 'POST' !== strtoupper( $_SERVER['REQUEST_METHOD'] ) )
		return;

	if ( bp_activity_remove_user_favorite( $_POST['id'] ) )
		_e( '<i class="icon-fav"></i>Favorite', 'buddypress' );
	else
		_e( '<i class="icon-unfav"></i>UnFavorite', 'buddypress' );

	exit;
}

add_action( 'wp_ajax_activity_mark_fav', 'custom_like_text' );
add_action( 'wp_ajax_nopriv_activity_mark_fav', 'custom_like_text' );

add_action( 'wp_ajax_activity_mark_unfav', 'custom_unlike_text' );
add_action( 'wp_ajax_nopriv_activity_mark_unfav', 'custom_unlike_text' );




function add_recurvive_comment_ul($ul){
  return '<ul class="inner_cm_ul">';
}

add_filter('bp_activity_recurse_comments_start_ul','add_recurvive_comment_ul');



function pauld_bp_get_activity_show_filters_options( $filters, $context ) { 
	


	
		$remove_these = array('created_group','group_details_updated','joined_group'); 

		//print_r($filters);
		
		foreach ( $filters as $key => $val ) {
		
			if ( in_array( $key, $remove_these ) )
				unset( $filters[ $key ] );
			
		}
	
	
    return $filters; 
}; 
add_filter( 'bp_get_activity_show_filters_options', 'pauld_bp_get_activity_show_filters_options', 20, 2 );



remove_action( 'bp_notification_settings', 'bp_activity_screen_notification_settings', 1 );

function bp_activity_screen_notification_settings001() {

	if ( bp_activity_do_mentions() ) {
		if ( ! $mention = bp_get_user_meta( bp_displayed_user_id(), 'notification_activity_new_mention', true ) ) {
			$mention = 'yes';
		}
	}

	if ( ! $reply = bp_get_user_meta( bp_displayed_user_id(), 'notification_activity_new_reply', true ) ) {
		$reply = 'yes';
	}

	?>
	<label for="" ><?php _e( 'Activity', 'buddypress' ); ?></label>
	<table class="notification-settings" id="activity-notification-settings">
      <tbody>
			<?php if ( bp_activity_do_mentions() ) : ?>
				<tr id="activity-notification-settings-mentions">
				<td>&nbsp;</td>
					
					<td><?php printf( __( 'A member mentions you in an update using "@%s"', 'buddypress' ), bp_core_get_username( bp_displayed_user_id() ) ) ?></td>

					<td>						
							<div class="switch-field">
								<input type="radio" name="notifications[notification_activity_new_mention]" id="switch_left" value="yes" <?php checked( $mention, 'yes', true ) ?>/>

								<label for="switch_left" ><?php
								/* translators: accessibility text */
								_e( 'Yes', 'buddypress' );
								?></label>

								<input type="radio" name="notifications[notification_activity_new_mention]" id="switch_right" value="no" <?php checked( $mention, 'no', true ) ?>/>

								<label for="switch_right" ><?php
								/* translators: accessibility text */
								_e( 'No', 'buddypress' );
								?></label> 
							</div>
					</td>
				</tr>
			<?php endif; ?>

			<tr id="activity-notification-settings-replies">
				<td>&nbsp;</td>
				<td><?php _e( "A member replies to an update or comment you've posted", 'buddypress' ) ?></td>				

                        <td>
                        <div class="switch-field">
									<input type="radio" name="notifications[notification_activity_new_reply]" id="switch_left_01" value="yes" <?php checked( $reply, 'yes', true ) ?>/>

									<label for="switch_left_01" ><?php
									/* translators: accessibility text */
									_e( 'Yes', 'buddypress' );
									?></label>

									<input type="radio" name="notifications[notification_activity_new_reply]" id="switch_right_01" value="no" <?php checked( $reply, 'no', true ) ?>/>

									<label for="switch_right_01" ><?php
									/* translators: accessibility text */
									_e( 'No', 'buddypress' );
									?></label> 
								</div>
					</td>
			</tr>
   
			<?php

			/**
			 * Fires inside the closing </tbody> tag for activity screen notification settings.
			 *
			 * @since 1.2.0
			 */
			do_action( 'bp_activity_screen_notification_settings' ) ?>
		</tbody>
	</table>


<?php
}
add_action( 'bp_notification_settings', 'bp_activity_screen_notification_settings001', 1 );


remove_action( 'bp_notification_settings', 'messages_screen_notification_settings', 2 );

function messages_screen_notification_settings001() {

	if ( bp_action_variables() ) {
		bp_do_404();
		return;
	}

	if ( !$new_messages = bp_get_user_meta( bp_displayed_user_id(), 'notification_messages_new_message', true ) ) {
		$new_messages = 'yes';
	} ?>

	<label for="" ><?php _e( 'Messages', 'buddypress' ); ?></label>
	<table class="notification-settings" id="messages-notification-settings">
		<!-- <thead>
			<tr>
				<th class="icon"></th>
				<th class="title"><?php _e( 'Messages', 'buddypress' ) ?></th>
				<th class="yes"><?php _e( 'Yes', 'buddypress' ) ?></th>
				<th class="no"><?php _e( 'No', 'buddypress' )?></th>
			</tr>
		</thead> -->

		<tbody>
			<tr id="messages-notification-settings-new-message">

				<td>&nbsp;</td>

				<td><?php _e( 'A member sends you a new message', 'buddypress' ) ?></td>

				<td class="yes">
					
					<div class="switch-field">

						<input type="radio" name="notifications[notification_messages_new_message]" id="switch_left_msg" value="yes" <?php checked( $new_messages, 'yes', true ) ?>/>

						<label for="switch_left_msg" ><?php
						/* translators: accessibility text */
						_e( 'Yes', 'buddypress' ); ?>
						</label>

						<input type="radio" name="notifications[notification_messages_new_message]" id="switch_right_msg" value="no" <?php checked( $new_messages, 'no', true ) ?>/>

						<label for="switch_right_msg"><?php
						/* translators: accessibility text */
						_e( 'No', 'buddypress' );?>
						</label>

					</div>

				</td>

			</tr>

			<?php

			/**
			 * Fires inside the closing </tbody> tag for messages screen notification settings.
			 *
			 * @since 1.0.0
			 */
			do_action( 'messages_screen_notification_settings001' ); ?>
		</tbody>
	</table>

<?php
}
add_action( 'bp_notification_settings', 'messages_screen_notification_settings001', 2 );


remove_action( 'bp_notification_settings', 'friends_screen_notification_settings' );

function friends_screen_notification_settings001() {

	if ( !$send_requests = bp_get_user_meta( bp_displayed_user_id(), 'notification_friends_friendship_request', true ) )
		$send_requests   = 'yes';

	if ( !$accept_requests = bp_get_user_meta( bp_displayed_user_id(), 'notification_friends_friendship_accepted', true ) )
		$accept_requests = 'yes'; ?>

	<label for="" ><?php _e( 'Friends', 'buddypress' ); ?></label>

	<table class="notification-settings" id="friends-notification-settings">
	
		<tbody>
			<tr id="friends-notification-settings-request">
				
				<td>&nbsp;</td>

				<td><?php _ex( 'A member sends you a friendship request', 'Friend settings on notification settings page', 'buddypress' ) ?></td>
				
				<td>

					<div class="switch-field">

						<input type="radio" name="notifications[notification_friends_friendship_request]" id="switch_left_fr_reqst_snd" value="yes" <?php checked( $send_requests, 'yes', true ) ?>/>

						<label for="switch_left_fr_reqst_snd"><?php
							/* translators: accessibility text */
							_e( 'Yes', 'buddypress' );?>
						</label>

						<input type="radio" name="notifications[notification_friends_friendship_request]" id="switch_right_fr_reqst_snd" value="no" <?php checked( $send_requests, 'no', true ) ?>/>

						<label for="switch_right_fr_reqst_snd" ><?php
							/* translators: accessibility text */
							_e( 'No', 'buddypress' );?>
						</label>

					</div>

				</td>
			</tr>

			<tr id="friends-notification-settings-accepted">

				<td>&nbsp;</td>

				<td><?php _ex( 'A member accepts your friendship request', 'Friend settings on notification settings page', 'buddypress' ) ?></td>

				<td>

					<div class="switch-field">

						<input type="radio" name="notifications[notification_friends_friendship_accepted]" id="switch_left_fr_reqst_acpt" value="yes" <?php checked( $accept_requests, 'yes', true ) ?>/>

						<label for="switch_left_fr_reqst_acpt"><?php
							/* translators: accessibility text */
							_e( 'Yes', 'buddypress' );?>
						</label>

						<input type="radio" name="notifications[notification_friends_friendship_accepted]" id="switch_right_fr_reqst_acpt" value="no" <?php checked( $accept_requests, 'no', true ) ?>/>

						<label for="switch_right_fr_reqst_acpt"><?php
							/* translators: accessibility text */
							_e( 'No', 'buddypress' );?>
						</label>

					</div>

				</td>
			</tr>

			<?php

			/**
			 * Fires after the last table row on the friends notification screen.
			 *
			 * @since 1.0.0
			 */
			do_action( 'friends_screen_notification_settings001' ); ?>

		</tbody>
	</table>

<?php
}
add_action( 'bp_notification_settings', 'friends_screen_notification_settings001' );



remove_action( 'bp_notification_settings', 'groups_screen_notification_settings' );

function groups_screen_notification_settings001() {

	if ( !$group_invite = bp_get_user_meta( bp_displayed_user_id(), 'notification_groups_invite', true ) )
		$group_invite  = 'yes';

	if ( !$group_update = bp_get_user_meta( bp_displayed_user_id(), 'notification_groups_group_updated', true ) )
		$group_update  = 'yes';

	if ( !$group_promo = bp_get_user_meta( bp_displayed_user_id(), 'notification_groups_admin_promotion', true ) )
		$group_promo   = 'yes';

	if ( !$group_request = bp_get_user_meta( bp_displayed_user_id(), 'notification_groups_membership_request', true ) )
		$group_request = 'yes';

	if ( ! $group_request_completed = bp_get_user_meta( bp_displayed_user_id(), 'notification_membership_request_completed', true ) ) {
		$group_request_completed = 'yes';
	}
	?>
	<label for="" ><?php _e( 'Groups', 'buddypress' ); ?></label>
	<table class="notification-settings" id="groups-notification-settings">
       <tbody>
			<tr id="groups-notification-settings-invitation">
				<td></td>
				<td><?php _ex( 'A member invites you to join a group', 'group settings on notification settings page','buddypress' ) ?></td>
					<td>						
						<div class="switch-field">

								<input type="radio" name="notifications[notification_groups_invite]" id="notification-groups-invite-yes" value="yes" <?php checked( $group_invite, 'yes', true ) ?>/>


								<label for="notification-groups-invite-yes" ><?php
								/* translators: accessibility text */
								_e( 'Yes', 'buddypress' );
								?></label>

							     <input type="radio" name="notifications[notification_groups_invite]" id="notification-groups-invite-no" value="no" <?php checked( $group_invite, 'no', true ) ?>/>	

								<label for="notification-groups-invite-no" ><?php
								/* translators: accessibility text */
								_e( 'No', 'buddypress' );
								?></label> 
							</div>
				</td>
			</tr>
			<tr id="groups-notification-settings-info-updated">
				<td></td>
				<td><?php _ex( 'Group information is updated', 'group settings on notification settings page', 'buddypress' ) ?></td>

				<td>	<div class="switch-field">
								<input type="radio" name="notifications[notification_groups_group_updated]" id="notification-groups-group-updated-yes" value="yes" <?php checked( $group_update, 'yes', true ) ?>/>

								<label for="notification-groups-group-updated-yes" ><?php
								/* translators: accessibility text */
								_e( 'Yes', 'buddypress' );
								?></label>

							     <input type="radio" name="notifications[notification_groups_group_updated]" id="notification-groups-group-updated-no" value="no" <?php checked( $group_update, 'no', true ) ?>/>

								<label for="notification-groups-group-updated-no" ><?php
								/* translators: accessibility text */
								_e( 'No', 'buddypress' );
								?></label> 
							</div>
					</td>		
			</tr>
			<tr id="groups-notification-settings-promoted">
				<td></td>
				<td><?php _ex( 'You are promoted to a group administrator or moderator', 'group settings on notification settings page', 'buddypress' ) ?></td>

                  <td>
					<div class="switch-field">
								<input type="radio" name="notifications[notification_groups_admin_promotion]" id="notification-groups-admin-promotion-yes" value="yes" <?php checked( $group_promo, 'yes', true ) ?>/>

								<label for="notification-groups-admin-promotion-yes" ><?php
								/* translators: accessibility text */
								_e( 'Yes', 'buddypress' );
								?></label>

							    <input type="radio" name="notifications[notification_groups_admin_promotion]" id="notification-groups-admin-promotion-no" value="no" <?php checked( $group_promo, 'no', true ) ?>/>

								<label for="notification-groups-admin-promotion-no" ><?php
								/* translators: accessibility text */
								_e( 'No', 'buddypress' );
								?></label> 
							</div>
                    </td>
			</tr>
			<tr id="groups-notification-settings-request">
				<td></td>
				<td><?php _ex( 'A member requests to join a private group for which you are an admin', 'group settings on notification settings page', 'buddypress' ) ?></td>

                  <td>
					<div class="switch-field">
								<input type="radio" name="notifications[notification_groups_membership_request]" id="notification-groups-membership-request-yes" value="yes" <?php checked( $group_request, 'yes', true ) ?>/>

								<label for="notification-groups-membership-request-yes" ><?php
								/* translators: accessibility text */
								_e( 'Yes', 'buddypress' );
								?></label>

							    <input type="radio" name="notifications[notification_groups_membership_request]" id="notification-groups-membership-request-no" value="no" <?php checked( $group_request, 'no', true ) ?>/>

								<label for="notification-groups-membership-request-no" ><?php
								/* translators: accessibility text */
								_e( 'No', 'buddypress' );
								?></label> 
							</div>
                    </td>
			</tr>
			<tr id="groups-notification-settings-request-completed">
				<td></td>
				<td><?php _ex( 'Your request to join a group has been approved or denied', 'group settings on notification settings page', 'buddypress' ) ?></td>

                 <td>
					<div class="switch-field">
								<input type="radio" name="notifications[notification_membership_request_completed]" id="notification-groups-membership-request-completed-yes" value="yes" <?php checked( $group_request_completed, 'yes', true ) ?>/>

								<label for="notification-groups-membership-request-completed-yes" ><?php
								/* translators: accessibility text */
								_e( 'Yes', 'buddypress' );
								?></label>

							    <input type="radio" name="notifications[notification_membership_request_completed]" id="notification-groups-membership-request-completed-no" value="no" <?php checked( $group_request_completed, 'no', true ) ?>/>

								<label for="notification-groups-membership-request-completed-no" ><?php
								/* translators: accessibility text */
								_e( 'No', 'buddypress' );
								?></label> 
							</div>
                    </td>
			</tr>

			<?php

			/**
			 * Fires at the end of the available group settings fields on Notification Settings page.
			 *
			 * @since 1.0.0
			 */
			do_action( 'groups_screen_notification_settings' ); ?>

		</tbody>
	</table>

<?php
}
add_action( 'bp_notification_settings', 'groups_screen_notification_settings001' );


remove_action( 'bp_actions', 'bp_settings_action_general' );

function bp_settings_action_general01() {

	// Bail if not a POST action.
	if ( 'POST' !== strtoupper( $_SERVER['REQUEST_METHOD'] ) )
		return;

	// Bail if no submit action.
	if ( ! isset( $_POST['submit'] ) )
		return;

	// Bail if not in settings.
	if ( ! bp_is_settings_component() || ! bp_is_current_action( 'general' ) )
		return;

	// 404 if there are any additional action variables attached
	if ( bp_action_variables() ) {
		bp_do_404();
		return;
	}

	// Define local defaults
	$bp            = buddypress(); // The instance
	$email_error   = false;        // invalid|blocked|taken|empty|nochange
	$pass_error    = false;        // invalid|mismatch|empty|nochange
	$pass_changed  = false;        // true if the user changes their password
	$email_changed = false;        // true if the user changes their email
	$noti_changed = false;        // true if the user changes their email
	$feedback_type = 'error';      // success|error
	$feedback      = array();      // array of strings for feedback.
	$img_changed=false;
	$img_error   = false;  



	// Nonce check.
	check_admin_referer('bp_settings_general');

	// Validate the user again for the current password when making a big change.
	if ( ( is_super_admin() ) || ( !empty( $_POST['pwd'] ) && wp_check_password( $_POST['pwd'], $bp->displayed_user->userdata->user_pass, bp_displayed_user_id() ) ) || !empty($_POST['notifications']) ) {

		$update_user = get_userdata( bp_displayed_user_id() );

		/* Email Change Attempt ******************************************/

	

		if ( !empty( $_POST['email'] ) ) {

			// What is missing from the profile page vs signup -
			// let's double check the goodies.
			$user_email     = sanitize_email( esc_html( trim( $_POST['email'] ) ) );
			$old_user_email = $bp->displayed_user->userdata->user_email;



		    	if(!empty($_POST['notifications'])){

					       foreach ($_POST['notifications'] as $key => $value) {
	                     	bp_update_user_meta( bp_displayed_user_id(), $key, $value );
	                   }

	                 if(bp_avatar_ajax_upload_custom()==200) {
	                 	 $img_changed=true;
	                 }else if(bp_avatar_ajax_upload_custom()==300){
	                 	$img_changed=true;
                     $img_error=300;
	                 }
	                 else if(bp_avatar_ajax_upload_custom()==400){
	                 	  $img_changed=true;
                      $img_error=400;
	                 }
	          
	                   $noti_changed=true;
					}

          if(!empty($_POST['user_role'])){

            $current_user = wp_get_current_user();
            $user         = get_user_by( 'id', $current_user->ID );
            $user->set_role($_POST['user_role']);

          }

			// User is changing email address.
			if ( $old_user_email != $user_email ) {

				// Run some tests on the email address.
				$email_checks = bp_core_validate_email_address( $user_email );

				if ( true !== $email_checks ) {
					if ( isset( $email_checks['invalid'] ) ) {
						$email_error = 'invalid';
					}

					if ( isset( $email_checks['domain_banned'] ) || isset( $email_checks['domain_not_allowed'] ) ) {
						$email_error = 'blocked';
					}

					if ( isset( $email_checks['in_use'] ) ) {
						$email_error = 'taken';
					}
				}


				// Store a hash to enable email validation.
				if ( false === $email_error ) {
					$hash = wp_generate_password( 32, false );

					$pending_email = array(
						'hash'     => $hash,
						'newemail' => $user_email,
					);

					bp_update_user_meta( bp_displayed_user_id(), 'pending_email_change', $pending_email );



					$verify_link = bp_displayed_user_domain() . bp_get_settings_slug() . '/?verify_email_change=' . $hash;

					// Send the verification email.
					$args = array(
						'tokens' => array(
							'displayname'    => bp_core_get_user_displayname( bp_displayed_user_id() ),
							'old-user.email' => $old_user_email,
							'user.email'     => $user_email,
							'verify.url'     => esc_url( $verify_link ),
						),
					);
					bp_send_email( 'settings-verify-email-change', bp_displayed_user_id(), $args );

					// We mark that the change has taken place so as to ensure a
					// success message, even though verification is still required.
					$_POST['email'] = $update_user->user_email;
					$email_changed = true;
				}

			// No change.
			} else {
				$email_error = false;
			}

		// Email address cannot be empty.
		} else {
			$email_error = 'empty';
		}

		/* Password Change Attempt ***************************************/

		if ( !empty( $_POST['pass1'] ) && !empty( $_POST['pass2'] ) ) {

			if ( ( $_POST['pass1'] == $_POST['pass2'] ) && !strpos( " " . $_POST['pass1'], "\\" ) ) {
              $update_user->user_pass = $_POST['pass1'];
              $pass_changed = true;
				// Password change attempt is successful.
				/*if ( ( ! empty( $_POST['pwd'] ) && $_POST['pwd'] != $_POST['pass1'] ) || is_super_admin() )  {
					

				// The new password is the same as the current password.
				} else {
					$pass_error = 'same';
				}*/

			// Password change attempt was unsuccessful.
			} else {
				$pass_error = 'mismatch';
			}

		// Both password fields were empty.
		} elseif ( empty( $_POST['pass1'] ) && empty( $_POST['pass2'] ) ) {
			$pass_error = false;

		// One of the password boxes was left empty.
		} elseif ( ( empty( $_POST['pass1'] ) && !empty( $_POST['pass2'] ) ) || ( !empty( $_POST['pass1'] ) && empty( $_POST['pass2'] ) ) ) {
			$pass_error = 'empty';
		}

		// The structure of the $update_user object changed in WP 3.3, but
		// wp_update_user() still expects the old format.
		if ( isset( $update_user->data ) && is_object( $update_user->data ) ) {
			$update_user = $update_user->data;
			$update_user = get_object_vars( $update_user );

			// Unset the password field to prevent it from emptying out the
			// user's user_pass field in the database.
			// @see wp_update_user().
			if ( false === $pass_changed ) {
				unset( $update_user['user_pass'] );
			}
		}

		// Clear cached data, so that the changed settings take effect
		// on the current page load.
		if ( ( false === $email_error ) && ( false === $pass_error ) && ( wp_update_user( $update_user ) ) ) {
			wp_cache_delete( 'bp_core_userdata_' . bp_displayed_user_id(), 'bp' );
			$bp->displayed_user->userdata = bp_core_get_core_userdata( bp_displayed_user_id() );
		}

	// Password Error.
	} else {
		$pass_error = 'invalid';
	}

	switch ( $img_error ) {

		case 300 :
			$feedback['img_error']  = __( 'Unsupported file type', 'buddypress' );
			break;
		case 400 :
			$feedback['img_error']  = __( 'Please upload image smaller than 200KB', 'buddypress' );
			break;
		case false :
			// No change.
			break;

	}

	// Email feedback.
	switch ( $email_error ) {
		case 'invalid' :
			$feedback['email_invalid']  = __( 'That email address is invalid. Check the formatting and try again.', 'buddypress' );
			break;
		case 'blocked' :
			$feedback['email_blocked']  = __( 'That email address is currently unavailable for use.', 'buddypress' );
			break;
		case 'taken' :
			$feedback['email_taken']    = __( 'That email address is already taken.', 'buddypress' );
			break;
		case 'empty' :
			$feedback['email_empty']    = __( 'Email address cannot be empty.', 'buddypress' );
			break;
		case false :
			// No change.
			break;
	}

	// Password feedback.
	switch ( $pass_error ) {
		case 'invalid' :
			$feedback['pass_error']    = __( 'Your current password is invalid.', 'buddypress' );
			break;
		case 'mismatch' :
			$feedback['pass_mismatch'] = __( 'The new password fields did not match.', 'buddypress' );
			break;
		case 'empty' :
			$feedback['pass_empty']    = __( 'One of the password fields was empty.', 'buddypress' );
			break;
		case 'same' :
			$feedback['pass_same'] 	   = __( 'The new password must be different from the current password.', 'buddypress' );
			break;
		case false :
			// No change.
			break;
	}

  if( true === $img_changed  && $img_error > 0){

  $feedback['nochange'] = '';

}

	// No errors so show a simple success message.
	elseif ( ( ( false === $email_error ) || ( false == $pass_error ) ) && ( ( true === $pass_changed ) || ( true === $email_changed ) ) ||  ( true === $noti_changed ) || ( true === $img_changed )  ) {
		$feedback[]    = __( 'Your settings have been saved.', 'buddypress' );
		$feedback_type = 'success';

	// Some kind of errors occurred.
	} elseif ( ( ( false === $email_error ) || ( false === $pass_error ) ) && ( ( false === $pass_changed ) || ( false === $email_changed ) ) ) {
		if ( bp_is_my_profile() ) {
			$feedback['nochange'] = __( 'No changes were made to your account.', 'buddypress' );
		} else {
			$feedback['nochange'] = __( 'No changes were made to this account.', 'buddypress' );
		}
	}
  //elseif ( ( false !== $img_error )) {
	
			//$feedback['nochange'] = $feedback['img_error'];
	
	//}


	// Set the feedback.
	bp_core_add_message( implode( "\n", $feedback ), $feedback_type );

	/**
	 * Fires after the general settings have been saved, and before redirect.
	 *
	 * @since 1.5.0
	 */
	do_action( 'bp_core_general_settings_after_save' );

	// Redirect to prevent issues with browser back button.
	bp_core_redirect( trailingslashit( bp_displayed_user_domain() . bp_get_settings_slug() . '/general' ) );
}
add_action( 'bp_actions', 'bp_settings_action_general01' );




function bp_avatar_ajax_upload_custom() {

  $item_id=bp_displayed_user_id();
	$avatar_dir = 'avatars';
	$avatar_folder_dir = apply_filters( 'bp_core_avatar_folder_dir', $avatar_dir . '/' . $item_id, $item_id, 'user', 'avatars' );

	$upload_dir   = wp_upload_dir();

	//pr($upload_dir['basedir']);
	 $avatarPath= $upload_dir['basedir']."/".$avatar_folder_dir."/";
    if ( ! file_exists( $avatarPath ) ) {
        wp_mkdir_p( $avatarPath );
    }


   $filename=$_FILES['file']['name'];

    $ext = pathinfo($filename, PATHINFO_EXTENSION);

    $fullImageName=time().'-bpfull.'.$ext;
    $thumbImageName=time().'-bpthumb.'.$ext;

    $fullPathThumb= $avatarPath.$thumbImageName;
    $fullPath= $avatarPath.$fullImageName;
        
$max_file_size = 1024*200; // 200kb
$valid_exts = array('jpeg', 'jpg', 'png', 'gif');
// thumbnail sizes
$sizes = array(250 => 250, 500,500);

if (isset($_FILES['file']) && ($_FILES['file']['size'] !=0 )) {


    foreach (glob($avatarPath."/*-bpthumb.*") as $filename) {  
           unlink($filename);
        } 

    foreach (glob($avatarPath."/*-bpfull.*") as $filename1) {  
           unlink($filename1);
        }   


  if( $_FILES['file']['size'] < $max_file_size ){
    // get file extension
    $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
    if (in_array($ext, $valid_exts)) {
      /* resize image */
       move_uploaded_file( $file['tmp_name'] , $fullPathThumb );
       move_uploaded_file( $file['tmp_name'] , $fullPath );
      resize(250, 250,'file',$fullPathThumb);
      resize(500, 500,'file', $fullPath);
        $msg = 200;
    } else {
      $msg = 300;  /*Unsupported file*/
    }
  } else{
    $msg = 400;  /*Please upload image smaller than 200KB*/
  }
  return $msg;
}

}



/**
 * Image resize
 * @param int $width
 * @param int $height
 */
function resize($width, $height,$filename,$filePath){
  /* Get original image x y*/
  list($w, $h) = getimagesize($_FILES[$filename]['tmp_name']);
  /* calculate new image size with ratio */
  $ratio = max($width/$w, $height/$h);
  $h = ceil($height / $ratio);
  $x = ($w - $width / $ratio) / 2;
  $w = ceil($width / $ratio);
  /* new file name */
  $path = $filePath;
  /* read binary data from image file */
  $imgString = file_get_contents($_FILES[$filename]['tmp_name']);
  /* create image from string */
  $image = imagecreatefromstring($imgString);
  $tmp = imagecreatetruecolor($width, $height);
  imagecopyresampled($tmp, $image,
    0, 0,
    $x, 0,
    $width, $height,
    $w, $h);
  /* Save image */
  switch ($_FILES[$filename]['type']) {
    case 'image/jpeg':
      imagejpeg($tmp, $path, 100);
      break;
    case 'image/png':
      imagepng($tmp, $path, 0);
      break;
    case 'image/gif':
      imagegif($tmp, $path);
      break;
    default:
      exit;
      break;
  }
  /* cleanup memory */
  imagedestroy($image);
  imagedestroy($tmp);
}



function create_html_for_events_list(){
   $html='';
   ob_start();
     include( get_stylesheet_directory() . '/event_list_sorted.php');
     $html.=ob_get_contents();
    ob_get_clean();
    return $html;

}
add_shortcode('sorted_event_list','create_html_for_events_list');


function create_html_my_profile_event_list(){
   $html='';
   ob_start();
     include( get_stylesheet_directory() . '/my_profile_event_list.php');
     $html.=ob_get_contents();
    ob_get_clean();
    return $html;

}
add_shortcode('my_profile_event_list','create_html_my_profile_event_list');




/* Main Event Page shortcode here */


function create_html_for_events_list_for_main(){
   $html='';
   ob_start();
     include( get_stylesheet_directory() . '/event_list_sorted_main_event.php');
     $html.=ob_get_contents();
    ob_get_clean();
    return $html;

}
add_shortcode('Main_Event_page','create_html_for_events_list_for_main');



/* Main Event Page shortcode end here */


function create_html_for_upcoming_events_list(){
   $html='';
   ob_start();
     include( get_stylesheet_directory() . '/upcoming_events_list.php');
     $html.=ob_get_contents();
    ob_get_clean();
    return $html;

}
add_shortcode('sorted_upcoming_event_list','create_html_for_upcoming_events_list');


function create_html_for_latest_photos_list(){
   $html='';
   ob_start();
     include( get_stylesheet_directory() . '/latest_photos_list_feed.php');
     $html.=ob_get_contents();
    ob_get_clean();
    return $html;

}
add_shortcode('latest_photos_list_of_user','create_html_for_latest_photos_list');



function get_location_by_id($id){
  global $wpdb;

  $get_location= $wpdb->get_row("select * from wp_em_locations where location_id='$id' ");
  return $get_location;


}


function get_itinerary_by_id($post_id){

 $itinerary_query = new WP_Query(
    array(
      'post_type' => 'itinerary',
      'meta_query' => array(
        'meta_key' => 'event_id',
        'meta_value' => $post_id
      ),
      'posts_per_page' => -1
    )
  );
 $itinerary_ar=array();
  if ( $itinerary_query->have_posts() ) {
     $i=0;
    while ( $itinerary_query->have_posts() ) {
      $itinerary_query->the_post();

      $itineraryId = get_the_id();
      $itineraryTitle = get_the_title();
      $itineraryStart = get_post_custom()["start"][0];
      $itineraryEnd = get_post_custom()["end"][0];
      $itineraryDate = get_post_custom()["date"][0];

		     $itinerary_ar[$i]['title']= $itineraryTitle; 
		     $itinerary_ar[$i]['start']= $itineraryStart; 
		     $itinerary_ar[$i]['end']= $itineraryEnd; 
		     $itinerary_ar[$i]['date']= $itineraryDate; 

		      $i++;

  }
}

return  $itinerary_ar;

}



function get_fund_details_event($event_id){
   global $wpdb;

    $getFund= $wpdb->get_results("select sum(ticket_price) as total_fund from wp_em_tickets where event_id='$event_id' ");
    return (!empty($getFund[0]->total_fund)) ? $getFund[0]->total_fund : 0.00;

}

function get_total_participents_event($event_id){
   global $wpdb;

    $getFund= $wpdb->get_results("select * from wp_em_bookings t1 left join wp_users t2 ON(t1.person_id=t2.ID) where event_id='$event_id' group by t2.ID ");
    return  $getFund;

}


function get_time_difference($time1, $time2) 
{ 
    $time1 = strtotime("1/1/1980 $time1"); 
    $time2 = strtotime("1/1/1980 $time2"); 
     
    if ($time2 < $time1) 
    { 
        $time2 = $time2 + 86400; 
    } 
     
    return ($time2 - $time1) / 3600; 
     
}  




add_filter('bp_get_options_nav_home','filter_second_nav');
function filter_second_nav($subnav_item, $selected_item ){

	 	return str_replace('Home', 'Feed', $subnav_item);
}

add_filter('bp_get_options_nav_nav-invite-anyone','filter_second_nav1');
function filter_second_nav1($subnav_item, $selected_item ){
	return $selected_item='';
}


add_filter('bp_get_options_nav_events','filter_second_nav2');
function filter_second_nav2($subnav_item, $selected_item ){

global $wp_query;
// pr($wp_query);
$curPage= $wp_query->query['pagename'];
$explode= explode('/',$curPage);
/*echo end($explode);*/

 $link =bp_get_group_permalink('/');

 //pr($explode);
 $userId  = get_current_user_id();
 $link= str_replace('chapters',$curPage , $link);
/* $link= str_replace(end($explode),'events' , $link);*/
 if(count($explode) == 2){
 	$link= $link.'events';
 }else{
  $link= str_replace('chapters',$curPage , $link);
  $link= str_replace(end($explode),'events' , $link);	
 }

 $args1=array(
	'post_type'=>'event',
	'posts_per_page'=>-1,
	'post_status'=>'publish',
  'author'     => $userId,
	);

$the_query1 = new WP_Query( $args1 );
	return '<li id="events-groups-li" class=""><a id="events" href="'.$link.'">Events <span>'.$the_query1->post_count.'</span></a></li>';
}
add_filter('bp_get_options_nav_admin','filter_second_nav3');
function filter_second_nav3($subnav_item, $selected_item ){
	return $selected_item='';
}


function custom_pagination($numpages = '', $pagerange = '', $paged='') {


  if (empty($pagerange)) {
    $pagerange = 2;
  }
 
  /**
   * This first part of our function is a fallback
   * for custom pagination inside a regular loop that
   * uses the global $paged and global $wp_query variables.
   * 
   * It's good because we can now override default pagination
   * in our theme, and use this function in default quries
   * and custom queries.
   */
  global $paged;
  if (empty($paged)) {
    $paged = 1;
  }
  if ($numpages == '') {
    global $wp_query;
    $numpages = $wp_query->max_num_pages;
    if(!$numpages) {
        $numpages = 1;
    }
  }
 
  /** 
   * We construct the pagination arguments to enter into our paginate_links
   * function. 
   */
  $pagination_args = array(
    'base'            => get_pagenum_link(1) . '%_%',
    'format'          => 'page/%#%',
    'total'           => $numpages,
    'current'         => $paged,
    'show_all'        => False,
    'end_size'        => 1,
    'mid_size'        => $pagerange,
    'prev_next'       => True,
    'prev_text'       => __('&laquo; Previous Page'),
    'next_text'       => __('Next Page &raquo;'),
    'type'            => 'plain',
    'add_args'        => false,
    'add_fragment'    => ''
  );

  $paginate_links = paginate_links($pagination_args);
  
  if ($paginate_links) {
  	echo '<div class="ast-pagination ast-custom-pagination">';
    echo "<nav class='navigation pagination'>";
    	echo '<div class="nav-links">';
      echo $paginate_links;
       echo "</div>";
    echo "</nav>";
    echo "</div>";
  }
 
}


function custom_pagination2($numpages = '', $pagerange = '', $paged='') {


  if (empty($pagerange)) {
    $pagerange = 2;
  }
 
  /**
   * This first part of our function is a fallback
   * for custom pagination inside a regular loop that
   * uses the global $paged and global $wp_query variables.
   * 
   * It's good because we can now override default pagination
   * in our theme, and use this function in default quries
   * and custom queries.
   */
  global $paged;
  if (empty($paged)) {
    $paged = 1;
  }
  if ($numpages == '') {
    global $wp_query;
    $numpages = $wp_query->max_num_pages;
    if(!$numpages) {
        $numpages = 1;
    }
  }
 
  /** 
   * We construct the pagination arguments to enter into our paginate_links
   * function. 
   */
  $pagination_args = array(
    'base'            => get_pagenum_link(1) . '%_%',
    'format'          => 'page/%#%',
    'total'           => $numpages,
    'current'         => $paged,
    'show_all'        => False,
    'end_size'        => 1,
    'mid_size'        => $pagerange,
    'prev_next'       => True,
    'prev_text'       => __('&laquo; Previous Page'),
    'next_text'       => __('Next Page &raquo;'),
    'type'            => 'plain',
    'add_args'        => false,
    'add_fragment'    => ''
  );

  $paginate_links = paginate_links($pagination_args);
  
  if ($paginate_links) {
    $ht .= '<div class="ast-pagination ast-custom-pagination">';
    $ht .= "<nav class='navigation pagination'>";
    $ht .= '<div class="nav-links">';
     $ht .= $paginate_links;
    $ht .= "</div>";
    $ht .= "</nav>";
    $ht .= "</div>";

    return $ht;
  }
 
}

function custom_pagination3($numpages = '', $pagerange = '', $paged='') {


$get_pagenum_link = explode('?page=',get_pagenum_link(1));
if(count($get_pagenum_link) ==2){
    $get_pagenum_link = $get_pagenum_link[0];
}else{
    $get_pagenum_link = $get_pagenum_link[0];
}



  if (empty($pagerange)) {
    $pagerange = 2;
  }
 
  /**
   * This first part of our function is a fallback
   * for custom pagination inside a regular loop that
   * uses the global $paged and global $wp_query variables.
   * 
   * It's good because we can now override default pagination
   * in our theme, and use this function in default quries
   * and custom queries.
   */

  if (empty($paged)) {
    $paged = 1;
  }
  if ($numpages == '') {
    global $wp_query;
    $numpages = $wp_query->max_num_pages;
    if(!$numpages) {
        $numpages = 1;
    }
  }

 
  /** 
   * We construct the pagination arguments to enter into our paginate_links
   * function. 
   */
  $pagination_args = array(
    'base'            => $get_pagenum_link . '%_%',
    'format'          => '?page=%#%',
    'total'           => $numpages,
    'current'         => $paged,
    'show_all'        => False,
    'end_size'        => 1,
    'mid_size'        => $pagerange,
    'prev_next'       => True,
    'prev_text'       => __('&laquo; Previous Page'),
    'next_text'       => __('Next Page &raquo;'),
    'type'            => 'plain',
    'add_args'        => false,
    'add_fragment'    => ''
  );

  $paginate_links = paginate_links($pagination_args);



  if ($paginate_links) {

    $ht .= '<div class="ast-pagination ast-custom-pagination">';
     $ht .= "<nav class='navigation pagination'>";
      $ht .= '<div class="nav-links">';
      $ht .= $paginate_links;
       $ht .= "</div>";
    $ht .= "</nav>";
    $ht .= "</div>";

    return $ht;
  }
 
}


function fcuintra_bp_group_navigation () {

    if ( bp_is_group_single() ) {

    	$user = wp_get_current_user();
		 $role = ( array ) $user->roles;

		$msgUrl =  bp_loggedin_user_domain().'settings/';

      if (in_array('administrator', $role) || in_array('bbp_moderator', $role))
      {

       echo '<li id="forum-anyone-groups-li" class="custom_single_group_nav"><a id="" href="'.site_url('create-forums').'">Create New Forum</a></li>';

      }

		
			if (in_array('administrator', $role) || in_array('bbp_keymaster', $role))
			{
				echo '<li id="invite-anyone-groups-li" class="custom_single_group_nav"><a id="user-invite-anyone" href="">Send Invites</a></li>';
			}

      
		
	}


}
add_action ( 'bp_group_options_nav', 'fcuintra_bp_group_navigation');


function get_count_invities($status=array('publish')){

	global $bp;
	$args = array(
		'post_type'=>'ia_invites',
		'posts_per_page'=> -1,
		'post_status'=>$status,
		'author'=>get_current_user_id(),
		'meta_query' => array(
				array(
					'key'     => 'bp_ia_accepted',
					'value'   => '',
				),
			),
		);
	$str = new WP_Query($args);
	$i=0;
	foreach ($str->posts as $key => $value) {
		if(!get_post_meta($value->ID,'bp_ia_accepted',true)){
			  $i++;
		}	
	}

	return $i;
}



//add_action('wp_ajax_custom_auth_login','custom_auth_login');
add_action('wp_ajax_nopriv_custom_auth_login','custom_auth_login');
/* Login ajax callback */
  function custom_auth_login(){
$nonce = $_REQUEST['_login_nonce'];
	$result=array();
	if(empty($_POST['g-recaptcha-response'])){
	$result['status']='fail';			  
	$result['message']="Please verify captcha..";
	echo json_encode($result);	
	die;
	}
if(wp_verify_nonce($nonce, 'log-auth-nonce')) {

				$user_login     = esc_attr($_POST["username"]);
				$user_password  = esc_attr($_POST["password"]);
				$user_email     = esc_attr($_POST["username"]);

			   
			    if(filter_var($user_email, FILTER_VALIDATE_EMAIL)) { 
			    	 $userinfo = get_user_by('email', $user_email);	
			    }else{
			    	$userinfo = get_user_by('login', $user_email);
			    }

				$user_data = array(
				    'user_login'    =>      $user_login,
				    'user_pass'     =>      $user_password,
				    'user_email'    =>      $user_email,
				    'role'          =>      'student'
				);

				// Inserting new user to the db
				//wp_insert_user( $user_data );

				$creds = array();
				$creds['user_login'] = $userinfo->user_login;
				$creds['user_password'] = $user_password;
				$creds['remember'] = true;

				$user = wp_signon($creds, false );
			
				if ( is_wp_error( $user ) ) {
					  $error_string = "Username and password invalid!";	
					  $result['status']='fail';			  
					  $result['message']=$error_string;			  

				}else{
	             	$userID = $user->ID;

					wp_set_current_user( $userID, $user_login );
					wp_set_auth_cookie( $userID);
					do_action( 'wp_login', $user_login );
           //$profileURl=  home_url( '/members/' . bp_core_get_username( get_current_user_id() ) . '/settings/' );
          $profileURl=  home_url( '/members/' . bp_core_get_username( get_current_user_id() ) );
					  $result['status']='ok';			  
            $result['message']="";    
					  $result['url']=$profileURl;	  

				}

				echo json_encode($result);
		}else{
			$result['status']='fail';			  
			$result['message']='Please login again..';
			echo json_encode($result);	

		}
		die;

  }

add_action('wp_ajax_custom_reset_password','custom_reset_password');
add_action('wp_ajax_nopriv_custom_reset_password','custom_reset_password');
function custom_reset_password(){
$email= $_POST['email'];
$nonce=$_POST['_reset_nonce'];
if(empty($_POST['g-recaptcha-response'])){
	$result['status']='fail';			  
	$result['message']="Please verify captcha..";
	echo json_encode($result);	
	die;
	}

if(wp_verify_nonce($nonce, 'log-reset-nonce')) {

     if( empty( $email ) ) {
			$error = 'Enter a username or e-mail address..';
		} else if( ! is_email( $email )) {
			$error = 'Invalid username or e-mail address.';
		} else if( ! email_exists($email) ) {
			$error = 'There is no user registered with that email address.';
		}
	if($error){
		echo json_encode(array('status'=>'fail','message'=>$error));
	}else{

		   $user = get_user_by( 'email', $_POST['email'] );
		       $unique_id= md5($user->ID);
		        update_user_meta( $user->ID,'reset_pass',$unique_id);
				$email=$_POST['email'];      	
		        $to = $email;
				$subject = 'Your new password';
				$sender = get_option('name');
				$link= site_url('reset-pass/').'?email='.$email.'&id='.$unique_id;
				$alink='<a href="'.$link.'">Reset Now</a>';
				$message = 'You can reset new password, Please click on password reset link: '.$alink;

				$headers[] = 'MIME-Version: 1.0' . "\r\n";
				$headers[] = 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers[] = "X-Mailer: PHP \r\n";
				$headers[] = 'From: '.$sender.' < '.$email.'>' . "\r\n";

				$mail = wp_mail( $to, $subject, $message, $headers );
				if( $mail ){
					echo json_encode(array('status'=>'ok','message'=>'Check your email address for you new password.'));
			    } else {				  
				  echo json_encode(array('status'=>'fail','message'=>'Oops something went wrong updaing your account.'));
			    }
	    }
}else{
	echo json_encode(array('status'=>'fail','message'=>'Please trying again'));
}
die;
}

/* Login ajax callback */


add_action('wp_ajax_custom_reset_password_now','custom_reset_password_now');
add_action('wp_ajax_nopriv_custom_reset_password_now','custom_reset_password_now');
function custom_reset_password_now(){
    $nonce=$_POST['_reset_nonce'];
	if(wp_verify_nonce($nonce, 'log-reset-nonce')) {
		$password= $_POST['password'];
		$password_new= $_POST['password_new'];
		$error='';
		if( empty( $password ) && empty( $password_new )) {
			$error='Please enter password and confirm password!';
		}
		if( $password !=$password_new) {
			$error='Password does not match!';
		}
		if($error){
			echo json_encode(array('status'=>'fail','message'=>$error));
		}else{

			 $user = get_user_by( 'email', $_POST['email'] );
             wp_set_password($password, $user->ID );
             delete_user_meta($user->ID,'reset_pass',''); 
			echo json_encode(array('status'=>'ok','message'=>"Password changed successfully!"));
		}

	}
die;
}

/* request to join mail send here */

add_action('wp_ajax_custom_request_now','custom_request_now');
add_action('wp_ajax_nopriv_custom_request_now','custom_request_now');
function custom_request_now(){
    $nonce=$_POST['_reset_nonce'];
	if(wp_verify_nonce($nonce, 'log-request-nonce')) {
		
		if(empty($_POST['g-recaptcha-response'])){
		$result['status']='fail';			  
		$result['message']="Please verify captcha..";
		echo json_encode($result);	
		die;
		}

		$fname    = sanitize_text_field($_POST['full_name']);
        $email1    = sanitize_email($_POST['email']);
        $message  = sanitize_text_field($_POST['message']);

        if( empty( $fname ) ) {
			$error = 'Please enter full name';
		} else if(empty( $email1 )) {
			$error = 'Please enter valid email address';
		} else if( empty( $message )) {
			$error = 'Please enter your message';
		}

		if($error){
		  echo json_encode(array('status'=>'fail','message'=>$error));
	    }else{

				  	
		        $to      = get_option('admin_email');
		        $to      = 'dev.smapp@gmail.com';
				$subject = 'Request an invitation.';
				$sender  = get_option('name');

				$headers[] = 'MIME-Version: 1.0' . "\r\n";
				$headers[] = 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers[] = "X-Mailer: PHP \r\n";
				$headers[] = 'From: '.$sender.' < '.$email1.'>' . "\r\n";

				$messageBody = '<table>

									<tr><td>Full Name:<td><td>'.$fname.'<td></tr>
									<tr><td>Email:<td><td>'.$email1.'<td></tr>
									<tr><td>Message:<td><td>'.$message.'<td></tr>

								</table>';
				

				$mail = wp_mail( $to, $subject, $messageBody, $headers );
				if( $mail ){
					echo json_encode(array('status'=>'ok','message'=>'Your invitation has been sucessfully!'));
			    } else {				  
				  echo json_encode(array('status'=>'fail','message'=>'Oops something went wrong updaing your account.'));
			    }

	    }

	}else{

		
		echo json_encode(array('status'=>'fail','message'=>'Please trying again'));
	}
die;
}


function update_gallery_url_upload($gallery_id,$link){
  if($gallery_id){
		$parsed= parse_url($gallery_id);
	    unset($parsed['query']);
	    $path=  str_replace('/manage/add/','',$parsed['path']);
     	$link=site_url($path);
  }
return $link;
}

add_filter('mpp_get_gallery_add_media_url','update_gallery_url_upload');

add_action('wp_ajax_save_album_single_titles','save_album_single_titles');
add_action('wp_ajax_nopriv_save_album_single_titles','save_album_single_titles');

function save_album_single_titles(){

	 $error=array();
		  foreach ($_POST['galleryTitle'] as $key => $value) {
		  	  if(empty($value)){
		  	  	 $error[$key]='Title can not blank';
		  	  }
		  }

	  if(empty($error)){
	  	 foreach ($_POST['galleryTitle'] as $key => $value) {
		  $my_post = array(
		      'ID'           => $key,
		      'post_title'   => $value,
		  );
		  wp_update_post( $my_post );
		}	
		echo json_encode(array('status'=>'ok','message'=>'Album is updated!'));
		die;
	}else{
		echo json_encode(array('status'=>'fail','message'=>$error));
			die;
	}

}
add_action('wp_ajax_delete_album_single_frnt','delete_album_single_frnt');
add_action('wp_ajax_nopriv_delete_album_single_frnt','delete_album_single_frnt');

function delete_album_single_frnt(){
		 $post_id= $_POST['post_id'];
		 wp_delete_post($post_id, true);
		 echo 1;	
		 die;
}

add_action('wp_ajax_save_album_titles','save_album_titles');
add_action('wp_ajax_nopriv_save_album_titles','save_album_titles');

function save_album_titles(){

 $error=array();
	  foreach ($_POST['galleryTitle'] as $key => $value) {
	  	  if(empty($value)){
	  	  	 $error[$key]='Title can not blank';
	  	  }
	  }

  if(empty($error)){
  	 foreach ($_POST['galleryTitle'] as $key => $value) {
	  $my_post = array(
	      'ID'           => $key,
	      'post_title'   => $value,
	  );
	  wp_update_post( $my_post );
	}	
	echo json_encode(array('status'=>'ok','message'=>'Albums are updated!'));
	die;
}else{
	echo json_encode(array('status'=>'fail','message'=>$error));
		die;
}
}

function delete_album_frnt(){
	$post_id= $_POST['post_id'];


	/*Delete child posts*/
		$args = array( 
		    'post_parent' => $post_id,
		    'post_type' => 'mpp-gallery'
		);

		$posts = get_posts( $args );

		if (is_array($posts) && count($posts) > 0) {
		    // Delete all the Children of the Parent Page
		    foreach($posts as $post){
		    	delete_associated_media22($post->ID);
		        wp_delete_post($post->ID, true);

		    }
		}
	 delete_associated_media( $post_id );	
	 wp_delete_post($post_id, true);		

   echo 1;
die;
}

function delete_associated_media22( $id ) {

    $media = get_children( array(
        'post_parent' => $id,
        'post_type'   => 'attachment'
    ) );

    if( empty( $media ) ) {
        return;
    }

    foreach( $media as $file ) {
        wp_delete_attachment( $file->ID );
    }
}


function delete_associated_media( $id ) {
	$post_id= $_POST['post_id'];

    $media = get_children( array(
        'post_parent' => $post_id,
        'post_type'   => 'attachment'
    ) );

    if( empty( $media ) ) {
        return;
    }

    foreach( $media as $file ) {
        wp_delete_attachment( $file->ID );
    }
}



add_action('wp_ajax_delete_album_frnt','delete_album_frnt');
add_action('wp_ajax_nopriv_delete_album_frnt','delete_album_frnt');

add_action('wp_ajax_custom_signup_invite','custom_signup_invite');
add_action('wp_ajax_nopriv_custom_signup_invite','custom_signup_invite');

function custom_signup_invite(){
$nonce = $_REQUEST['_signup_nonce_added'];
  if(wp_verify_nonce($nonce, '_signup-auth-nonce-added')) {

      $password= $_POST['password'];
      $password_new= $_POST['cpassword'];
      $email= $_POST['email'];
      $username= $_POST['username'];
      $group_id= $_POST['groupId'];
      $inviter_id= $_POST['inviter_id'];
       $recipientRole= $_POST['recipientRole'];
       $inviter_post_id= $_POST['inviter_post_id'];
       $fullname= $_POST['fullname'];
       $is_admin=0;  

      $error='';
       if (empty( $fullname ) ){
          $error['fullname']='fullname is required!';
       }

       if (empty( $email ) ){
          $error['email']='Email id is required!';
       }
       if (email_exists( $email ) ){
          $error['email']='This Email id already in use!';
       }

       if (empty( $username ) ){
          $error['username']='Username is required!';
       }
       if (username_exists( $username ) ){
          $error['username']='Username name already in use!';
       }

      if( empty( $password )) {
        $error['pass']='Please enter password!';
      }

      if( empty( $password ) && empty( $password_new )) {
        $error['repass']='Please enter confirm password!';
      }
      if( $password !=$password_new) {
        $error['repass']='Password does not match!';
      }
  $response=array();
  if($error){
    $response =array('status'=>'fail','err'=>$error);
    }else{

         $user_id = wp_create_user( $username, $password, $email );

          //if($recipientRole=="bbp_keymaster"){

            $_POST['clubpack_user_id']   = $user_id;
            $_POST['clubname']           = 'excelmultisport';
            $_POST['role']               = $recipientRole;

            $remote_userId =  clubpack_remote_user($_POST);
         
          //}
          
         if( !is_wp_error($user_id) ) {
                   $user = get_user_by( 'id', $user_id );
                   $user->set_role($recipientRole);
               }
           
        if($recipientRole=="bbp_keymaster"){
                   $is_admin=1;
        }

        update_user_meta($user_id,'custom_role1',$recipientRole);
        update_user_meta($user_id,'groupId',$group_id);
        update_user_meta($user_id,'inviter_id',$inviter_id);
        update_user_meta($user_id,'inviter_post_id',$inviter_post_id);
         update_user_meta($user_id,'fullname',$fullname);

        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
/*         groups_accept_invite( $user_id, $group_id );
        groups_join_group($group_id, $user_id);*/

       global $wpdb;
          $data=array(
            'group_id'=>$group_id,
            'user_id'=>$user_id,
            'inviter_id'=>0,
            'is_admin'=>0,
            'is_mod'=>0,
            'date_modified'=>date('Y-m-d h:i:s'),
            'user_title'=>'',
            'is_confirmed'=>1,
            'is_banned'=>0,
            'invite_sent'=>1,
            );
          $wpdb->insert('wp_bp_groups_members',$data);

        

          $getMemberCount= intval(get_groupMeta($group_id,'total_member_count'))+1;
         /* echo "Count:".$getMemberCount;*/

         update_groupMeta($group_id,'total_member_count',$getMemberCount);
          update_post_meta($inviter_post_id,'bp_ia_accepted',date('Y-m-d h:i:s'));
          update_post_meta($inviter_post_id,'bp_ia_is_cloudsponge','No');
          $profileURl=  home_url( '/members/' . bp_core_get_username( get_current_user_id() ) . '/settings/' );
        $response =array('status'=>'ok','message'=>'Congratulations you have successfully registered!!','url'=>$profileURl);
    }

    echo json_encode($response);
}
die;
}


function get_groupMeta($group_id,$key){
   global $wpdb,$table_prefix;
   $table =$table_prefix.'bp_groups_groupmeta';

   $get= $wpdb->get_row("SELECT * FROM $table WHERE `group_id` = '$group_id' and meta_key='$key' ");

   return $get->meta_value;
}

function update_groupMeta($group_id,$key,$value){
   global $wpdb,$table_prefix;
   $table =$table_prefix.'bp_groups_groupmeta';

   $get= $wpdb->query("update $table set meta_value='$value' where group_id='$group_id' and meta_key='$key' ");

   return $get;
}



function after_bp_activated_user001($user_id, $key, $user) {
      $group_id= $_POST['group_id'];
      $inviter_id= $_POST['inviter_id'];
     //var_dump(groups_accept_invite( $user_id, $group_id )) ;
      do_action( 'groups_accept_invite', $user_id, $group_id, $inviter_id );
}


function buddydev_add_user_to_groups_on_account_activation( $user_id ) {
 
    if ( ! function_exists( 'groups_join_group' ) ) {
        return ;
    }

      $group_id=get_user_meta($user_id,'group_id',true);

 
    // Change the group ids with your own group ids
    $group_ids = array($group_id );
 
    foreach ( $group_ids as $group_id ) {
        // add user to group
        groups_join_group( $group_id, $user_id );
    }
}
add_action( 'bp_core_activated_user', 'buddydev_add_user_to_groups_on_account_activation', 0 );



/*
var_dump( groups_accept_invite( 713, 1079 ));
var_dump(  groups_join_group( 1079, 713 ));
var_dump(   groups_check_user_has_invite( 713, 1079 ));*/
/*var_dump(groups_check_for_membership_request( 713, 1079 ) );*/

add_action( 'wp_enqueue_scripts', array(&$this, 'new-custom-css'), 200 );

/*------ custome code for add friend------------*/

function bp_ajax_add_friend() 
{
  global $bp,$wpdb;
  $friend_id = intval($_POST['userid']);
  $response=array();
  if($friend_id == 0)
  {
    $msg   =  'Username invalid!!';
    $response =array('status'=>'fail','msg'=>$msg);
    echo json_encode($response);
    die();
  }
  $initiator_userid = get_current_user_id();
  $table = $wpdb->prefix.'bp_friends';
 

  $check   = $wpdb->get_row($wpdb->prepare("SELECT * From $table WHERE  `friend_user_id` = %d AND `initiator_user_id` = %d",$friend_id,$initiator_userid),ARRAY_A);
  $is_confir  = $check['is_confirmed'];
  if(count($check) > 0)
  {
    if($is_confir == 0)
    {
      $msg   =  'Already invited!!';
      $response =array('status'=>'fail','msg'=>$msg);
    }
    else
    {
      $msg   =  'Already Added!!';
      $response =array('status'=>'fail','msg'=>$msg);
    }
  }
  else
  {
    $ccc = friends_add_friend( $initiator_userid, $friend_id );
    $msg   =  'Friend has been added sucessfully!!';
    $response =array('status'=>'ok','msg'=>$msg);
  }
  echo json_encode($response);
  die();
}

add_action('wp_ajax_bp_ajax_add_friend','bp_ajax_add_friend');

/*------ End custome code for add friend------------*/

function get_custom_user_name_auto()
{
  global $wpdb;
  if($_POST['uname'] != '')
  {
    $city = $_POST['uname'];
    $sql= "select ID,display_name from ".$wpdb->prefix."users where display_name like '$city%' OR user_login like '$city%' OR user_nicename like '$city%' LIMIT 20 ";
    $getdata= $wpdb->get_results($sql);
    $json_results=array();
    if($getdata)
    {
      foreach ($getdata as $value) 
      {
        $json_results[]=array('id'=>$value->ID, 'label'=> $value->display_name);
      }
    }
    echo json_encode( array('items'=> $json_results) );
    die;
  }
}

add_action('wp_ajax_get_custom_user_name_auto','get_custom_user_name_auto');




/* Save itineraries to post meta table when an event add or edit 

This can be seen on event single page "Schedule for date"
 */





function custom_filter_notifications_get_registered_components( $component_names = array() ) {
 
    // Force $component_names to be an array
    if ( ! is_array( $component_names ) ) {
        $component_names = array();
    }
 
    // Add 'custom' component to registered components array
    array_push( $component_names, 'custom1' );
 
    // Return component's with 'custom' appended
    return $component_names;
}
add_filter( 'bp_notifications_get_registered_components', 'custom_filter_notifications_get_registered_components' );



function custom_format_buddypress_notifications( $action, $item_id, $secondary_item_id, $total_items=1, $format = 'string' ) {


 
    // New custom notifications
    if ( 'custom1_action' === $action ) {

       $user_info = get_userdata($item_id);
       $user_info_inviter = get_userdata($secondary_item_id);

         $custom_title ="Invitation accepted";
         /*    
        $comment = get_comment( $item_id );
    
        $custom_title = $comment->comment_author . ' commented on the post ' . get_the_title( $comment->comment_post_ID );*/
        $custom_link  = home_url( '/members/' . bp_core_get_username($user_info->ID ));
        $custom_text = $user_info->display_name . ' accepted your invitation ';
        // WordPress Toolbar
        if ( 'string' === $format ) {
            $return = '<a href="' . esc_url( $custom_link ) . '" title="' . esc_attr( $custom_title ) . '">' . esc_html( $custom_text ) . '</a>';
 
        // Deprecated BuddyBar
        } else {
            $return = apply_filters( 'custom1_filter', array(
                'text' => $custom_text,
                'link' => $custom_link
            ), $custom_link, (int) $total_items, $custom_text, $custom_title );
        }
        
        return $return;
        
    }
    
}
add_filter( 'bp_notifications_get_notifications_for_user', 'custom_format_buddypress_notifications', 10, 5 );


/*add_action( 'save_post', 'myplugin_registration_save');

function myplugin_registration_save( $post ) {

  global $wpdb,$wp,$post;
  

     bp_notifications_add_notification( array(
            'user_id'           => $author_id,
            'item_id'           => $post_id,
            'secondary_item_id' => $author_id,
            'component_name'    => 'custom',
            'component_action'  => 'custom_action',
            'date_notified'     => bp_core_current_time(),
            'is_new'            => 1,
) );

}*/


/* new here */



function mail_data_handler($template_uri,$post_data=array(),$to,$subject){

     $get_tmp_data='';
       ob_start();
         require get_theme_file_path( '/email_templates/'.$template_uri.'.html');
         $get_tmp_data= ob_get_contents();
       ob_get_clean(); 
      $fields_arr=array(  
        '%INVITER_NAME%'=>'inviter_name',
        '%PROFILE_LINK%' => 'profile_link', 
        '%INVITE_LINK%'=>'invite_link',
        '%OPT_OUT_LINK%'=>'opt_out_link',
        );

    foreach ($fields_arr as $key => $value) {
         if(!empty($post_data[$value])){
            $get_tmp_data=str_replace($key, $post_data[$value] , $get_tmp_data);
         }      
    }

    return $get_tmp_data;
    // wp_mail($to,$subject,$get_tmp_data);
    
}



//add_filter( 'bbp_after_get_the_content_parse_args', 'bavotasan_bbpress_upload_media' );
/**
 * Allow upload media in bbPress
 *
 * This function is attached to the 'bbp_after_get_the_content_parse_args' filter hook.
 */
/*function bavotasan_bbpress_upload_media( $args ) {
  $args['media_buttons'] = true;

  return $args;
}*/




function my_em_styles_frontend_form_input(){
    ?>
    <fieldset>
        <legend>Status</legend>
        <?php my_em_styles_metabox(); ?>
    </div>
    <?php
}
add_action('em_front_event_form_footer', 'my_em_styles_frontend_form_input',99);


function my_em_styles_meta_boxes(){
    add_meta_box('em-event-styles', 'Status', 'my_em_styles_metabox',EM_POST_TYPE_EVENT, 'normal','high');
    add_meta_box('em-event-styles', 'Status', 'my_em_styles_metabox','event-recurring', 'normal','high');
}
add_action('add_meta_boxes', 'my_em_styles_meta_boxes');
 
function my_em_styles_metabox(){
    global $EM_Event;
/*
    pr($EM_Event);*/
    
    $event_control=  get_post_meta($EM_Event->post_id,'event_control',true);

        ?>

        <select name="event_control" id="event_control">
        <option value="">Select Status</option>
        <option value="public" <?php if($event_control=='public'){?> selected='selected' <?php }?> > Public</option>
       <!--  <option value="private" <?php if($event_control=='private'){?> selected='selected' <?php }?> > Private</option> -->
        <option value="loggedin" <?php if($event_control=='loggedin'){?> selected='selected' <?php }?> > Loggedin</option>
        <!-- <option value="friendsonly" <?php if($event_control=='friendsonly'){?> selected='selected' <?php }?> > Friendsonly</option> -->
        </select>         
        <?php

}


/*
add_filter('em_event_save','my_em_styles_event_save',1,2);
function my_em_styles_event_save($result,$EM_Event){
    global $wpdb;


    if(isset($_POST['event_control'])){

       update_post_meta($EM_Event->post_id,'event_control',$_POST['event_control']);
    }
   
    return $result;
}
*/

add_filter('em_event_save','my_em_styles_event_save',1,2);
function my_em_styles_event_save($result,$EM_Event){
    global $wpdb;
    //First delete any old saves
  if(isset($_POST['event_control'])){
       $if_have= $wpdb->query("select * FROM ".EM_META_TABLE." WHERE object_id='{$EM_Event->event_id}' AND meta_key='event_control'");
       if($if_have){
          $eventControl=  $_POST['event_control'];
           $wpdb->query("UPDATE ".EM_META_TABLE." set meta_value='$eventControl' where object_id='{$EM_Event->event_id}' AND meta_key='event_control' ");
       }else{
            $eventControl=  $_POST['event_control'];
           $wpdb->query("INSERT INTO ".EM_META_TABLE." (object_id, meta_key, meta_value) VALUES('$EM_Event->event_id','event_control','$eventControl' ) ");
       }

        update_post_meta($EM_Event->post_id,'event_control',$_POST['event_control']);
     }


    return $result;
}

/* Filter the query when site wide event show*/
add_filter( 'em_events_build_sql_conditions', 'my_em_styles_events_build_sql_conditions',1,2);
function my_em_styles_events_build_sql_conditions($conditions, $args){

    global $wpdb;
      if(isset($_REQUEST['em_ajax'])){
        $control="'public'";
        $is_user_logged_in='';
        if(is_user_logged_in()){
           $control="'public','loggedin'";
        }
       $sql = $wpdb->prepare("SELECT object_id FROM ".EM_META_TABLE." WHERE meta_value IN ($control) AND meta_key='event_control'");
        $conditions['style'] = "event_id IN ($sql)";
      }
    
    return $conditions;
}

function get_actual_event_id($post_id){
  global $wpdb;
    $sql=$wpdb->get_row("select * from wp_em_events where post_id='$post_id' ");
  return $sql;
}


/*add_action('wp_ajax_save_pushtoken','save_pushtoken');
add_action('wp_ajax_nopriv_save_pushtoken','save_pushtoken');
function save_pushtoken(){
 $token= $_POST['token'];
 global $wpdb;

  die;
}

*/

//add_action('wp_ajax_send_pushtoken','send_pushtoken');
//add_action('wp_ajax_nopriv_send_pushtoken','send_pushtoken');

//add_action('save_post','send_pushtoken');

/*function send_pushtoken($post_id){
 $token='fK-haKNX7_k:APA91bGClO8LnAb4nBR6DiR75ckfU4ZpYaSqyYU8DAP3NJCMdJ5raID207O1ATp29wP7qpFhozoFkxQL-__9m1SVISqNIpyh3aTLCU6negvsJkbSmZVbxsMEkRR9SksvUpsJzVArqulg';
 $message='This is test notification..';
 $order_id='876604016817';



    define( 'API_ACCESS_KEY', 'AIzaSyBq95sPe8O92ID2QyJdLr8DKNjLkXrPsAw' );
 
    $registrationIds =$order_id;

     $msg = array
          (
    'body'  => 'Body  Of Notification',
    'title' => 'Title Of Notification',
              'icon'  => 'myicon',
                'sound' => 'mySound'
          );
  $fields = array
      (
        'to'    => $registrationIds,
        'notification'  => $msg
      );
  
  
  $headers = array
      (
        'Authorization: key=' . API_ACCESS_KEY,
        'Content-Type: application/json'
      );
  
    $ch = curl_init();
    curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
    curl_setopt( $ch,CURLOPT_POST, true );
    curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
    curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
    curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
    curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
    $result = curl_exec($ch );
    curl_close( $ch );

echo $result;





}*/



define("STRING_DELIMITER", " ");
function word_limiter($str, $limit = 10) {
    $str = strip_tags($str); // Updated from Ivan Dimov
    if (stripos($str, STRING_DELIMITER)) {
        $ex_str = explode(STRING_DELIMITER, $str);
        if (count($ex_str) > $limit) {
            for ($i = 0; $i < $limit; $i++) {
                $str_s.=$ex_str[$i] . " ";
            }
            return $str_s."...";
        } else {
            return $str;
        }
    } else {
        return $str;
    }
}

function wpse23007_redirect(){
    if(is_user_logged_in()){
          $allowd_ids=array(3,4,454);
          $user_id= get_current_user_id();
      /*if(!in_array($user_id, $allowd_ids)){
           add_filter('show_admin_bar', '__return_false');
      }*/
      if( is_admin() && !defined('DOING_AJAX')) {

        if(!in_array($user_id, $allowd_ids)){
          wp_redirect(home_url());
          exit;
        }

      }
    }
}
add_action('init','wpse23007_redirect');


add_filter('astra_schema_body','astra_schema_body_extend');
function astra_schema_body_extend($tagUrl){
  return $tagUrl= str_replace('http:', 'https:', $tagUrl);
}

function _remove_script_version( $src ){
$parts = explode( '?ver', $src );
return $parts[0];
}
add_filter( 'script_loader_src', '_remove_script_version', 15, 1 );
add_filter( 'style_loader_src', '_remove_script_version', 15, 1 );


/*if (!(is_admin() )) {
    function defer_parsing_of_js ( $url ) {
        if ( FALSE === strpos( $url, '.js' ) ) return $url;
        if ( strpos( $url, 'jquery.js' ) ) return $url;
        // return "$url' defer ";
        return "$url' defer onload='";
    }
    add_filter( 'clean_url', 'defer_parsing_of_js', 11, 1 );
}*/


add_filter('wp_nav_menu_objects', 'ad_filter_menu', 10, 2);

function ad_filter_menu($sorted_menu_objects, $args) {

    // check for the right menu to remove the menu item from
    // here we check for theme location of 'secondary-menu'
    // alternatively you can check for menu name ($args->menu == 'menu_name')
   /* if ($args->theme_location != 'primary')  
        return $sorted_menu_objects;*/

    // remove the menu item that has a title of 'Uncategorized'
    foreach ($sorted_menu_objects as $key => $menu_object) {

        // can also check for $menu_object->url for example
        // see all properties to test against:
        // print_r($menu_object); die();
         if($menu_object->ID=="20481"){
           unset($sorted_menu_objects[$key]);
           break;
         }


     // echo $menu_object;
   /*     if ($menu_object->title == 'Uncategorized') {
            unset($sorted_menu_objects[$key]);
            break;
        }*/
    }

    return $sorted_menu_objects;
}


function bbp_increase_forum_per_page( $args = array() ) {
$args['posts_per_page'] = get_option( '_bbp_forums_per_page', 500 );
return $args;
}
//add_filter( 'bbp_before_has_forums_parse_args', 'bbp_increase_forum_per_page');



/*Trigger Notification when Group[Chapter] updated..*/
add_action('groups_details_updated','groups_details_updated_extend');
function groups_details_updated_extend( $group_id, $old_group, $notify_members){

  $notify_members=true;
  groups_notification_group_updated( $group_id, $old_group );
}

register_sidebar(
  apply_filters(
    'astra_footer_1_widgets_init', array(
      'name'          => esc_html__( 'Footer bootom 1', 'astra' ),
      'id'            => 'footer-bottom-1',
      'description'   => '',
      'before_widget' => '<aside id="%1$s" class="widget %2$s">',
      'after_widget'  => '</aside>',
      'before_title'  => '<h2 class="widget-title">',
      'after_title'   => '</h2>',
    )
  )
);

register_sidebar(
  apply_filters(
    'astra_footer_1_widgets_init', array(
      'name'          => esc_html__( 'Footer bootom 2', 'astra' ),
      'id'            => 'footer-bottom-2',
      'description'   => '',
      'before_widget' => '<aside id="%1$s" class="widget %2$s">',
      'after_widget'  => '</aside>',
      'before_title'  => '<h2 class="widget-title">',
      'after_title'   => '</h2>',
    )
  )
);

register_sidebar(
  apply_filters(
    'astra_footer_1_widgets_init', array(
      'name'          => esc_html__( 'Footer bootom 3', 'astra' ),
      'id'            => 'footer-bottom-3',
      'description'   => '',
      'before_widget' => '<aside id="%1$s" class="widget %2$s">',
      'after_widget'  => '</aside>',
      'before_title'  => '<h2 class="widget-title">',
      'after_title'   => '</h2>',
    )
  )
);

function clubpack_remote_user($data){
   $data['createUser'] = 1;
   $ch = curl_init();
   $endpoint =  'https://clubpack.org/';
  
  curl_setopt($ch, CURLOPT_URL, $endpoint);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
  $response = curl_exec ($ch);
  curl_close ($ch);

  return $response;
}

// remove toolbar items
// https://digwp.com/2016/06/remove-toolbar-items/
function shapeSpace_remove_toolbar_node($wp_admin_bar) {

  if(is_user_logged_in()){

     $allowd_ids=array(3,4,454);

     $user_id= get_current_user_id();

     if(!in_array($user_id, $allowd_ids)){
  
      // replace 'updraft_admin_node' with your node id
      $wp_admin_bar->remove_node('customize');
      $wp_admin_bar->remove_node('updates');
      $wp_admin_bar->remove_node('comments');
      $wp_admin_bar->remove_node('new-content');
      $wp_admin_bar->remove_node('edit');
      $wp_admin_bar->remove_node('site-name');
      $wp_admin_bar->remove_node('bp-notifications');
      $wp_admin_bar->remove_node('my-account');
      $wp_admin_bar->remove_node('search');
      $wp_admin_bar->remove_node('wp-logo');

    }

 }
  
}
add_action('admin_bar_menu', 'shapeSpace_remove_toolbar_node', 999);

//when admin delete any user then automatic delete from clubpack site /
function my_delete_user( $user_id ) {
  global $wpdb;

  $user_obj            = get_userdata( $user_id );
  $deleteEmail         = $user_obj->user_email;
  $_POST['deleteuser'] = $deleteEmail;
  $rr = clubpack_remote_user_delete($_POST);

}
add_action( 'delete_user', 'my_delete_user' );

function clubpack_remote_user_delete($data){

   $data['deleteUser'] = 1;
   $ch = curl_init();
   $endpoint =  'https://clubpack.org/';
  
  curl_setopt($ch, CURLOPT_URL, $endpoint);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
  $response = curl_exec ($ch);
  curl_close ($ch);
  return $response;
}
?>