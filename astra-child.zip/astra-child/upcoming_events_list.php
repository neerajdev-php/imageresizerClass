<?php 
// the query
global $wp_query;

$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;

$args=array(
	'post_type'=>'event',
	'posts_per_page'=>10,
	'post_status'=>'publish',
	/*'paged' => $paged,
	'page' => $paged*/

	);

$the_query = new WP_Query( $args );
/*echo $the_query->request;*/

/*pr($the_query);*/
 $event_url =  bp_get_group_permalink($group).'events/';

 ?>

<?php if ( $the_query->have_posts() ) : ?>

	<!-- pagination here -->
   <div class="event_list_container">
    <div class="upcoming_event_list">
     <div class="event_head"><h3>Upcoming Events <span class="feed_all_upevent"><a href="<?php echo $event_url;?>">Browse All</a></span></h3>

    		</div>
		   	<!-- the loop -->
			<?php
			$html_upcoming='';
			global $post;
			if($the_query->have_posts()){
			   while ( $the_query->have_posts() ) : $the_query->the_post();
			     
			     ?>
						<?php 
							$post_id='';
							$post='';
							$start_date='';
							$end_date='';
							$post= $the_query->post;
		                    setup_postdata($post); 
		                   $post_id= $post->ID;	              
									
							$start_date= get_post_meta($post_id,'_event_start_date',true);
							$end_date= get_post_meta($post_id,'_event_end_date',true);
						 	if( strtotime($start_date) >= strtotime(date('Y-m-d'))){
						 	 $nonImageContent='';				 		
		                            $html_upcoming.='<div class="repeat-events">'; 
		                            if(has_post_thumbnail()){
		                               $html_upcoming.='<div class="event_list_thumb">';
		                                 	$feat_image_url = wp_get_attachment_url( get_post_thumbnail_id() );
		                                $html_upcoming.='<a href="'.get_the_permalink().'"><img src="'.$feat_image_url.'" class="img_responsive"></a>';
		                               $html_upcoming.='</div>';
		                             }else{
		                             	$html_upcoming.='<div class="event_list_thumb">';
		                                 	$feat_image_url = get_bloginfo( 'stylesheet_directory' ) . '/images/default-thumbnail.jpg';
		                                $html_upcoming.='<a href="'.get_the_permalink().'"><img src="'.$feat_image_url.'" class="img_responsive"></a>';
		                               $html_upcoming.='</div>';
		                             }    
		                             $html_upcoming.='<div class="event_list_header '.$nonImageContent.'">';
								 	 $html_upcoming.='<div class="event_title_head"> <a href="'.get_the_permalink().'">'. get_the_title()."</a></div>";
								 	 $html_upcoming.='<div class="event_meta_container"> '; 
                                      $html_upcoming.='<div class="event_meta_head"> Start Date: '.date('F d, Y',strtotime($start_date))."</div>";
                                      $html_upcoming.='<div class="event_meta_head"> End Date: '.date('F d, Y',strtotime($end_date))."</div>"; 
                                     $html_upcoming.='</div>'; 
                                     $html_upcoming.='</div>'; 

								 	$html_upcoming.='</div>'; 
						 	}
                        
					?>
			 <?php endwhile; ?>
			 <?php if(!$html_upcoming){ ?>
			 	   <div class="repeat-events"><p><?php esc_html_e( 'Sorry, no upcoming events found!' ); ?></p></div>
			  <?php }else{ 
			  	        echo $html_upcoming; 
			        }   	
			    } 

			 ?>	
	
    </div>		  

     <?php
      if (function_exists('custom_pagination')) {
      //	pr($the_query);
       // custom_pagination($the_query->max_num_pages,"",$paged);
      }
    ?>

	<!-- end of the loop -->

	<!-- pagination here -->

	<?php wp_reset_postdata(); ?>

<?php else : ?>
	<p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>
 </div>
