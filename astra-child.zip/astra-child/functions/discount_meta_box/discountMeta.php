<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
add_action( 'add_meta_boxes', 'discount_code_custom_box' );
add_action( 'add_meta_boxes', 'discount_expire_date_custom_box' );
add_action( 'add_meta_boxes', 'discount_url_custom_box' );

function discount_code_custom_box() {
    add_meta_box(
        'dynamic_sectionid',
        __( 'Discount Code', 'myplugin_textdomain' ),
        'discount_inner_code_box',
        'discount');
}


function discount_expire_date_custom_box() {
    add_meta_box(
        'dynamic_sectionid2',
        __( 'Discount expire date', 'myplugin_textdomain' ),
        'discount_inner_expire_date_box',
        'discount');
}


function discount_url_custom_box() {
    add_meta_box(
        'dynamic_sectionid3',
        __( 'Discount Website Url', 'myplugin_textdomain' ),
        'discount_inner_web_url_box',
        'discount');
}

function discount_inner_code_box(){

    global $post;
    $code  =  get_post_meta($post->ID,'discount_code',true);
    echo '<p><input type="text" name="discount_code" class="regular-text code" value="'.$code.'"></p>';
}

function discount_inner_expire_date_box(){

     global $post;
     $expire_date  =  get_post_meta($post->ID,'discount_expire_date',true);
     echo '<p><input type="text" name="discount_expire_dare" class="regular-text code" value="'.$expire_date.'"></p>';
}

function discount_inner_web_url_box(){

     global $post;
     $web_url  =  get_post_meta($post->ID,'discount_web_url',true);
     echo '<p><input type="text" name="discount_web_url" class="regular-text code" value="'.$web_url.'"></p>';
}
?>