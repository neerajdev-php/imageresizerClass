<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;


function create_html_add_edit_news(){

   $html='';
   ob_start();
      require get_theme_file_path( '/template-parts/inviteHTML/add_edit_news.php' );
     $html.=ob_get_contents();
    ob_get_clean();
    return $html; 

}
add_shortcode('NEW_NEWS_CODE','create_html_add_edit_news');

/* save discount code here */
add_action('wp_ajax_custom_news_add_edit','custom_news_add_edit');
function custom_news_add_edit(){
	$nonce = $_REQUEST['_news_nonce'];
  	if(wp_verify_nonce($nonce, 'log-news-nonce')) {

  		$title      =  sanitize_text_field($_POST['news_title']);
	    $cat        =  intval($_POST['news_cate']);
	    $desc       =  $_POST['news_description'];
	    $image      =  $_FILES['news_logo']['name'];
	    

	    $editId    = intval($_POST['edit_code']);
	    $edittype  = sanitize_text_field($_POST['edit_type']);

	    $error='';

	    $user = wp_get_current_user();
	    $uId  =  $user->ID;
	    $role = ( array ) $user->roles;

	    if (in_array('administrator', $role) || in_array('bbp_keymaster', $role))
	    {

	    	  if( empty( $title )) {
		        $error = 'Please enter news name.';
		      }
		      else if( empty($cat)) {
		        $error = 'Please fill news category.';
		      } else if( empty($desc)) {
		        $error = 'Please insert news description';
		      }
		      if($error){
		      echo json_encode(array('status'=>'fail','message'=>$error));
		      }else{


		      	require_once(ABSPATH . "wp-admin" . '/includes/image.php');
          		require_once(ABSPATH . "wp-admin" . '/includes/file.php');
          		require_once(ABSPATH . "wp-admin" . '/includes/media.php');


          		if($edittype != 'edit'){

		               // Create post object
		               $my_post  = array(
		                                 'post_title'   => $title,
		                                 'post_content' => $desc,
		                                 'post_status'  => 'publish',
		                                 'post_type'    => 'post',
		                                 'post_author'  => $uId,
		                          );
		             
		              // Insert the post into the database
		              $post_ID = wp_insert_post( $my_post );

		              wp_set_post_terms( $post_ID, $cat, 'category');

						/* create feature image here */
		              
		              $uploaddir = wp_upload_dir();
		              $file = $_FILES['news_logo' ];
		              $uploadfile = $uploaddir['path'] . '/' . basename( $file['name'] );
		              $uploadfileUrl = $uploaddir['url'] . '/' . basename( $file['name'] );
		              move_uploaded_file( $file['tmp_name'] , $uploadfile );
		              $filename = basename( $uploadfile );
		              $wp_filetype = wp_check_filetype(basename($filename), null );
		              $attachment = array(
		              	'guid'           => $uploadfileUrl,
		                'post_mime_type' => $wp_filetype['type'],
		                'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
		                'post_content' => '',
		                'post_status' => 'inherit',
		                'menu_order' => $_i + 1000
		                );

		              $attach_id = wp_insert_attachment( $attachment, $uploadfile );

		              update_post_meta($post_ID,'_thumbnail_id',$attach_id);

		              update_post_meta($post_ID, 'onesignal_meta_box_present', true);
	                  update_post_meta($post_ID, 'onesignal_send_notification', true);

		              set_post_thumbnail($post_ID, $attach_id );

		              echo json_encode(array('status'=>'ok','message'=>'Added sucessfully!!'));

		          }else{


		          	 // Create post object
		               $my_post  = array(

		               					 'ID'           => $editId,
		                                 'post_title'   => $title,
		                                 'post_content' => $desc,
		                                 'post_status'  => 'publish',
		                                 'post_type'    => 'post',
		                                 'post_author'  => $uId,
		                          );
		             
		              // Insert the post into the database
		              $post_ID = wp_update_post( $my_post );

		              wp_set_post_terms( $post_ID, $cat, 'category');


		              if($image !=''){

		                 $attachment_id = get_post_thumbnail_id( $editId );
		                 wp_delete_attachment($attachment_id, true);


		                 $uploaddir = wp_upload_dir();
		                $file = $_FILES['news_logo' ];
		                $uploadfile = $uploaddir['path'] . '/' . basename( $file['name'] );
		                $uploadfileUrl = $uploaddir['url'] . '/' . basename( $file['name'] );
		                move_uploaded_file( $file['tmp_name'] , $uploadfile );
		                $filename = basename( $uploadfile );
		                $wp_filetype = wp_check_filetype(basename($filename), null );
		                $attachment = array(
		                  'guid'           => $uploadfileUrl,
		                  'post_mime_type' => $wp_filetype['type'],
		                  'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
		                  'post_content' => '',
		                  'post_status' => 'inherit',
		                  'menu_order' => $_i + 1000
		                  );

		                $attach_id = wp_insert_attachment( $attachment, $uploadfile );

		                update_post_meta($post_ID,'_thumbnail_id',$attach_id);

		                update_post_meta($post_ID, 'onesignal_meta_box_present', true);
	                    update_post_meta($post_ID, 'onesignal_send_notification', true);

		                set_post_thumbnail($post_ID, $attach_id );



              		}

              			echo json_encode(array('status'=>'ok','message'=>'Updated sucessfully!!'));


		          }

				}
	}
}
die();
}

/* display edit news data in popup */
add_action('wp_ajax_update_fronten_news_data','update_fronten_news_data');
function update_fronten_news_data(){

  global $wpdb;

   $id    = intval($_POST['id']);
   $data  = get_post($id); 

   $image       =  wp_get_attachment_image_src( get_post_thumbnail_id( $id ));
   $title       =  $data->post_title;
   $content     =  $data->post_content;

   $cat = wp_get_post_terms( $id, 'category', 'ARRAY_A');
  $combinedata =   array(

                              'news_title'  => $title,
                              'news_cat'    => $cat[0]->term_id,
                              'news_desc'   => $content,
                              'news_image'  => $image[0],
                              
                        );
   echo json_encode($combinedata);
die(0);  
}

/* delete news data */
add_action('wp_ajax_delete_news_data','delete_news_data');
function delete_news_data(){

  global $wpdb;

   $id    = intval($_POST['id']);
   $data  = get_post($id); 

   wp_delete_post( $id);
                        
   echo json_encode(array('status'=>'ok','message'=>'delete'));
die(0);  
}

add_action('wp_ajax_custom_share_post_activity','custom_share_post_activity');
add_action('wp_ajax_nopriv_custom_share_post_activity','custom_share_post_activity');
function custom_share_post_activity(){

	global $bp;

	$id        =  intval($_POST['pId']);
	$uid        =  intval($_POST['userid1']);
    $postData =   get_post($id); 

	$userId  =  get_current_user_id();
	$userdata= get_userdata( $userId );
	$displayName= $userdata->display_name;

	$ptitle    = $postData->post_title;
	$plink     = get_the_permalink($postData->ID);

	$brifContent= word_limiter($postData->post_content,50);
	  $profileURl=  home_url( '/members/' . bp_core_get_username( $userId) );
    $content = '<a href="'.$profileURl.'"> '.$displayName.'</a> shared a post <a href="'.$plink.'">'.$ptitle.'</a>  ';

	$args = array(

				'action'       		=> $content,
				'content'      		=> $brifContent,
				'component'    		=> 'member',
				'type'         		=> 'share_post',
			/*	'primary_link' 		=> '',*/
				'user_id'      		=> $uid ,
				'item_id'           => $id,
				'secondary_item_id' => $userId,
				'recorded_time'     => bp_core_current_time(),
				'hide_sitewide'     => false,
				'is_spam'           => false, 
				'error_type'        => 'bool',
	);

	$activity_id = bp_activity_add( $args );

	echo json_encode(array('status'=>'ok','message'=>'Shared sucessfully!!' ,'returnId' => $activity_id));

die();
}
?>