<?php

if ( ! defined( 'ABSPATH' ) ) {

	exit; // Exit if accessed directly
}
/**

 * Registers a products post type.

 *

 * @link http://codex.wordpress.org/Function_Reference/register_post_type

 */

function discount_register_post_type()
{

	register_post_type(

		'discount',

		array(

			'labels' => array(

				'name'               => __('Discount Code', 'text_domain'),

				'singular_name'      => __('Discount Code', 'text_domain'),

				'menu_name'          => __('Discount Code', 'text_domain'),

				'name_admin_bar'     => __('Discount Code Item', 'text_domain'),

				'all_items'          => __('All Discount Code', 'text_domain'),

				'add_new'            => _x('Add Discount Code', 'discount', 'text_domain'),

				'add_new_item'       => __('Add New Discount Code', 'text_domain'),

				'edit_item'          => __('Edit Discount Code', 'text_domain'),

				'new_item'           => __('New Discount Code', 'text_domain'),

				'view_item'          => __('View Discount Code', 'text_domain'),

				'search_items'       => __('Search Discount Code Code', 'text_domain'),

				'not_found'          => __('No Discount Code found.', 'text_domain'),

				'not_found_in_trash' => __('No Discount Code found in Trash.', 'text_domain'),

				'parent_item_colon'  => __('Parent Discount Code:', 'text_domain'),

			),

			'public'        => true,

			'menu_position' => 5,

			//'menu_icon'     => '',

			'supports'      => array(

				'title',

				'editor',

				'thumbnail',

				'',

				'',

			),

			//'capability_type'    => 'add_Products',

			'taxonomies'    => array(

				'',

			),

			'has_archive'   => true,

			'rewrite'       => array(

				'slug' => 'discount',

			),

		)

	);
}
add_action('init', 'discount_register_post_type');
?>