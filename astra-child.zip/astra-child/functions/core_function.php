<?php 

/*Add Setting page for Deals post type*/
if ( ! function_exists('add_setting_deal_post_type') ) :

add_action( 'admin_menu' , 'add_setting_deal_post_type' );

/**
 * Generate sub menu page for settings
 *
 * @uses rushhour_projects_options_display()
 */
function add_setting_deal_post_type()
{
    add_submenu_page(
        'edit.php?post_type=deals',
        __('Timer Settings', 'ASTRA'),
        __('Timer Settings', 'ASTRA'),
        'manage_options',
        'timer_settings',
        'add_setting_deal_post_type_display');
}
endif;


function add_setting_deal_post_type_display(){
   // Create a header in the default WordPress 'wrap' container

if(isset($_POST['save_timer_setting'])){


  $get_timer= $_POST['deals_timer'];
  update_option( 'deals_timer',  $get_timer );

     echo "<div class='notice notice-success is-dismissible'>
        <p>Setting Updated!!</p>
    </div>";

}

$get_timer_obj= get_option('deals_timer');
$timer_val= !empty($get_timer_obj['timer_expire_date']) ? $get_timer_obj['timer_expire_date'] : '';

/*  echo '<pre>';
    print_r($get_timer_obj);
  echo '</pre>';*/



$str = <<<EOF
        <div class="wrap">
        <h1>Timer Setting</h1>
         <form method="post" action="">
           <p><label for="timer_expire_date"><strong>Expired Date:  </strong></label><input type="text" name="deals_timer[timer_expire_date]" id="datepicker" value="$timer_val"></p>

           <p><input type="submit" name="save_timer_setting" class="button button-primary button-large" id="save_timer_setting" value="Save Changes"></p>
         </form>
         </div>
         <link rel='stylesheet' type='text/css' media='all'  href="//code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css">
         <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
         <script>
         jQuery(function($) {
           $('#datepicker').datepicker({
             dateFormat: 'yy-mm-dd',
             onSelect: function(datetext){
                  var d = new Date(); // for now
                  var h = d.getHours();
                  h = (h < 10) ? ("0" + h) : h ;

                  var m = d.getMinutes();
                  m = (m < 10) ? ("0" + m) : m ;

                  var s = d.getSeconds();
                  s = (s < 10) ? ("0" + s) : s ;
                  datetext = datetext + " " + h + ":" + m + ":" + s;
            $('#datepicker').val(datetext);
        },
    });
});
         </script>
EOF;


echo $str;
}




/*Add Setting page for Deals post type*/

/* Custom functions */ 

function custom_gal_action_links($links){
	
	preg_match_all("|<[^>]+>(.*)</[^>]+>|U",$links,$out, PREG_PATTERN_ORDER);
	$newLinks = '';
	foreach ($out[1] as $key => $value) {
		if($value == 'upload'){
			$str = $out[0][$key];
			$newLinks.= str_replace('>upload</a>', 'class="mpp_upload_gallery">upload</a>', $str);
		}else{
			$newLinks.= $out[0][$key];
		}
	}
	echo $newLinks;
}
	
add_filter( 'mpp_gallery_actions_links','custom_gal_action_links');


/* sponsers listing here */

function display_spon_list(){

 global $wpdb;

 $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

  $args   =  array(

            'page'         =>  $paged,
            'paged'         =>  $paged,
            'posts_per_page' =>  '6',
  					'post_type'     =>  'sponsor',
  					'post_status'   =>  'publish',
  					'order'		      =>  'desc',
  				);

  $the_query = new WP_Query( $args );

  $html .=  '<div class="discount-table">


   <ul class="discount-table-ul">


    <li>
         <div class="discount-table-store">
            <strong>About</strong>
         </div>
         <div class="discount-table-deal">
            <strong></strong>
         </div>
         <div class="discount-table-code">
            <strong>Website</strong>
         </div>
      </li>';


   if ( $the_query->have_posts() ) :

      while ( $the_query->have_posts() ) : $the_query->the_post();

        $id     = get_the_id();
        $link   = get_post_meta($id,'wp_sponsors_url',true);
        $input  = get_post_meta($id,'wp_sponsors_url',true); 
        $image  = wp_get_attachment_url( get_post_thumbnail_id() );


      // in case scheme relative URI is passed, e.g., //www.google.com/
      $input = trim($input, '/');

      // If scheme not included, prepend it
      if (!preg_match('#^http(s)?://#', $input)) {
          $input = 'http://' . $input;
      }

      $urlParts = parse_url($input);

      // remove www
      $domain = preg_replace('/^www\./', '', $urlParts['host']);

      //echo get_post_meta($id,'wp_sponsors_desc',true).'<br>';

        $cont = '';
        ob_start();
         the_content();
         $cont  = ob_get_contents();
        ob_get_clean();


      //'<span>'.get_post_meta($id,'wp_sponsors_desc',true).'</span>';

     $html .= '<li class="class="partnert_hide_'.$id.'"">
                     <div class="discount-table-store">
                        <div class="discount-table-store-img">
                           <div class="inner_store_im">
                              <img src="'.$image.'" alt="">
                           </div>
                        </div>
                     </div>
                     <div class="discount-table-deal">
                        <div class="discount-table-box">
                          <h4>'.get_the_title($id).'</h4>
                           

                            <span>'.$cont.'</span>
                           
                        </div>
                     </div>
                     <div class="discount-table-code">
                        <div class="discount-table-box">';

                          $user = wp_get_current_user();
                          $role = ( array ) $user->roles;
                          if (in_array('administrator', $role))
                          {

                               $html .= '<div class="after_click_edit after_click_edit_partner" style="display: none;">
                                  <span class="discount_edit partner_edit">
                                  <a href="javascript:void(0);" data-id="'.$id.'" data-type="edit"></a>
                                  </span>
                                  <span class="discount_delete partner_delete">
                                  <a href="javascript:void(0);" data-id="'.$id.'"></a>
                                  </span>
                               </div>';

                             }   

                            $html .= '
                           <a href="'.$link.'" target="_blank"><h3>'.$domain.'</h3></a>
                           <a href="javascript:void(0);" class="btn discount-table-btn"></a> 
                        </div>
                     </div>
            </li>';

        endwhile;

      wp_reset_query();

     

     

      else :

    $html .= '<li class="no_spon">Sorry, no sponsors found here </li>';

   endif; 

    $html .= '</ul>';


     if (function_exists('custom_pagination')) {
      //  pr($the_query);
        $html .= custom_pagination2($the_query->max_num_pages,"",$paged);
      }


     $html .= '</div>';

   


   return $html;

}
add_shortcode('SPONSORS','display_spon_list');


/* footer spnsore slider start here */
function footer_sponsors_slider(){

  global $wpdb;

  $args_slider   =  array(

            'post_type'    =>  'sponsor',
            'post_status'  =>  'publish',
            'order'        =>  'desc',
            'posts_per_page'  => -1,
          );

  $the_query_slider = new WP_Query( $args_slider );

   if ( $the_query_slider->have_posts() ) :

      $slider .= '<div class="owl-carousel owl-theme" id="owl-demo">';

         while ( $the_query_slider->have_posts() ) : $the_query_slider->the_post();

           $id     = get_the_id();
           $link   = get_post_meta($id,'wp_sponsors_url',true);
           $image1  = wp_get_attachment_image_src( get_post_thumbnail_id( $id ),'single-post-thumbnail');


           //echo '<pre>'; print_r($image1);

        $slider .= '<div class="item">
                      <a href="'.$link.'" target="_blank"><img  src="'.$image1[0].'" class="" alt="'.get_the_title($id).'" title="'.get_the_title($id).'"></a>
                        </div>';


         endwhile;

        wp_reset_query();

      else :

    $slider .= '<p class="no_spon">Sorry, no sponsors found here </p>';

   endif; 

  $slider .= '</div>';

  return $slider;

}
add_shortcode('SLIDER-SPONSORS','footer_sponsors_slider');


/* footer spnsore slider end  here */

/* notification user image */

function bp_get_the_notification_image(){

  global $bp;

  $bp           = buddypress();
  $notification = $bp->notifications->query_loop->notification;
  $userId       =  $notification->item_id;
  $args         = get_avatar_data( $userId , 50);
  $auImage      = '<img src="'.$args[url].'" class="noti_aut_image">';
  return $auImage;
}

/* notifaction mark read and unread */
add_action('wp_ajax_custom_mark_read_unread_notification','custom_mark_read_unread_notification');
function custom_mark_read_unread_notification(){

 global $wpdb;

  $type       =  $_POST['type'];
  $userId     =  intval($_POST['userId']);
  $noti_id    =  $_POST['noti_id'];
  
  
  $noti_table  =  $wpdb->prefix.'bp_notifications';
  $sucess = array();


  if($type == 'unread'){

     $sql  =  "UPDATE $noti_table SET is_new ='0' WHERE user_id = $userId ANd id IN($noti_id)";
     $res  =  $wpdb->query($sql);

     $sucess  =  array('msg' => 'sucess','message' => 'All Notification has been unread sucessfully');

   }else{

     $sql  =  "UPDATE $noti_table SET is_new ='1' WHERE user_id = $userId ANd id IN($noti_id)";
     $res  =  $wpdb->query($sql);

     $sucess  =  array('msg' => 'sucess','message' => 'All Notification has been read sucessfully');

  }

  echo json_encode($sucess);

die(0);
}

add_action('wp_ajax_custom_delete_read_unread_notification','custom_delete_read_unread_notification');
function custom_delete_read_unread_notification(){

 global $wpdb;

  
  $userId     =  intval($_POST['userId']);
  $noti_id    =  $_POST['noti_id'];


  $noti_table  =  $wpdb->prefix.'bp_notifications';
  $sucess = array();

 $sql     =  "DELETE from $noti_table  WHERE user_id = $userId ANd id IN($noti_id)";
 $res     =  $wpdb->query($sql);
 $sucess  =  array('msg' => 'sucess','message' => 'All Notification has been delete sucessfully');

  echo json_encode($sucess);

die(0);
}

/* count unread message of current user */
function get_current_user_unread_notification_count(){

  global $wpdb;
  $user        = get_current_user_id();
  $noti_table  =  $wpdb->prefix.'bp_notifications';
  
  global $wpdb;
  $wpdb->get_results("SELECT id FROM " . $wpdb->prefix . "bp_notifications  WHERE  `user_id` = $user AND `is_new` = '1' "); 
  return $wpdb->num_rows;
}

/* count read message of current user */
function get_current_user_read_notification_count(){

  global $wpdb;
  $user        = get_current_user_id();
  $noti_table  =  $wpdb->prefix.'bp_notifications';
  
  global $wpdb;
  $wpdb->get_results("SELECT id FROM " . $wpdb->prefix . "bp_notifications  WHERE  `user_id` = $user AND `is_new` = '0' "); 
  return $wpdb->num_rows;
}

/* registered discount code post type here */
include('registerd_discount_code_post_type/discount.php');
include('discount_meta_box/discountMeta.php');

/* add discount code shortcode register here */
function create_html_add_discount_code(){

   $html='';
   ob_start();
      require get_theme_file_path( '/template-parts/inviteHTML/add_discount_code.php' );
     $html.=ob_get_contents();
    ob_get_clean();
    return $html; 

}
add_shortcode('NEW_DISCOUNT_CODE','create_html_add_discount_code');



/* add discount code shortcode register here */
function create_html_add_discount_deals(){

   $html='';
   ob_start();
      require get_theme_file_path( '/template-parts/add_discount_deal.php' );
     $html.=ob_get_contents();
    ob_get_clean();
    return $html; 

}
add_shortcode('NEW_DISCOUNT_DEALS','create_html_add_discount_deals');



function create_html_add_friend_code(){

   $html='';
   ob_start();
      require get_theme_file_path( '/template-parts/inviteHTML/add_friends_code.php' );
     $html.=ob_get_contents();
    ob_get_clean();
    return $html; 

}
add_shortcode('NEW_FRIEND_CODE','create_html_add_friend_code');



function create_html_share_post_code(){

   $html='';
   ob_start();
      require get_theme_file_path( '/template-parts/inviteHTML/share_friends_post.php' );
     $html.=ob_get_contents();
    ob_get_clean();
    return $html; 

}
add_shortcode('NEW_SHARE_CODE','create_html_share_post_code');

/* save discount code here */
add_action('wp_ajax_custom_discount_add_edit','custom_discount_add_edit');
function custom_discount_add_edit(){


  $nonce = $_REQUEST['_discount_nonce'];
  if(wp_verify_nonce($nonce, 'log-discount-nonce')) {


    $code      =  sanitize_text_field($_POST['dis_code']);
    $date      =  $_POST['dis_expire_date'];
    $deal      =  sanitize_text_field($_POST['des_deal']);
    $logo      =  $_FILES['dis_logo']['name'];
    $dis_url   =  $_POST['dis_url'];

    $editId    = intval($_POST['edit_code']);
    $edittype  = sanitize_text_field($_POST['edit_type']);

    $error='';

    $user = wp_get_current_user();
    $role = ( array ) $user->roles;

    if (in_array('administrator', $role) || in_array('bbp_keymaster', $role))
    {

     
      if( empty( $code )) {
        $error = 'Please enter discount code.';
      }
      else if( empty($date)) {
        $error = 'Please fill discount date.';
      } else if( empty($deal)) {
        $error = 'Please insert discount deal';
      }else if( empty($dis_url)) {
        $error = 'Please insert website url';
      }
      if($error){
      echo json_encode(array('status'=>'fail','message'=>$error));
      }else{

          require_once(ABSPATH . "wp-admin" . '/includes/image.php');
          require_once(ABSPATH . "wp-admin" . '/includes/file.php');
          require_once(ABSPATH . "wp-admin" . '/includes/media.php');


          if($edittype != 'edit'){

               // Create post object
               $my_post  = array(
                                 'post_title'   => $deal,
                                 'post_content' => $deal,
                                 'post_status'  => 'publish',
                                 'post_type'    => 'discount', // we can set custom post type too
                          );
             
              // Insert the post into the database
              $post_ID = wp_insert_post( $my_post );


               /* update extra fields here */

              update_post_meta($post_ID,'discount_code',$code);
              update_post_meta($post_ID,'discount_expire_date',$date);
              update_post_meta($post_ID,'discount_web_url',$dis_url);

                /* create feature image here */
              
              $uploaddir = wp_upload_dir();
              $file = $_FILES['dis_logo' ];
              $uploadfile = $uploaddir['path'] . '/' . basename( $file['name'] );
              $uploadfileurl = $uploaddir['url'] . '/' . basename( $file['name'] );
              move_uploaded_file( $file['tmp_name'] , $uploadfile );
              $filename = basename( $uploadfile );
              $wp_filetype = wp_check_filetype(basename($filename), null );
              $attachment = array(
                 'guid' => $uploadfileurl,
                'post_mime_type' => $wp_filetype['type'],
                'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
                'post_content' => '',
                'post_status' => 'inherit',
                'menu_order' => $_i + 1000
                );

              $attach_id = wp_insert_attachment( $attachment, $uploadfile );

              update_post_meta($post_ID,'_thumbnail_id',$attach_id);
              set_post_thumbnail($post_ID, $attach_id );

              echo json_encode(array('status'=>'ok','message'=>'Discount code hasbeen add sucessfully'));
           

          }else{


                  // update post object
                  $my_post  = array(
                               
                               'ID'           => $editId,
                               'post_title'   => $deal,
                               'post_content' => $deal,
                               'post_status'  => 'publish',
                               'post_type'    => 'discount', // we can set custom post type too
                        );
           
                  // Insert the post into the database
                  $post_ID = wp_update_post( $my_post );


                  /* update extra fields here */

              update_post_meta($post_ID,'discount_code',$code);
              update_post_meta($post_ID,'discount_expire_date',$date);
              update_post_meta($post_ID,'discount_web_url',$dis_url);

              if($logo !=''){

                 $attachment_id = get_post_thumbnail_id( $editId );
                 wp_delete_attachment($attachment_id, true);


                 $uploaddir = wp_upload_dir();
                $file = $_FILES['dis_logo' ];
                $uploadfile = $uploaddir['path'] . '/' . basename( $file['name'] );
                $uploadfileurl = $uploaddir['url'] . '/' . basename( $file['name'] );
                move_uploaded_file( $file['tmp_name'] , $uploadfile );
                $filename = basename( $uploadfile );
                $wp_filetype = wp_check_filetype(basename($filename), null );
                $attachment = array(
                   'guid' => $uploadfileurl,
                  'post_mime_type' => $wp_filetype['type'],
                  'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
                  'post_content' => '',
                  'post_status' => 'inherit',
                  'menu_order' => $_i + 1000
                  );

                $attach_id = wp_insert_attachment( $attachment, $uploadfile );

                update_post_meta($post_ID,'_thumbnail_id',$attach_id);
                set_post_thumbnail($post_ID, $attach_id );



              }

              echo json_encode(array('status'=>'ok','message'=>'Discount code hasbeen update sucessfully'));


          }

      }

    
  }

}

die(0);  
}

/* display edit discount data in popup */
add_action('wp_ajax_update_discount_data','update_discount_data');
function update_discount_data(){

  global $wpdb;

   $id    = intval($_POST['id']);
   $data  = get_post($id); 

    $code     =  get_post_meta($id,'discount_code',true);
    $date     =  get_post_meta($id,'discount_expire_date',true);
    $dis_url  =  get_post_meta($id,'discount_web_url',true);
    $logo     =  wp_get_attachment_image_src( get_post_thumbnail_id( $id ));
    $title    =  $data->post_title;

    $combinedata =   array(

                              'dis_code'  => $code,
                              'dis_date'  => $date,
                              'dis_deal'  => $title,
                              'dis_logo'  => $logo[0],
                              'dis_url'   => $dis_url, 
                        );
   echo json_encode($combinedata);
die(0);  
}



/* delete discount data */
add_action('wp_ajax_delete_discount_data','delete_discount_data');
function delete_discount_data(){

  global $wpdb;

   $id    = intval($_POST['id']);
   $data  = get_post($id); 

   wp_delete_post( $id);
                        
   echo json_encode(array('status'=>'ok','message'=>'delete'));
die(0);  
}

/* delete custom message here */
add_action('wp_ajax_custom_delete_message','custom_delete_message');
function custom_delete_message(){

  global $wpdb,$bp;

    $userId        =  intval($_POST['userId']);
    $message_id    =  $_POST['message_id'];

    $explode  = explode(',',$message_id);

    $res  = '';

     foreach($explode as $id){

        $res =    messages_delete_thread($id,$userId);

     }


      echo $res;

die(0);
}


/*
Description: Add Description Tab to the groups page.
*/
function add_groups_description_page(){
global $bp,$wpdb;

$groups_link = $bp->root_domain . '/' . $bp->groups->slug . '/' . $bp->groups->current_group->slug . '/';

     $user = wp_get_current_user();
     $role = ( array ) $user->roles;
    
      $currentUserId  = $user->ID;

      $tg           = $wpdb->prefix.'bp_groups';
      $matchchapter =  $wpdb->get_row($wpdb->prepare("SELECT creator_id FROM {$tg} WHERE creator_id = %d",$currentUserId));

     if (in_array('administrator', $role) || count($matchchapter) > 0)
      {

          bp_core_new_subnav_item( array(
              'name' => 'Manage',
              'slug' => 'manage-chapter',
              'parent_slug' => $bp->groups->current_group->slug,
              'parent_url' => bp_get_group_permalink( $bp->groups->current_group ),
              'screen_function' => 'group_description_function_to_show_screen',
              'position' => 100 ) );
          }

      }
add_action( 'wp', 'add_groups_description_page');

function group_description_function_to_show_screen() {

    add_action( 'bp_template_title', 'group_description_function_to_show_screen_title' );
    add_action( 'bp_template_content', 'group_description_function_to_show_screen_content' );

    $templates = array('groups/single/plugins.php','plugin-template.php');
    if( strstr( locate_template($templates), 'groups/single/plugins.php' ) ) {
      bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'groups/single/plugins' ) );
    } else {
      bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'plugin-template' ) );
    }
}

function group_description_function_to_show_screen_title() {
    echo 'Manage';
}

function group_description_function_to_show_screen_content() {
global $bp;
     if(is_user_logged_in()){

         get_template_part( 'template-parts/manage-chapter', 'code' );

      }
}

/* update manage chapter setting here */
add_action('wp_ajax_update_chapter_setting_frontend','update_chapter_setting_frontend');
function update_chapter_setting_frontend(){

  global $wpdb;

  $nonce = $_REQUEST['_manage_seting_nonce'];
  if(wp_verify_nonce($nonce, 'log-chapter-setting')) {


     $ChapterName      =  sanitize_text_field($_POST['chapt_name']);
     $Chapterdesc      =  sanitize_text_field($_POST['about_chapter']);
     $Chaptersetting   =  sanitize_text_field($_POST['group-status']);
     $ChapterId        =  intval($_POST['update_chapter_setting']);


    $max_file_size = 1024*200; // 200kb
    $valid_exts = array('jpeg', 'jpg', 'png', 'gif');
    // thumbnail sizes
    $sizes = array(250 => 250, 500,500);

    $upload_dir   = wp_upload_dir();
    $groupFolderName="group-avatars";

   $avatarPath= $upload_dir['basedir']."/".$groupFolderName."/".$ChapterId."/";
      if ( ! file_exists( $avatarPath ) ) {
          wp_mkdir_p( $avatarPath );
      }

    $filename=$_FILES['file']['name'];

    $ext = pathinfo($filename, PATHINFO_EXTENSION);

    $fullImageName=time().'-bpfull.'.$ext;
    $thumbImageName=time().'-bpthumb.'.$ext;

    $fullPathThumb= $avatarPath.$thumbImageName;
    $fullPath= $avatarPath.$fullImageName;
    $err=array();

     if( isset($_FILES['file']['size']) && $_FILES['file']['size'] > 0){

          foreach (glob($avatarPath."/*-bpthumb.*") as $filename) {  
             unlink($filename);
          } 

        foreach (glob($avatarPath."/*-bpfull.*") as $filename1) {  
             unlink($filename1);
          }
          $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));

              if (in_array($ext, $valid_exts)) {
                /* resize image */
                 move_uploaded_file( $file['tmp_name'] , $fullPathThumb );
                 move_uploaded_file( $file['tmp_name'] , $fullPath );
                resize(250, 250,'file',$fullPathThumb);
                resize(500, 500,'file', $fullPath);
                 
              } else {
                $err[] = 'Unsupported file type!';
              }
     }
     if(empty($ChapterName)){
         $err[] = 'Chapter name can not be blank!';
     }


   if(empty($err)){
     $tableGroup   =  $wpdb->prefix.'bp_groups';

      $wpdb->update( 
            $tableGroup, 
            array( 
              
              'name'        => $ChapterName,
              'description' => $Chapterdesc,
              'status'      => $Chaptersetting,
            ),
            array('id' => $ChapterId),
            array( 
              
              '%s', 
              '%s',
              '%s',
            ),
            array('%d')
          );
    }
   
   if(!empty($err)){
      echo json_encode(array('status'=>'fail','error'=>$err));  
   }else{
     echo json_encode(array('status'=>'ok','message'=>'Chapter setting hasbeen updated'));  
   }
   
}
die();
}

/* get total friend here */

function get_total_friends(){

   global $bp,$wpdb;

  $initiator_userid = get_current_user_id();
  $table = $wpdb->prefix.'bp_friends';
  $is_confirmed = 1;

  $totalFriends   = $wpdb->get_results($wpdb->prepare("SELECT * From $table WHERE  `is_confirmed` = %d AND `initiator_user_id` = %d", $is_confirmed,$initiator_userid),ARRAY_A);

  return count($totalFriends);

}

/* add and edit paertner from frontend shortcode register here */
function create_html_add_edit_partner(){

   $html='';
   ob_start();
      require get_theme_file_path( '/template-parts/inviteHTML/add_edit_partner_code.php');
     $html.=ob_get_contents();
    ob_get_clean();
    return $html; 

}
add_shortcode('NEW_PARTNER_CODE','create_html_add_edit_partner');

/* save and update partnet from frontend */

add_action('wp_ajax_custom_partner_add_edit','custom_partner_add_edit');
function custom_partner_add_edit(){


  $nonce = $_REQUEST['_partner_nonce'];
  if(wp_verify_nonce($nonce, 'log-partner-nonce')) {


    $name      =  sanitize_text_field($_POST['part_name']);
    $desc2     =  $_POST['des_partner'];
    $website   =  sanitize_text_field($_POST['partner_website']);
    $logo      =  $_FILES['partner_logo']['name'];

    $editId    = intval($_POST['edit_part_id']);
    $edittype  = sanitize_text_field($_POST['edit_type']);

    $error='';

    $user = wp_get_current_user();
    $role = ( array ) $user->roles;

    if (in_array('administrator', $role) || in_array('bbp_keymaster', $role))
    {

     
      if( empty( $name )) {
        $error = 'Please enter partner name.';
      }
      else if( empty($desc2)) {
        $error = 'Please fill partner description.';
      } else if( empty($website)) {
        $error = 'Please inser partner website';
      }
      if($error){
      echo json_encode(array('status'=>'fail','message'=>$error));
      }else{

         
          require_once(ABSPATH . "wp-admin" . '/includes/file.php');
          require_once(ABSPATH . "wp-admin" . '/includes/media.php');


          if($edittype != 'edit'){

               // Create post object
               $my_post  = array(
                                 'post_title'   => $name,
                                 'post_content' => $desc2,
                                 'post_status'  => 'publish',
                                 'post_type'    => 'sponsor', // we can set custom post type too
                          );
             
              // Insert the post into the database
              $post_ID = wp_insert_post( $my_post );


               /* update extra fields here */

              update_post_meta($post_ID,'wp_sponsors_url',$website);
              update_post_meta($post_ID,'wp_sponsors_desc',$desc2);
              update_post_meta($post_ID,'wp_sponsor_link_behaviour',1);
              

                /* create feature image here */
              
              $uploaddir = wp_upload_dir();
              $file = $_FILES['partner_logo' ];
              $uploadfile = $uploaddir['path'] . '/' . basename( $file['name'] );
              $uploadurl = $uploaddir['url'] . '/' . basename( $file['name'] );
              move_uploaded_file( $file['tmp_name'] , $uploadfile );
              $filename = basename( $uploadfile );
              $wp_filetype = wp_check_filetype(basename($filename), null );
              $attachment = array(
                'guid' => $uploadurl, 
                'post_mime_type' => $wp_filetype['type'],
                'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
                'post_content' => '',
                'post_status' => 'inherit',
                'menu_order' => $_i + 1000
                );

              $attach_id = wp_insert_attachment( $attachment, $uploadfile );

              require_once( ABSPATH . 'wp-admin/includes/image.php' );

              $attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
              wp_update_attachment_metadata( $attach_id, $attach_data );

              update_post_meta($post_ID,'_thumbnail_id',$attach_id);
              set_post_thumbnail($post_ID, $attach_id );

              echo json_encode(array('status'=>'ok','message'=>'Partner has been add sucessfully!!'));
           

          }else{


                  // update post object
                  $my_post  = array(
                               
                               'ID'           => $editId,
                               'post_title'   => $name,
                               'post_content' => $desc2,
                               'post_status'  => 'publish',
                               'post_type'    => 'sponsor', // we can set custom post type too
                        );
           
                  // Insert the post into the database
                  $post_ID = wp_update_post( $my_post );


                  /* update extra fields here */

              update_post_meta($post_ID,'wp_sponsors_url',$website);
              update_post_meta($post_ID,'wp_sponsors_desc',$desc2);
              update_post_meta($post_ID,'wp_sponsor_link_behaviour',1);


              if($logo !=''){

                 $attachment_id = get_post_thumbnail_id( $editId );
                 wp_delete_attachment($attachment_id, true);


                 $uploaddir = wp_upload_dir();
                $file = $_FILES['partner_logo' ];
                $uploadfile = $uploaddir['path'] . '/' . basename( $file['name'] );
                $uploadurl = $uploaddir['url'] . '/' . basename( $file['name'] );
                move_uploaded_file( $file['tmp_name'] , $uploadfile );
                $filename = basename( $uploadfile );
                $wp_filetype = wp_check_filetype(basename($filename), null );
                $attachment = array(
                  'guid' => $uploadurl,
                  'post_mime_type' => $wp_filetype['type'],
                  'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
                  'post_content' => '',
                  'post_status' => 'inherit',
                  'menu_order' => $_i + 1000
                  );

                $attach_id = wp_insert_attachment( $attachment, $uploadfile );

                update_post_meta($post_ID,'_thumbnail_id',$attach_id);
                set_post_thumbnail($post_ID, $attach_id );
              }

              echo json_encode(array('status'=>'ok','message'=>'Updated sucessfully!!'));
            }

      }
    }

}
die(0);  
}

/* display edit discount data in popup */
add_action('wp_ajax_update_partner_data','update_partner_data');
function update_partner_data(){

  global $wpdb;

   $id    = intval($_POST['id']);
   $data  = get_post($id); 

    $web      =  get_post_meta($id,'wp_sponsors_url',true);
    //$desc     =  get_post_meta($id,'wp_sponsors_desc',true);
    $desc     =  $data->post_content;
    $logo     =  wp_get_attachment_image_src( get_post_thumbnail_id( $id ));
    $title    =  $data->post_title;

    $combinedata =   array(

                              'par_name'  => $title,
                              'par_web'   => $web,
                              'par_desc'  => $desc,
                              'par_logo'  => $logo[0],
                        );
   echo json_encode($combinedata);
die();  
}

/* delete partner data */
add_action('wp_ajax_delete_partner_data','delete_partner_data');
function delete_partner_data(){

  global $wpdb;

   $id    = intval($_POST['id']);
   $data  = get_post($id); 

   wp_delete_post( $id);
                        
   echo json_encode(array('status'=>'ok','message'=>'delete'));
die(0);  
}

/* trash topic which created by user */
add_action('wp_ajax_custom_delete_user_created_event','custom_delete_user_created_event');
function custom_delete_user_created_event(){

  global $wpdb,$EM_Event;

   $post_id    = intval($_POST['post_id']);
   $em_id    = intval($_POST['event_id']);
    $EM_Event->event_id= $em_id;
    $EM_Event->delete(true);
    
die(0);  
}


/* trash topic which created by user */
add_action('wp_ajax_custom_delete_user_created_topic','custom_delete_user_created_topic');
function custom_delete_user_created_topic(){

  global $wpdb;

   $id    = intval($_POST['topic_id']);
   wp_delete_post( $id);
    
die(0);  
}



remove_action( 'mpp_setup', 'mpp_group_init' );
function mpp_group_init12() {

  mpp_register_status( array(
    'key'              => 'groupsonly',
    'label'            => __( 'Chapter Only', 'mediapress' ),
    'labels'           => array(
      'singular_name' => __( 'Chapter Only', 'mediapress' ),
      'plural_name'   => __( 'Chapter Only', 'mediapress' )
    ),
    'description'      => __( 'Chapter Only Privacy Type', 'mediapress' ),
    'callback'         => 'mpp_check_groups_access',
    'activity_privacy' => 'grouponly',
  ) );
}

add_action( 'mpp_setup', 'mpp_group_init12' );

/* disable plugin update */
function my_filter_plugin_updates( $value ) {
   if( isset( $value->response['bbpress/bbpress.php'] ) ) {        
      unset( $value->response['bbpress/bbpress.php'] );
    }

    if( isset( $value->response['buddypress/bp-loader.php'] ) ) {        
      unset( $value->response['buddypress/bp-loader.php'] );
    }

    if( isset( $value->response['mediapress/mediapress.php'] ) ) {        
      unset( $value->response['mediapress/mediapress.php'] );
    }

    if( isset( $value->response['events-manager/events-manager.php'] ) ) {        
      unset( $value->response['events-manager/events-manager.php'] );
    }

    if( isset( $value->response['invite-anyone/invite-anyone.php'] ) ) {        
      unset( $value->response['invite-anyone/invite-anyone.php'] );
    }
    return $value;
 }
 add_filter( 'site_transient_update_plugins', 'my_filter_plugin_updates' );


 /* delete forum data */
add_action('wp_ajax_custom_delete_user_created_forum','custom_delete_user_created_forum');
function custom_delete_user_created_forum(){

  global $wpdb;

   $id    = intval($_POST['forum_id']);
   $data  = get_post($id); 

   wp_delete_post( $id);
                        
   echo '1';
die(0);  
}
/* Remove member from chapter from frontend here */
add_action('wp_ajax_delete_member_from_chapter_from_frontend','delete_member_from_chapter_from_frontend');
function delete_member_from_chapter_from_frontend(){

     global $wpdb;

     $userId   = intval($_POST['userid']);
     $groupid  = intval($_POST['groupid']);

     $chapterTable  = $wpdb->prefix.'bp_groups_members';

     $sql  =  $wpdb->query($wpdb->prepare("DELETE FROM $chapterTable WHERE user_id = %d AND group_id = %d",$userId,$groupid));

     echo json_encode(array('status'=>'ok','message'=>'delete'));

 die(); 
}
?> 