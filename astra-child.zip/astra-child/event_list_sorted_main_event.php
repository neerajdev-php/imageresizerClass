<?php 
// the query
global $wp_query;
$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
$args=array(
	'post_type'=>'event',
	'posts_per_page'=>5,
	'post_status'=>'publish',
	'paged' => $paged,
	'page' => $paged,
	);
$event_control=array('public');
 if(is_user_logged_in()){

 	$event_control=array('public','loggedin');
 }
$args['meta_query']=array(
		array(
			'key'     => 'event_control',
			'value'   => $event_control,
			'compare' => 'IN',
		),
	);
$the_query = new WP_Query( $args );
/*pr($the_query);*/

$checkRole = wp_get_current_user();
$role = ( array ) $checkRole->roles;
//echo '<pre>'; print_r($role);
//if (in_array('subscriber', $role))
//{
	//echo '<p>Sorry, You are not authorized for this.</p>';

//}else{
 ?>

<?php if ( $the_query->have_posts() ) : ?>

<!-- pagination here -->
 <div class="event_list_container">
   <div class="upcoming_event_list">
    		<div class="event_head"><h3>Upcoming Events</h3></div>
    		 <!-- the loop -->
			<?php
			$html_upcoming='';
			global $post;
			if($the_query->have_posts()){
			   while ( $the_query->have_posts() ) : $the_query->the_post(); 
							$post_id='';
							$post='';
							$start_date='';
							$end_date='';
							$post= $the_query->post;
		                    setup_postdata($post); 
		                   $post_id= $post->ID;	

		                   $eventData= get_actual_event_id($post_id);  
		                   $em_id= $eventData->event_id;
		                   $emEditlink = home_url( '/members/' . bp_core_get_username( get_current_user_id() ) . '/events/my-events/?action=edit&event_id='.$em_id );    
									
							$start_date= get_post_meta($post_id,'_event_start_date',true);
							$end_date= get_post_meta($post_id,'_event_end_date',true);
						 	if( strtotime($start_date) >= strtotime(date('Y-m-d'))){
						 	 $nonImageContent='';				 		
		                            $html_upcoming.='<div class="repeat-events">'; 
		                            if(has_post_thumbnail()){
		                               $html_upcoming.='<div class="event_list_thumb">';
		                                 	$feat_image_url = wp_get_attachment_url( get_post_thumbnail_id() );
		                                $html_upcoming.='<a href="'.get_the_permalink().'"><img src="'.$feat_image_url.'" class="img_responsive"></a>';
		                               $html_upcoming.='</div>';
		                             }else{
		                             	//$nonImageContent='nonimageevent';
		                             	
		                             	$html_upcoming.='<div class="event_list_thumb">';
		                                 	$feat_image_url = get_bloginfo( 'stylesheet_directory' ) . '/images/default-thumbnail.jpg';
		                                $html_upcoming.='<a href="'.get_the_permalink().'"><img src="'.$feat_image_url.'" class="img_responsive"></a>';
		                               $html_upcoming.='</div>';
		                             }    
									$html_upcoming.='<div class="event_list_header '.$nonImageContent.'">';
									$html_upcoming.='<div class="event_title_head"> <a href="'.get_the_permalink().'">'. get_the_title()."</a></div>";
									$html_upcoming.='<div class="event_meta_container"> '; 
									$html_upcoming.='<div class="event_meta_head"> Start Date: '.date('F d, Y',strtotime($start_date))."</div>";
									$html_upcoming.='<div class="event_meta_head"> End Date: '.date('F d, Y',strtotime($end_date))."</div>";

									if(is_user_logged_in() && current_user_can('administrator') ){
									   $html_upcoming.='<div class="event_meta_actions" style="display:none;"><a class="edit_em_single ast_edit_icon" href="'.$emEditlink.'">Edit</a> <a class="delete_em_single ast_del_icon" data-em-id="'.$em_id.'" data-post-id="'.$post_id.'" href="javascript:void(0);">Delete</a></div>';
									}    

									$html_upcoming.='</div>';
									$html_upcoming.='</div>'; 
									$html_upcoming.='</div>'; 
						 	}
                        
					?>
			 <?php endwhile; ?>
			 <?php if(!$html_upcoming){ ?>
			 	   <div class="repeat-events"><p><?php esc_html_e( 'Sorry, no upcoming events found!' ); ?></p></div>
			  <?php }else{ 
			  	        echo $html_upcoming; 
			        }   	
			    } 

			 ?>	
	</div>


		<div class="event_calender">
			

			<?php echo do_shortcode('[fullcalendar]');?>


		</div>


     <div class="past_event_list">
    		<div class="event_head"><h3>Past Events</h3></div> 
       			<?php
			$html_past='';
			global $post;
			if($the_query->have_posts()){
			   while ( $the_query->have_posts() ) : $the_query->the_post();
			     
			     ?>
						<?php 
							$post_id='';
							$post='';
							$start_date='';
							$end_date='';
							$post= $the_query->post;
		                    setup_postdata($post); 
		                    $post_id= $post->ID;	              
							$eventData= get_actual_event_id($post_id);  
			                $em_id= $eventData->event_id;
		                    $emEditlink = home_url( '/members/' . bp_core_get_username( get_current_user_id() ) . '/events/my-events/?action=edit&event_id='.$em_id );	

							$start_date= get_post_meta($post_id,'_event_start_date',true);
							$end_date= get_post_meta($post_id,'_event_end_date',true);
						 	if( strtotime($start_date) < strtotime(date('Y-m-d'))){				 		
		                            $html_past.='<div class="repeat-events">'; 
		                            $nonImageContent='';
		                            if(has_post_thumbnail()){

		                               $html_past.='<div class="event_list_thumb">';
		                                 	$feat_image_url = wp_get_attachment_url( get_post_thumbnail_id() );
		                                $html_past.='<a href="'.get_the_permalink().'"><img src="'.$feat_image_url.'" class="img_responsive"></a>';
		                               $html_past.='</div>';
		                             }else{
		                             	$html_past.='<div class="event_list_thumb">';
		                                 	$feat_image_url = get_bloginfo( 'stylesheet_directory' ) . '/images/default-thumbnail.jpg';
		                                $html_past.='<a href="'.get_the_permalink().'"><img src="'.$feat_image_url.'" class="img_responsive"></a>';
		                               $html_past.='</div>';
		                             }  
									$html_past.='<div class="event_list_header '.$nonImageContent.' ">';
									$html_past.='<div class="event_title_head"><a href="'.get_the_permalink().'">'. get_the_title()."</a></div>";
									$html_past.='<div class="event_meta_container"> '; 
									$html_past.='<div class="event_meta_head"> Start Date: '.date('F d, Y',strtotime($start_date))."</div>";
									$html_past.='<div class="event_meta_head"> End Date: '.date('F d, Y',strtotime($end_date))."</div>"; 
									if(is_user_logged_in() && current_user_can('administrator') ){

									   /*$html_past.='<div class="event_meta_actions"><a class="edit_em_single" href="'.$emEditlink.'">Edit</a> <a class="delete_em_single" data-em-id="'.$em_id.'" data-post-id="'.$post_id.'" href="javascript:void(0);" style="display:none;">Delete</a></div>';*/


									   $html_past.='<div class="event_meta_actions" style="display:none;"><a class="edit_em_single ast_edit_icon" href="'.$emEditlink.'">Edit</a> <a class="delete_em_single ast_del_icon" data-em-id="'.$em_id.'" data-post-id="'.$post_id.'" href="javascript:void(0);">Delete</a></div>';
									}  

									$html_past.='</div>'; 
									$html_past.='</div>'; 
								 	$html_past.='</div>'; 
						 	}
                        
					?>
			 <?php endwhile; ?>


			 <?php if(!$html_past){ ?>
			 	   <div class="repeat-events"><p><?php esc_html_e( 'Sorry, no past events found!' ); ?></p></div>
			  <?php }else{ 
			  	        echo $html_past; 
			        }   	
			    } 

			 ?>	
	 </div>		  

     <?php
      if (function_exists('custom_pagination')) {
      //	pr($the_query);
        custom_pagination($the_query->max_num_pages,"",$paged);
      }
    ?>

	<!-- end of the loop -->

	<!-- pagination here -->

	<?php wp_reset_postdata(); ?>

<?php else : ?>
	<p><?php esc_html_e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; 
//}?>
 </div>