<?php 
global $bp,$wpdb;
global $groups_template;
$chapterId  =  $groups_template->groups[0]->group_id;
$table      = $wpdb->prefix.'bp_groups';
$res        = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %s",$chapterId),ARRAY_A);
$groupImage = bp_get_group_avatar($chapterId);


?>
<div id="item-body">
   <h2 class="bp-screen-reader-text">Account settings</h2>
   <div class="custom-container-header">
      <div class="custom-container">
         <div class="ast-row">
            <div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
               <h3>General Settings</h3>
            </div>
            <div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
               <h3>Privacy Options</h3>
            </div>
         </div>
      </div>
   </div>

   <form action="" method="post" class="standard-form chapter_setting" id="chapter_setting" enctype="multipart/form-data">
      <div class="custom-container">
         <div class="ast-row">

            <div class="ast-col-lg-5 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
               
               <label for="email">Chapter Name</label>
               <input type="text" name="chapt_name" id="" value="<?php echo $res['name'];?>" class="settings-input">
               <label for="pass1">About the Chapter</label>
               <textarea name="about_chapter" class="about_chapter"><?php echo $res['description'];?></textarea>

               <label for="file">Chapter Photo</label>
               <div class="img_file_container">
                  <div class="img_preview custom_group_avatar"><?php echo $groupImage;?></div>
                  <input type="file" name="file" id="file">
                 
               </div>
            </div>
            <div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12 ast-col-lg-offset-1">
               
            	<div class="chapter_status">
            		
            		<div class="inner_priva">

            	      <input type="radio" name="group-status" id="bp-group-status-public" <?php if(isset($res['status']) && $res['status'] == 'public'){ echo 'checked=checked';}?> value="public"><span>This is a Public Chapter</span>
					</div>

					<p>Public Chapters are visible in all chapter directories. The contents of the chapter – activity updates, forum posts, and any additional chapter functionality you might add through plugins – is publicly accessible. Anyone in your Team RWB Tri community can join a Public Chapter.</p>

            	</div>

            	<div class="chapter_status">

            		<div class="inner_priva">
            		

            		<input type="radio" name="group-status" id="bp-group-status-private" <?php if(isset($res['status']) && $res['status'] == 'private'){ echo 'checked=checked';}?> value="private"><span>This is a Private Chapter</span>

            		 </div>

					<p>Private Chapters are also visible in chapter directories. The chapter name andchapter description remain available for all to see. However, the contents of the chapter are accessible only to members. Moreover, chapter membership is controlled: members of your broader Team RWB Tri community must request membership, which can only be granted by a Chapter Head.</p>

            	</div>

            	<div class="chapter_status">

            		<div class="inner_priva">
            		

            		<input type="radio" name="group-status" id="bp-group-status-hidden" <?php if(isset($res['status']) && $res['status'] == 'hidden'){ echo 'checked=checked';}?> value="hidden"><span>This is a Hidden Chapter</span>

            	
				</div>

					<p>Hidden Chapters are invisible to non-members. These chapter names and descriptions are not listed in sitewide directories, and their contents are accessible only to members of the chapter. Because the chapter is unlisted, users cannot request membership. Instead, individuals can only join the chapter by invitation.</p>


            	</div>

            	<div clas="chapter_status">
            		

            	<strong class="bbbb_tt">Chapter Heads can change a chapter’s privacy settings at any time by visiting the chapter’s Manage tab.</strong>


            	</div>
			</div>


         </div>

         <div class="ast-row">
            <div class="ast-col-lg-5 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
               <div class="submit">
                  <input type="submit" name="submit" value="Save Changes" id="submit" class="auto">
               </div>
            </div>
         </div>

         <div class="ast-clearfix"></div>

        <div class="ast-row">
         <div class="ast-col-lg-5 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">

            <div class="image_loader_manage1" style="display:none; text-align: center;">
                     <img src="<?php echo get_stylesheet_directory_uri().'/images/common-loader.gif'?>">
             </div>
            <div class="after_sucess_msg"></div>
         </div>
         </div>
     


      </div>
      <input type="hidden" name="update_chapter_setting" value="<?php echo $chapterId;?>">
      <input type="hidden" name="action" value="update_chapter_setting_frontend">
      <input type="hidden" name="_manage_seting_nonce" value="<?php echo wp_create_nonce( 'log-chapter-setting' ); ?>">
   </form>

   

         
</div>
<script type="text/javascript">
   jQuery(function($){
       
         jQuery('body').on('submit','#chapter_setting',function(){
         var formData = new FormData(jQuery(this)[0]);
          jQuery('.after_sucess_msg').html('');  
          jQuery('.image_loader_manage1').show();

             setTimeout(function(){
                  jQuery('.after_sucess_msg').html('');  
                  jQuery.ajax({
                        type:"POST",
                        url: ajaxurl,
                        data:formData,
                        dataType: "json",
                        async: false,
                        cache: false,
                        dataType: "json",
                        contentType: false,
                        processData: false,
                        success:function(res){
                          if(res.status=="fail"){

                              jQuery('.image_loader_manage1').hide();
                              errHtml='';
                              jQuery.each(res.error,function(index,item){

                                 errHtml+='<div class="ast-alert-danger">'+item+'</div>';
                              });

                              jQuery('.after_sucess_msg').html(errHtml);                          
                           }else{

                               jQuery('.image_loader_manage1').hide();
                               jQuery('.after_sucess_msg').html('');
                               jQuery('.after_sucess_msg').html('<div class="ast-alert-success">'+res.message+'</div>');
                              
                           }
                           
                        }
                    });

             },200);

           return false;
       });

});
 </script>


	