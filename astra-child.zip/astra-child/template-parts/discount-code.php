<?php 
global $wpdb;
 $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args =  array(
                  //'page'         =>  $paged,
                  //'paged'         =>  $paged,
                  //'posts_per_page' =>  '1',
                  'post_type'    => 'discount',
                  'post_status'  =>  'publish',
                  'order'        => 'desc',
               );
$the_query = new WP_Query( $args );
?>
<div class="discount-codes-row">
   <div class="discount-codes-col-6">
      <div class="discount-exclusive">
         <div class="discount-exclusive-div">
            <h3>Exclusive MBS Discounts</h3>
            <p>Get exclusive discounts on the My Bike Shop page. 
               With already amazing prices you will make sure your 
               team has the best in the industry.
            </p>
            <a href="<?php echo site_url('team-rwb-deals'); ?>" class="btn btn-go-to-mbs">Go to MBS</a>
         </div>
      </div>
   </div>
   <div class="discount-codes-col-6">
      <div class="discount-Sponsor">
         <h3>Sponsor Codes</h3>
         <p>With our easy to use interface quickly change, 
            modify and add your sponsor codes so your team 
            has instant access to them.
         </p>
      </div>
   </div>
</div>
<div class="discount-table">
   <ul class="discount-table-ul">
      <li>
         <div class="discount-table-store">
            <strong>Store</strong>
         </div>
         <div class="discount-table-deal">
            <strong>Deal</strong>
         </div>
         <div class="discount-table-code">
            <strong>Code</strong>
         </div>
      </li>
<?php if ( $the_query->have_posts() ) : 
      while ( $the_query->have_posts() ) : $the_query->the_post(); 

         $post_ID  =  get_the_id();
         $code     =  get_post_meta($post_ID,'discount_code',true);
         $date     =  get_post_meta($post_ID,'discount_expire_date',true);
         $url      =  get_post_meta($post_ID,'discount_web_url',true);
         $logo     = wp_get_attachment_image_src( get_post_thumbnail_id( $post_ID ));
         $convertDate   =  strtotime($date);

         if(isset($url) && !empty($url)){ $link =  $url; }else{ $link = 'javascript:void(0)';}
      ?>
      <li class="dis_hide_<?php echo $post_ID;?>">
         <div class="discount-table-store">
            <div class="discount-table-store-img"> 
              <div class="inner_store_im">
               <img src="<?php echo $logo[0];?>" alt="">
               </div>
            </div>
         </div>
         <div class="discount-table-deal">
            <div class="discount-table-box">
               <span>Expire <?php if(isset($date)){ echo date('F Y',$convertDate);}?></span>
               <h4><?php the_title();?></h4>
            </div>
         </div>
         <div class="discount-table-code">
            <div class="discount-table-box">
               <?php 
               $user = wp_get_current_user();
                        $role = ( array ) $user->roles;
                        if (in_array('administrator', $role))
                        {
               ?>
               <div class="after_click_edit">
                  <span class="discount_edit">
                     <a href="javascript:void(0);" data-id="<?php echo $post_ID;?>" data-type="edit"></a>
                  </span>
                  <span class="discount_delete">
                    <a href="javascript:void(0);" data-id="<?php echo $post_ID;?>"></a>
                  </span>
            </div>
             <?php } ?>
               <span>Use at Checkout</span>
               <h3><?php  echo $code;?></h3>
               <a href="<?php echo $link;?>" class="btn discount-table-btn" target="_blank"></a> 
            </div>
         </div>
      </li>
   <?php endwhile; ?>
      <?php wp_reset_postdata(); ?>
      <?php else : ?>
            <p><?php esc_html_e( 'Sorry, no discount code were found.' ); ?></p>
<?php endif; ?>
</ul>
</div>

</div>
<?php echo do_shortcode('[NEW_DISCOUNT_CODE]');?>
<script>
jQuery(function($){
         jQuery('.discount_edit >a').click(function(){
         var id    = jQuery(this).attr('data-id');
           var type  = jQuery(this).attr('data-type');
            jQuery.ajax({
               type:"POST",
               url: ajaxurl,
               dataType: "json",
               data: {"action": "update_discount_data", 'id':id },
               success:function(res){
                  console.log(res);
                  if(res.status=="fail"){
                  }else{
                       jQuery('.update_code_discount').val(id);
                       jQuery('.type_code_discount').val(type);
                       jQuery('.edit_dis_code').val(res.dis_code);
                       jQuery('.edit_dis_date').val(res.dis_date);
                       jQuery('.edit_dis_deal').val(res.dis_deal);
                       jQuery('.edit_store_logo').attr('src',res.dis_logo);
                       jQuery('.edit_dis_url').val(res.dis_url);
                       jQuery('#dis_logo').removeAttr("required");
                       jQuery('#popup_add_edit_discount_code .popup').show();
                       jQuery('#popup_add_edit_discount_code .popup_label').text('Update Discount Code').show();
                  }
               }
           });

          return false;
       });

   
    jQuery('.edit_discount_code >a').click(function(){

         jQuery('.after_click_edit').toggle();

    });

});

/* delete post here */
jQuery(function($){
         jQuery('.discount_delete >a').click(function(){
         var id    = jQuery(this).attr('data-id');
       //if(confirm_modal()){
           jQuery.ajax({
               type:"POST",
               url: ajaxurl,
               dataType: "json",
               data: {"action": "delete_discount_data", 'id':id },
               success:function(res){
                  console.log(res);
                  if(res.status=="fail"){
                  }else{
                     jQuery('.dis_hide_'+id).fadeOut('slow');
                     window.location.reload();
                  }
               }
           });
         //}
      });
});          
</script>