<?php
 if(isset($_GET['email']) && isset($_GET['id']) ){

 $user = get_user_by( 'email', $_GET['email'] );
 $get_id= get_user_meta($user->ID,'reset_pass',true); 
  if($get_id){
 ?>
<div class="ast-container">
<div class="reset-pass-form-box">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1 id="popup_label">Reset your password!</h1>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				   		<div class="popup_warnings"></div>
						 <div id="forget_frm_section" class="">
						  <form class="reset_frm" id="reset_frm" method="post">
						  
						   <input type="hidden" name="action" value="custom_reset_password_now">	 
						   <input type="hidden" name="email" value="<?php echo $_GET['email']; ?>">	 
						   <input type="hidden" name="_reset_nonce" value="<?php echo wp_create_nonce( 'log-reset-nonce' ); ?>">	
						  
						  <div class="popup-form-group">
						        <label for="password">New Password</label>
						  		<input type="password" name="password" id="password">
						  </div>

						<div class="popup-form-group">
						        <label for="password_new">Confirm New Password</label>
						  		<input type="password" name="password_new" id="password_new">
						  </div>		  
						  <div class="popup-form-group">		
						  		<input type="submit" name="submit_forget" id="submit_forget" value="Reset">
						  		</div>
						  </form>

						   <div class="login_section"><a href="javascript:void();" class="login_pass_btn" data-section="#login_frm_section">Login</a></div>
						 </div> 				  
				 </div>
		 </div>
         </div>
</div>
<?php }else{ 
	?>
<div class="ast-container">
    <div class="ast-row invite_main_form"> 
		<div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading"><h1 id="popup_label">Reset your password!</h1></div>
		<div class="ast-alert-warning">Your password already reset.</div>
	</div> 
</div>
	<?php  } } else{ ?>

<div class="ast-container">
    <div class="ast-row invite_main_form"> 
		<div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading"><h1 id="popup_label">404 Not Found!</h1></div>
		<div class="ast-alert-warning">Invalid Request</div>
	</div> 
</div>
	<?php 	} ?>
<script type="text/javascript">
   jQuery(function($){
   	   	jQuery('body').on('submit','#reset_frm',function(){
 		 	  var formData= jQuery(this).serialize();
 		 	  jQuery.ajax({
 		 	  		type:"POST",
 		 	  		url: ajaxurl,
 		 	  		data:formData,
 		 	  		dataType: "json",
 		 	  		beforeSend:function(){
 		 	  			jQuery('.popup_warnings').addClass('ast-alert-info').text('Please wait...');
 		 	  		},
 		 	  		success:function(res){
 		 	  			console.log(res);
 		 	  			if(res.status=="fail"){
                           jQuery('.popup_warnings').removeClass('ast-alert-info').addClass('ast-alert-danger').text(res.message);
 		 	  			}else{
 		 	  				jQuery('.popup_warnings').removeClass('ast-alert-danger').addClass('ast-alert-success').text(res.message);
 		 	  			}
 		 	  			
 		 	  		}
 		 	  });
 		 	  return false;
 		 });

   	   	jQuery('body').on('click','.login_pass_btn',function(){

   	   			jQuery('#popup_login > .popup').show();
   	   			
   	   	});

   });
</script>