<?php
/**
 * Template part for displaying single posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Astra
 * @since 1.0.0
 */



$image    =  $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
$author   =  get_the_author($post->ID); 
$authorId =  $post->post_author;
$args     = get_avatar_data( $authorId);

$postDate  =  $post->post_date;
$conver    = strtotime($postDate);
?>
<?php astra_entry_before(); ?>
<article itemtype="https://schema.org/CreativeWork" itemscope="itemscope" class="formCON_sec" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php astra_entry_top(); ?>


	<div class="new_image" style="background:url(<?php echo  $image[0];?>) no-repeat center center;"></div>

	<div class="new_author_meta">
		<img src="<?php echo $args[url];?>" class="post_aut_image">
		<span class="aut_name"><?php echo $author;?></span>
		<span class="pos_date"><?php echo date('F d, Y ',$conver).'at '.date('h:i a',$conver);?></span>
	</div>


	<div class="post_desc"><?php the_content();?></div>

	

	<?php //astra_entry_content_single(); ?>

	<?php astra_entry_bottom(); ?>

</article><!-- #post-## -->

<?php astra_entry_after(); ?>
