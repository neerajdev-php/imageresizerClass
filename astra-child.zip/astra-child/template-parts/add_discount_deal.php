<?php 
global $wpdb;
 $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args =  array(
                  //'page'         =>  $paged,
                  //'paged'         =>  $paged,
                  //'posts_per_page' =>  '1',
                  'post_type'    => 'deals',
                  'post_status'  =>  'publish',
                  'order'        => 'desc',
               );
$the_query = new WP_Query( $args );

$get_timer_obj= get_option('deals_timer');
$timer_val= !empty($get_timer_obj['timer_expire_date']) ? $get_timer_obj['timer_expire_date'] : '';

if(is_user_logged_in()){

?>
<div class="discount-codes-row"> 
    <div class="discount-codes-col-12">
       <div class="launch_deal_data">
          <strong class="launch_deal_data-heding">Team RWB Launch Deals</strong>
           <div class="ast-clearfix"></div>
          <div id="PageOpenTimer" class="launch_deal_data-box" data-date="<?php echo $timer_val; ?>" style="width: 500px; height: 125px; float: center;"></div>
       </div>
   </div>
</div>
<div class="discount-table">
   <ul class="discount-table-ul">
      <li class="discount-table-ul-header"> 
         <div class="discount-table-code-tr">
            <strong>Deal</strong>
         </div>
         <div class="discount-table-code-td">
            <strong>DISCOUNT CODE</strong>
         </div>
         <div class="discount-table-code-tr">
            <strong>LINK</strong>
         </div>
      </li>
     <?php if( strtotime($timer_val) > strtotime(date('Y-m-d h:i:s'))  ){ ?> 
    <?php if ( $the_query->have_posts() ) : 
      while ( $the_query->have_posts() ) : $the_query->the_post(); 

         $post_ID  =  get_the_id();
         $code     =  get_post_meta($post_ID,'deal_code',true);
         $date     =  get_post_meta($post_ID,'expired_date',true);
         $url      =  get_post_meta($post_ID,'link',true);
         $logo     = wp_get_attachment_image_src( get_post_thumbnail_id( $post_ID ));
         $convertDate   =  strtotime($date);

         if(isset($url) && !empty($url)){ $link =  $url; }else{ $link = 'javascript:void(0)';}
      ?>
      <li class="discount-table-ul-body dis_hide_<?php echo $post_ID;?>">
     
           <div class="discount-table-code-tr">
               <div class="discount-table-box-tr"> 
           <!--     <span>Expire <?php if(isset($date)){ echo date('F Y',$convertDate);}?></span>  -->
                <p title="<?php the_title(); ?>"><?php echo word_limiter(get_the_title(),7);?></p>
               </div>
            </div>
         
         <div class="discount-table-code-td">
            <div class="discount-table-box-tr"> 
            
            <?php if($code) {?> 
                <button type="button" class="btn discount-table-btn-primary"><?php  echo $code;?></button>  
                <?php } ?>
                
            </div>
         </div>
         <div class="discount-table-code-tr">
            <div class="discount-table-box-tr">
               <?php 
               $user = wp_get_current_user();
                        $role = ( array ) $user->roles;
                        if (in_array('administrator', $role))
                        {
               ?>
               <div class="after_click_edit">
                  <span class="discount_edit">
                     <a href="javascript:void(0);" data-id="<?php echo $post_ID;?>" data-type="edit"></a>
                  </span>
                  <span class="discount_delete">
                    <a href="javascript:void(0);" data-id="<?php echo $post_ID;?>"></a>
                  </span>
            </div>
             <?php } ?>

               <a href="<?php echo $link;?>" class="btn " target="_blank"><?php echo $url;?></a> 
            </div>
         </div>
      </li>
   <?php endwhile; ?>
      <?php wp_reset_postdata(); ?>
      <?php else : ?>
            <p><?php esc_html_e( 'Sorry, no deals code were found.' ); ?></p>
<?php endif; ?>
<?php }else{ ?>
 <li class="discount-table-ul-body">
       <p><?php esc_html_e( 'Sorry, no deals code were found.' ); ?></p>
 </li>
<?php } ?>
</ul>
</div>

</div>


<?php  }else{ ?>
  <div class="discount-codes-row"> 

  <p><?php esc_html_e( 'Please login to access the deals!!' ); ?></p>
  </div>
 <?php  } ?>
<script>
jQuery(function($){
         jQuery('.discount_edit >a').click(function(){
         var id    = jQuery(this).attr('data-id');
           var type  = jQuery(this).attr('data-type');
            jQuery.ajax({
               type:"POST",
               url: ajaxurl,
               dataType: "json",
               data: {"action": "update_discount_data", 'id':id },
               success:function(res){
                  console.log(res);
                  if(res.status=="fail"){
                  }else{
                       jQuery('.update_code_discount').val(id);
                       jQuery('.type_code_discount').val(type);
                       jQuery('.edit_dis_code').val(res.dis_code);
                       jQuery('.edit_dis_date').val(res.dis_date);
                       jQuery('.edit_dis_deal').val(res.dis_deal);
                       jQuery('.edit_store_logo').attr('src',res.dis_logo);
                       jQuery('.edit_dis_url').val(res.dis_url);
                       jQuery('#dis_logo').removeAttr("required");
                       jQuery('#popup_add_edit_discount_code .popup').show();
                       jQuery('#popup_add_edit_discount_code .popup_label').text('Update Discount Code').show();
                  }
               }
           });

          return false;
       });

   
    jQuery('.edit_discount_code >a').click(function(){

         jQuery('.after_click_edit').toggle();

    });

});

/* delete post here */
jQuery(function($){
         jQuery('.discount_delete >a').click(function(){
         var id    = jQuery(this).attr('data-id');
       //if(confirm_modal()){
           jQuery.ajax({
               type:"POST",
               url: ajaxurl,
               dataType: "json",
               data: {"action": "delete_discount_data", 'id':id },
               success:function(res){
                  console.log(res);
                  if(res.status=="fail"){
                  }else{
                     jQuery('.dis_hide_'+id).fadeOut('slow');
                     window.location.reload();
                  }
               }
           });
         //}
      });
});          
</script>