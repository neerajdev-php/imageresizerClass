<?php 

/*

	Template Name: Create New Event


*/
get_header(); 

$user = wp_get_current_user();
$role = ( array ) $user->roles;

if (in_array('administrator', $role) || in_array('bbp_keymaster', $role))
 {

    echo do_shortcode('[event_form]');

 }else{

 	echo 'Please login first then you can create a new events';

 }

?>

<?php get_footer();
?>