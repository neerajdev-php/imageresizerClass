<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Astra
 * @since 1.0.0
 */
$filter  =  get_post_meta(get_the_id(),'post_filter',true);
?>

<?php astra_entry_before(); 
//if($filter == 'yes')
//{

?>

<div class="ast-col-lg-4 ast-col-md-6 ast-col-sm-6 ast-col-xs-12 hide_news_<?php the_ID();?>">
<article itemtype="https://schema.org/CreativeWork" itemscope="itemscope" id="post-<?php the_ID(); ?>" <?php post_class('news_article'); ?>>

	<?php astra_entry_top(); ?>

	<?php astra_entry_content_blog(); ?>

	<?php astra_entry_bottom(); ?>

</article><!-- #post-## -->
</div>

<?php //} astra_entry_after(); ?>
