<div id="popup_add_edit_discount_code"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner popup-inner-full">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1 class="popup_label"></h1><br>
				 	<div class="popup_sub_label"></div>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				   		<div class="popup_warnings"></div>

					    <div id="request_join_section" class="discount_join_section">
					         		
                            <form class="discount_add_edit" id="discount_add_edit" method="post">
                            	  <input type="hidden" name="action" value="custom_discount_add_edit">	
                            	  <input type="hidden" name="edit_code" value="" class="update_code_discount"> 
                            	  <input type="hidden" name="edit_type" value="" class="type_code_discount"> 
							  
							     <input type="hidden" name="_discount_nonce" value="<?php echo wp_create_nonce( 'log-discount-nonce' ); ?>">

							      <div class="ast-row">
								      	<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
								      		<div class="popup-form-group">
										  		<label for="full_name">Discount Code</label>
										    	<input type="text" name="dis_code" required="required" class="edit_dis_code" value="">
											</div>
										</div>
										<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
								      		<div class="popup-form-group">
									  			<label for="email">Discount date</label>
									    		<input type="text" name="dis_expire_date" id="datepicker" required="required" class="edit_dis_date" value="">
											</div>
										</div>
									</div>
									<div class="ast-row">
											<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
								      			<div class="popup-form-group">
										  			<label for="message">Discount Deal</label>
										   			<textarea name="des_deal" id="des_deal" rows="1" cols="2" required="required" class="edit_dis_deal" ></textarea>
												</div>
											</div>
											<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
								      		 <div class="popup-form-group">
									  			<label for="message">Website Url</label>
									    		<input type="text" class="edit_dis_url" name="dis_url" id="dis_url" placeholder="http://www.example.com" required>

									    		</div>
											</div>
									</div>
									<div class="ast-row">
										<div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
							      		 <div class="popup-form-group">
								  			<label for="message">Store Logo</label>
								    		<input type="file" name="dis_logo" id="dis_logo" required>
											<img src="" class="edit_store_logo" style="height: 50px;">
											</div>
										 </div>
									</div>
								<div class="popup-form-group-btn">						 	
						  			<input type="submit" name="submit_form" id="submit_form_dis" class="submit_add_edit_discount" value="Send">
						  		</div> 
							</form>
					   
						</div> 
						<div id="dis_new_message_section" class="hide_section popup_site_message">
						 	
						 	  <div class="dis_message popup_success_msg"></div>
						</div>
                    </div>
			 </div>
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>
 <script type="text/javascript">
 	jQuery(function($){
			jQuery('.add_discount_code >a').click(function(){ 
			//jQuery('#request_new_message_section').addClass('hide_section');
 		 	  //jQuery('#popup_add_edit_discount_code').removeClass('hide_section');
			  jQuery('.update_code_discount').val("");
              jQuery('.type_code_discount').val("");
			  jQuery('.edit_dis_code').val("");
              jQuery('.edit_dis_date').val("");
              jQuery('.edit_dis_deal').val("");
              jQuery('.edit_store_logo').attr('src',"");
			  jQuery('#dis_logo').prop('required',true);
			  jQuery('#popup_add_edit_discount_code .popup').show();
 		 	  jQuery('#popup_add_edit_discount_code .popup_label').text('Add New Discount Code').show();
 		 	  //jQuery('#popup_add_edit_discount_code .popup_sub_label').text('Become a part of Tri community!');

			return false;
 		 });

			jQuery('body').on('submit','#discount_add_edit',function(){
			var formData = new FormData(jQuery(this)[0]);
			jQuery.ajax({
 		 	  		type:"POST",
 		 	  		url: ajaxurl,
 		 	  		data:formData,
 		 	  		dataType: "json",
 		 	  		async: false,
					cache: false,
					dataType: "json",
					contentType: false,
					processData: false,
 		 	  		beforeSend:function(){
 		 	  			jQuery('#popup_add_edit_discount_code .popup_warnings').addClass('ast-alert-info').text('Please wait...');
 		 	  		},
 		 	  		success:function(res){
 		 	  			console.log(res);
 		 	  			if(res.status=="fail"){
                           jQuery('#popup_add_edit_discount_code .popup_warnings').removeClass('ast-alert-info').addClass('ast-alert-danger').text(res.message);
 		 	  			}else{
						 	   jQuery('#popup_add_edit_discount_code .popup_warnings').removeClass('ast-alert-info').removeClass('ast-alert-danger').addClass('ast-alert-success').text(res.message);

						 	    jQuery('#discount_add_edit')[0].reset();
								jQuery('#popup_add_edit_discount_code .popup_label').hide(); 		 
				 		 	    jQuery('#popup_add_edit_discount_code .popup_sub_label').hide(); 		  				
 		 	  				    jQuery('#request_new_message_section').removeClass('hide_section');
 		 	  				    jQuery('#request_join_section').addClass('hide_section');
								window.location.reload();
 		 	  			}
 		 	  			
 		 	  		}
 		 	  });
 		 	  return false;
 		 });

 		 /*jQuery('.send_new_btn').click(function(){
				jQuery('#popup_request_join .popup_label').show(); 		 
				jQuery('#popup_request_join .popup_sub_label').show(); 	
 		 	jQuery('#popup_request_join .popup_warnings').removeClass('ast-alert-info').removeClass('ast-alert-danger').removeClass('ast-alert-success').text('');
			jQuery('#request_new_message_section').addClass('hide_section');
			jQuery('#request_join_section').removeClass('hide_section');

 		 });*/
});
 </script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  jQuery( function() {
    jQuery( "#datepicker" ).datepicker();
});
</script>