<div id="popup_map_event"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1>Event Location</h1>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">

				     <?php echo do_shortcode('[locations_map  width="100%"  location="'.$location_id.'"]');?>
				 </div>
			 </div>
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>
<div id="popup_participants"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner">
			<div class="ast-container11">
			 <div class="ast-row"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1>All Participants</h1>
				 </div>
			 </div>
			 <div class="ast-row">				 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				 <ul class="participants_list">				
				 	<?php $participants= get_total_participents_event($event_id); 
				 	if($participants){
				 		foreach ($participants as $key => $value) {				 		
				 			$name= get_user_meta($value->ID,'first_name',true)." ".get_user_meta($value->ID,'last_name',true);				 			
				 		 ?>
				 			<li> <div class="imge_section"><?php echo bp_activity_avatar( array( 'user_id' => $value->ID ) ); ?></div>
				 				 <div class="participant_name"><?php echo $name; ?></div>	
				 			 </li>	
				 	<?php	}
				 	}
				 	?>
					</ul>

				 </div>
			 </div>			 
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>



 <script type="text/javascript">
 	jQuery(function($){
 		 jQuery('.open_map').click(function(){
 		 	 jQuery('#popup_map_event > .popup').show();
            em_maps();
 		 });


 		 jQuery('.open_popup_participants').click(function(){
 		 	 jQuery('#popup_participants > .popup').show();
 		 });


 	})
 </script>