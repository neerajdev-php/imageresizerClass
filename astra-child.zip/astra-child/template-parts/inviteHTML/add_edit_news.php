<div id="popup_add_edit_news_code"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner popup-inner-full">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1 class="popup_label"></h1><br>
				 	<div class="popup_sub_label"></div>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				   		<div class="popup_warnings"></div>

					    <div id="request_join_section" class="news_join_section">
					         		
                            <form class="news_add_edit" id="news_add_edit" method="post">
                            	  <input type="hidden" name="action" value="custom_news_add_edit">	
                            	  <input type="hidden" name="edit_code" value="" class="update_code_news"> 
                            	  <input type="hidden" name="edit_type" value="" class="type_code_news"> 
							  
							     <input type="hidden" name="_news_nonce" value="<?php echo wp_create_nonce( 'log-news-nonce' ); ?>">

							      <div class="ast-row">
								      	<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
								      		<div class="popup-form-group">
										  		<label for="full_name">News Title</label>
										    	<input type="text" name="news_title" required="required" class="edit_news_title" value="">
											</div>
										</div>
										<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
								      		<div class="popup-form-group">
									  			<label for="email">News Category</label>
									  			<select name="news_cate" class="news_cate" required="">
									  				<option value="">Select Category</option>
									  			<?php 
											    $terms = get_terms( 'category', array(
											    	'hide_empty' => false,
												));
												foreach($terms  as $term){
									  			?>
									  			<option value="<?php echo $term->term_id; ?>"><?php echo $term->name; ?></option>
									    		<?php } ?>
									    		</select>
											</div>
										</div>
									</div>
									<div class="ast-row">
											<div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
								      			<div class="popup-form-group">
										  			<label for="message">News Description</label>
										   			<!--<textarea name="news_desc" id="news_desc" rows="3" cols="3" required="required" class="edit_news_desc" ></textarea>-->
										   			<?php wp_editor( $content, 'news_description', $settings = array('name'=> 'news_desc','media_buttons' => true) ); ?>
												</div>
											</div>
											
									</div>
									<div class="ast-row">
										<div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
							      		 <div class="popup-form-group">
								  			<label for="message">Image</label>
								    		<input type="file" name="news_logo" id="news_logo" required>
											<img src="" class="edit_news_logo" style="height: 50px;">
											</div>
										 </div>
									</div>
								<div class="popup-form-group-btn">						 	
						  			<input type="submit" name="submit_form" id="submit_form_news" class="submit_add_edit_discount" value="Save">
						  		</div> 
							</form>
					   
						</div> 
						<div id="news_new_message_section" class="hide_section popup_site_message">
						 	
						 	  <div class="news_message popup_success_msg"></div>
						</div>
                    </div>
			 </div>
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>

