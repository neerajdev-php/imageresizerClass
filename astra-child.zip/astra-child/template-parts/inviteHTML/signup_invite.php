<?php 
     $invitee_name= !empty($_GET['invitee_name']) ? $_GET['invitee_name'] :'';
	 
	 $email= !empty($_GET['email']) ? $_GET['email'] :'';

	 $recipientRole= !empty($_GET['recipientRole']) ? $_GET['recipientRole'] :'';

	 $emailObj = get_term_by( 'name',$email,'ia_invitees');
	 // var_dump($emails);

	// var_dump(BP_Group_Invite_Email::user_has_invites($email));



	$inviterPost = get_posts(array(
		  'post_type' => 'ia_invites',
		  'numberposts' => -1,
		  'tax_query' => array(
				    array(
				            'taxonomy' => 'ia_invitees',
		                     'terms' 	=> $emailObj->slug,
							'field' 	=> 'slug',
							'operator'	=> 'IN'
				    )
		  )
		));
 //var_dump($inviterPost);


  $postObj= $inviterPost[0];

  $is_already_accepted= get_post_meta($postObj->ID,'bp_ia_accepted',true);



  $inviter_id= $postObj->post_author;
  $authorObj= get_userdata($inviter_id);
  $inviter_post_id= $postObj->ID;
  $terms = wp_get_post_terms( $inviter_post_id, 'ia_invited_groups' );
  $groupTermObj= $terms[0];
  $groupId= $groupTermObj->name;

  $closeClass= !empty($is_already_accepted) ? 'closeAl' :'';


 ?>

<div id="popup_signup_invite"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner popup-inner-full">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
			 <!-- If invitaion exist  -->
			  <?php if($is_already_accepted==""){ ?>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1 class="popup_label">Welcome to Team RWB!</h1>
				 	<div class="popup_sub_label">You've been invited to join community by the following user: <?php echo $authorObj->display_name; ?></div>
				 	<div class="popup_sub_long_data">
						Joining our community is easy. Just fill in the fields below, and we'll get a new account 
						set up for you in no time. You might also need to verify your email address after 
						submitting the form below.
                     </div>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				   		<div class="popup_warnings"></div>

					    <div id="invite_signup_frm_section">			
						   <form class="invite_signup_frn" id="invite_signup_frn" method="post">
						   <div class="ast-row"> 
							    <div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
									       <div class="popup-form-group">
									  		<label for="username">Full Name</label>
									  		<input type="text" name="fullname" id="fullname" value="<?php echo $invitee_name; ?>">
									  		<span id="err_fullname" class="err_box"></span>
									  		</div>
							  		</div>
                                <div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
								  	    <div class="popup-form-group">
								  		<label for="password">Password</label>
									   	<div class="ast-input-group ast-input-group-right">					  		   
									  			<input type="password" name="password" id="password">
									  			<span class="ast-input-group-addon"><i class="ast-icon-info"></i></span>
									  		 	<span id="err_pass" class="err_box"></span>
									  		</div> 
									  	
						  		       </div>
						          </div>

						  </div>
						   <div class="ast-row"> 
							    <div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
								  	    <div class="popup-form-group">
									  		<label for="username">Username</label>
									  		<input type="text" name="username" id="username">
									  		<span id="err_username" class="err_box"></span>
									  	</div>	
							  		</div>
                                <div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
								  	    <div class="popup-form-group">
								  		 <label for="cpassword">Confirm Password</label>
								  		 <input type="password" name="cpassword" id="cpassword">
								  		 <span id="err_repass" class="err_box"></span>
								  		</div>
						          </div>
						  </div>
						  <div class="ast-row"> 
							    <div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
								       <div class="popup-form-group">								          
								  		  <label for="email">E-mail</label>
		                                 <div class="ast-input-group">
								  		   <span class="ast-input-group-addon">@</span>
								  		   <input type="email" name="email" id="email" value="<?php echo $email; ?>">
								  		    <span id="err_email" class="err_box"></span>
								  		 </div> 
								  		 
								  		</div>
							  	</div>
                                <div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12"> 
									   <div class="popup-form-group">
									   <label for="">&nbsp;</label>
			                                <input type="hidden" name="action" value="custom_signup_invite">	 	
			                                <input type="hidden" name="_signup_nonce_added" value="<?php echo wp_create_nonce( '_signup-auth-nonce-added' ); ?>">
			                                <input type="hidden" name="groupId" value="<?php echo $groupId; ?>">
			                                <input type="hidden" name="inviter_id" value="<?php echo $inviter_id; ?>">
			                                <input type="hidden" name="recipientRole" value="<?php echo $recipientRole; ?>">
			                            <input type="hidden" name="inviter_post_id" value="<?php echo $inviter_post_id; ?>">

									  		 <input type="submit" name="submit_register" id="submit_register" value="Sign up">
									  	</div> 
						          </div>
						  </div>	  

						 </form>	
						</div> 
						 <div id="forget_message_section" class="hide_section popup_site_message">
						 	  <img src="<?php echo get_stylesheet_directory_uri() ?>/images/login-key-icon.png" class="forget_message_img">
						 	  <div class="reset_message popup_success_msg">You have successfully registered!</div>

						 	 <div class="login_section"><a href="javascript:void();" data-popup-close="popup-1" class="popup_close">Close</a></div> 
						 </div>

				 </div>
				 <?php }else{ ?>
				
						<div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
						 	<h1 class="popup_label">Welcome to Team RWB!</h1>
						 	<div class="popup_sub_label">You already accepted the invitation!</div>						
						 </div>
				<?php } ?>
				<!-- If invitaion exist  -->


			 </div>
		 </div>
        <a class="popup-close popup_close_invite" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>

 <script type="text/javascript">
 	jQuery(function($){	
 function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi,    
    function(m,key,value) {
      vars[key] = value;
    });
    return vars;
  }
  paramsObj= getUrlVars();
		if((paramsObj.action=='accept-invitation') && (paramsObj.email!=undefined && paramsObj.email!='') && (paramsObj.invitee_name!=undefined && paramsObj.invitee_name!='')){

				jQuery('#popup_signup_invite > .popup').show();


				jQuery('.popup_close_invite').click(function(){
					console.log('ssss');
			          window.location=rwbObj.site_url;
				 	 /* jQuery('.popup').hide();
				 	  window.reload();*/
				 });

		 }
 		 jQuery('body').on('submit','#invite_signup_frn',function(){
 		 	jQuery('#popup_signup_invite .popup_warnings').text('');
 		 	jQuery('.err_box').removeClass('err_msg').text('');
 		 	  var formData= jQuery(this).serialize();
 		 	  jQuery.ajax({
 		 	  		type:"POST",
 		 	  		url: ajaxurl,
 		 	  		data:formData,
 		 	  		dataType: "json",
 		 	  		beforeSend:function(){
 		 	  			jQuery('#popup_signup_invite .popup_warnings').addClass('ast-alert-info').text('Please wait...');
 		 	  		},
 		 	  		success:function(res){
 		 	  			console.log(res);
 		 	  			if(res.status=="fail"){
                           jQuery('#popup_signup_invite .popup_warnings').removeClass('ast-alert-info').addClass('ast-alert-danger').text(res.message);

                           		jQuery.each(res.err,function(index,val){
                           			console.log("IUndex:"+index+'V:'+val);
                           			var er_id='err_'+index;
                           			jQuery('#'+er_id).addClass('err_msg').text(val);
                           		});


 		 	  			}else{
 		 	  				jQuery('#popup_signup_invite .popup_warnings').removeClass('ast-alert-danger').addClass('ast-alert-success').text('Redirecting to account..');

 		 	  				setTimeout(function(){
 		 	  					window.location=res.url;
 		 	  				},400);
 		 	  			}
 		 	  			
 		 	  		}
 		 	  });
 		 	  return false;
 		 });




 	});
 </script>