<div id="popup_create_gallery"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1 class="popup_label">New Album</h1>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				    <div id="create_gallery_section">
						<div id="mpp-gallery-create-form-wrapper" class="mpp-container">

							<?php if ( mpp_user_can_create_gallery( mpp_get_current_component(), mpp_get_current_component_id() ) ) : ?>

								<form method="post" action="" id="mpp-gallery-create-form" class="mpp-form mpp-form-stacked mpp-gallery-create-form">
									<?php
									$title  = $description = $type = '';
									$status = mpp_get_default_status();
	
									if ( ! empty( $_POST['mpp-gallery-title'] ) ) {
										$title = $_POST['mpp-gallery-title'];
									}

									if ( ! empty( $_POST['mpp-gallery-description'] ) ) {
										$description = $_POST['mpp-gallery-description'];
									}

									if ( ! empty( $_POST['mpp-gallery-status'] ) ) {
										$status = $_POST['mpp-gallery-status'];
									}

									if ( ! empty( $_POST['mpp-gallery-type'] ) ) {
										$type = $_POST['mpp-gallery-type'];
									}


									$status1  = get_option('mpp-settings');

									?>
									<?php do_action( 'mpp_before_create_gallery_form' ); ?>
									<div class="mpp-g mpp-form-wrap">
										<div class="mpp-u-1-1 mpp-before-create-gallery-form-fields">
											<?php // use this hook to add anything at the top of the gallery create form.  ?>
											<?php do_action( 'mpp_before_create_gallery_form_fields' ); ?>
										</div>

										<div class="mpp-u-1-2 mpp-editable-gallery-type" style="display: none;">
											<label for="mpp-gallery-type"><?php _e( 'Type', 'mediapress' ); ?></label>
											<?php mpp_type_dd( array( 'selected' => $type, 'component' => mpp_get_current_component() ) ) ?>
										</div>

										
										<div class="popup-form-group">
											<label for="mpp-gallery-title"><?php _e( 'Title:', 'mediapress' ); ?></label>
											<input id="mpp-gallery-title" type="text" value="<?php echo esc_attr( $title ) ?>" class="mpp-input-1" name="mpp-gallery-title" required='required' />
										</div>



										<div class="popup-form-group">
											<label for="mpp-gallery-status"><?php _e( 'Status:', 'mediapress' ); ?></label>
											<select name="mpp-gallery-status" required='required'>
											<?php if(count($status1['active_statuses']) > 0){
													echo '<option value="">Select Status</option>';
													foreach ($status1['active_statuses'] as $key => $value) {

														if($key == 'groupsonly'){ continue;}
													?>
													<option value="<?php echo $key;?>"> <?php echo ucfirst($value);?></option>
													<?php
													}
												}else{

													echo '<option>No Data</option>'; 
												}?>
											</select>
										</div>


										<div class="mpp-u-1-1 mpp-editable-gallery-description" style="display: none;">
											<label for="mpp-gallery-description"><?php _e( 'Description', 'mediapress' ); ?></label>
											<textarea id="mpp-gallery-description" name="mpp-gallery-description" rows="3" class="mpp-input-1"><?php echo esc_textarea( $description ); ?></textarea>
										</div>

										<div class="mpp-u-1-1 mpp-after-create-gallery-form-fields">
											<?php // use this hook to add any extra data here for settings or other things at the bottom of create gallery form. ?>
											<?php do_action( 'mpp_after_create_gallery_form_fields' ); ?>

										</div>

										<?php do_action( 'mpp_before_create_gallery_form_submit_field' ); ?>
										<?php
										// do not delete this line, we need it to validate.
										wp_nonce_field( 'mpp-create-gallery', 'mpp-nonce' );
										// also do not delete the next line <input type='hidde' name='mpp-action' value='create-gallery' >
										?>

										<input type='hidden' name="mpp-action" value='create-gallery'/>

										<div class=" popup-form-group">
											<!-- <button type="submit" id="submit_login" class='mpp-align-right mpp-button-primary mpp-create-gallery-button '> <?php _e( 'Create', 'mediapress' ); ?></button> -->
											<input type="submit" type="submit" id="submit_login" class='mpp-align-right mpp-button-primary mpp-create-gallery-button ' value="<?php _e( 'Create', 'mediapress' ); ?>">
										</div>

									</div><!-- end of .mpp-g -->

									<?php do_action( 'mpp_after_create_gallery_form' ); ?>
								</form>

							<?php else: ?>
								<div class='mpp-notice mpp-unauthorized-access'>
									<p><?php _e( 'Unauthorized access!', 'mediapress' ); ?></p>
								</div>
							<?php endif; ?>
						</div><!-- end of mpp-container -->

		       	      </div>
					 <div id="upload_gallery_message" class="hide_section popup_site_message">
						 	  <img src="<?php echo get_stylesheet_directory_uri() ?>/images/uploaded-icon.png" class="forget_message_img">
						 <div class="reset_message popup_success_msg">Your photos has been uploaded successfully!</div>
				     </div>


				 </div>
			 </div>
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>
 <script type="text/javascript">
 	jQuery(function($){
		function parseURL(url) {
		    var parser = document.createElement('a'),
		        searchObject = {},
		        queries, split, i;
		    // Let the browser do the work
		    parser.href = url;
		    // Convert query string to object
		    queries = parser.search.replace(/^\?/, '').split('&');
		    for( i = 0; i < queries.length; i++ ) {
		        split = queries[i].split('=');
		        searchObject[split[0]] = split[1];
		    }
		    return {
		        protocol: parser.protocol,
		        host: parser.host,
		        hostname: parser.hostname,
		        port: parser.port,
		        pathname: parser.pathname,
		        search: parser.search,
		        searchObject: searchObject,
		        hash: parser.hash
		    };
		}

 		 jQuery('#subnav #create-personal-li #create').click(function(){
 		 	 jQuery('#popup_create_gallery > .popup').show();
 		 	return false;
 		 });


 	})

 </script>