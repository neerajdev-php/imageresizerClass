<?php
$gallery = mpp_get_current_gallery();
/*pr($gallery);*/

?>
<div id="popup_gallery_upload"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1 class="popup_label">Upload Photos</h1>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				    <div id="upload_gallery_section" class="" >				   		
							   		<!-- append uploaded media here -->
									<div id="mpp-uploaded-media-list-gallery" class="mpp-uploading-media-list">
										<ul>
										</ul>
									</div>
									<?php do_action( 'mpp_after_gallery_upload_medialist' ); ?>
									<!-- drop files here for uploading -->
									<?php $context='gallery'; ?>
								  <div id="mpp-upload-dropzone-<?php echo $context; ?>" class="mpp-dropzone">
								        <div class="mpp-drag-drop-inside">
								            <p class="mpp-drag-drop-info"><?php _e( 'Drop files here', 'mediapress' ); ?></p>
								            
								        </div>
								    </div>
								   <p class="mpp-drag-drop-buttons">							
								                 <input id="mpp-upload-media-button-<?php echo $context; ?>" type="button" class="button mpp-button-select-files" value="<?php _e( 'Or Select files', 'mediapress' ); ?>"/>
								            <p class="mpp-uploader-allowed-file-type-info"></p>
								            <?php if ( mpp_get_option('show_max_upload_file_size' ) ) : ?>
								                <p class="mpp-uploader-allowed-max-file-size-info"></p>
								            <?php endif; ?>
								            </p>
									<?php wp_nonce_field( 'mpp-manage-gallery', '_mpp_manage_gallery_nonce' ); ?>
									<?php do_action( 'mpp_after_gallery_upload_dropzone' ); ?>
									<!-- show any feedback here -->
									<div id="mpp-upload-feedback-gallery" class="mpp-feedback">
										<ul></ul>
									</div>
					       	      <?php// mpp_upload_dropzone( 'gallery' ); ?>
					       	      <input type="hidden" name="mpp-context" id="mpp-context" value="gallery">				  
					              <input type="hidden" name="gallery-id" id="gallery-id" value="<?php echo $gallery->id; ?>">  
					       	      <input type="hidden" name="mpp-upload-gallery-id" id="mpp-upload-gallery-id" value="<?php echo $gallery->id; ?>">
		       	      </div>

					 <div id="upload_gallery_message" class="hide_section popup_site_message">
						 	  <img src="<?php echo get_stylesheet_directory_uri() ?>/images/uploaded-icon.png" class="forget_message_img">
						 <div class="reset_message popup_success_msg">Your photos has been uploaded successfully!</div>
				     </div>


				 </div>
			 </div>
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#" id="refresh_album_data">x</a>
        </div>
 </div>
 </div>
 <script type="text/javascript">
 	jQuery(function($){
		function parseURL(url) {
		    var parser = document.createElement('a'),
		        searchObject = {},
		        queries, split, i;
		    // Let the browser do the work
		    parser.href = url;
		    // Convert query string to object
		    queries = parser.search.replace(/^\?/, '').split('&');
		    for( i = 0; i < queries.length; i++ ) {
		        split = queries[i].split('=');
		        searchObject[split[0]] = split[1];
		    }
		    return {
		        protocol: parser.protocol,
		        host: parser.host,
		        hostname: parser.hostname,
		        port: parser.port,
		        pathname: parser.pathname,
		        search: parser.search,
		        searchObject: searchObject,
		        hash: parser.hash
		    };
		}

 		 jQuery('.single_gl_over .gl_actns > ul > li > a:first').click(function(){
 		 	 jQuery('#popup_gallery_upload .popup_label').text('Upload Photos').show();
 		 	    jQuery('#upload_gallery_section').removeClass('hide_section');
        	   jQuery('#upload_gallery_message').addClass('hide_section');
 		 	 jQuery('#popup_gallery_upload > .popup').show();
 		 	 var url1= jQuery(this).attr('href');
 		 	 var parseURL1= parseURL(url1);

 		 	 var gallery_id= parseURL1.searchObject.gallery_id;

 		 /*     jQuery("input[name='_wp_http_referer']").val(url1);
            // jQuery("#gallery-id").val(gallery_id);
         jQuery("#mpp-upload-gallery-id").val(gallery_id);*/


 

 		 	 	//console.log(parseURL1);

 		 	 return false;
 		 });


 	})
jQuery('#refresh_album_data').click(function(){

  location.reload();   

});
 </script>