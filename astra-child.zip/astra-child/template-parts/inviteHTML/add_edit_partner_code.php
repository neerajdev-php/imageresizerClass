<div id="popup_add_edit_partner"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner popup-inner-full">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1 class="popup_label"></h1><br>
				 	
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				   		<div class="popup_warnings"></div>

					    <div id="request_join_section" class="partner_join_section">
					         		
                            	 <form class="partner_add_edit" id="partner_add_edit" method="post">
                            	  <input type="hidden" name="action" value="custom_partner_add_edit">	
                            	  <input type="hidden" name="edit_part_id" value="" class="update_code_partner"> 
                            	  <input type="hidden" name="edit_type" value="" class="type_partner"> 
							  
							     <input type="hidden" name="_partner_nonce" value="<?php echo wp_create_nonce( 'log-partner-nonce' ); ?>">	



							     <div class="ast-row">
							     	
							     	<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
							     		

							     		 <div class="popup-form-group">
								           <label for="full_name">Sponsors Name</label>
								    	   <input type="text" name="part_name" required="required" class="edit_part_name" value="">
								        </div>


							     	</div>


							     	<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
							     		

							     		 <div class="popup-form-group">
										  <label for="email">Website</label>
										    <input type="text" name="partner_website" required="required" class="partner_website" value="" placeholder="http://www.example.com">
								        </div>

							     		
							     	</div>


							     </div>

							      <div class="ast-row">
							      	
							      	<div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
							      		
							      		 <div class="popup-form-group">
										  <label for="message">Description</label>

										  <!-- <textarea name="des_partner" id="des_partner" rows="3" cols="2" required="required" class="edit_partner_desc" ></textarea>-->

                      <?php wp_editor( 'Please add some text...', 'des_partner', $settings = array('name'=> 'des_partner','media_buttons' => false) ); ?>

								       </div>

							      	</div>

							      </div>



							      <div class="ast-row">
							      	
							      	<div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
							      		
							      		<div class="popup-form-group">
											  <label for="message">Logo</label>
											    <input type="file" name="partner_logo" id="partner_logo" required>

											    <img src="" class="edit_partner_logo" style="height: 50px;">
										</div>
								 		<div class="popup-form-group-btn">						 	
						  				<input type="submit" name="submit_form_partner" id="submit_form_partner" class="submit_add_edit_partner" value="Save">
						  				</div> 
							      	</div>
								
								</div>
								
								
								
						        

						  	</form>
					   
						</div> 
						<div id="partner_new_message_section" class="hide_section popup_site_message">
						 	
						 	  <div class="partner_message popup_success_msg"></div>
						</div>
                    </div>
			 </div>
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>
<script type="text/javascript">

  jQuery(function($){
    function tmce_setContent(content, editor_id, textarea_id) {
      if ( typeof editor_id == 'undefined' ) editor_id = wpActiveEditor;
      if ( typeof textarea_id == 'undefined' ) textarea_id = editor_id;
      
      if ( jQuery('#wp-'+editor_id+'-wrap').hasClass('tmce-active') && tinyMCE.get(editor_id) ) {
        return tinyMCE.get(editor_id).setContent(content);
      }else{
        return jQuery('#'+textarea_id).val(content);
      }
    }



      jQuery('.add_new_partner').click(function(){ 
          tmce_setContent('','des_partner','des_partner');
        jQuery('.update_code_partner').val("");
        jQuery('.type_partner').val("");
        jQuery('.edit_part_name').val("");
        jQuery('.edit_partner_desc').val("");
        jQuery('.edit_partner_logo').attr('src',"");
        jQuery('.partner_website').val("");
        jQuery('#partner_logo').prop('required',true);
        jQuery('#popup_add_edit_partner .popup').show();
        jQuery('#popup_add_edit_partner .popup_label').text('Add New').show();
       

      return false;
     });

      jQuery('body').on('submit','#partner_add_edit',function(){
      var formData = new FormData(jQuery(this)[0]);
      jQuery.ajax({
            type:"POST",
            url: ajaxurl,
            data:formData,
            dataType: "json",
            async: false,
          cache: false,
          dataType: "json",
          contentType: false,
          processData: false,
            beforeSend:function(){
              jQuery('#popup_add_edit_partner .popup_warnings').addClass('ast-alert-info').text('Please wait...');
            },
            success:function(res){
              console.log(res);
              if(res.status=="fail"){
                           jQuery('#popup_add_edit_partner .popup_warnings').removeClass('ast-alert-info').addClass('ast-alert-danger').text(res.message);
              }else{
                 jQuery('#popup_add_edit_partner .popup_warnings').removeClass('ast-alert-info').removeClass('ast-alert-danger').addClass('ast-alert-success').text(res.message);

                  jQuery('#partner_add_edit')[0].reset();
                jQuery('#popup_add_edit_partner .popup_label').hide();     
                  jQuery('#popup_add_edit_partner .popup_sub_label').hide();              
                    jQuery('#partner_new_message_section').removeClass('hide_section');
                    jQuery('.partner_join_section').addClass('hide_section');
                window.location.reload();
              }
              
            }
        });
        return false;
     });

  
    jQuery('.edit_partner_code >a').click(function(){

         jQuery('.after_click_edit_partner').toggle();

    });




    /* edit partner code here */

     jQuery('.partner_edit >a').click(function(){

           var id    = jQuery(this).attr('data-id');
           var type  = jQuery(this).attr('data-type');
            jQuery.ajax({
               type:"POST",
               url: ajaxurl,
               dataType: "json",
               data: {"action": "update_partner_data", 'id':id },
               success:function(res){
                  console.log(res.par_desc);
                  if(res.status=="fail"){
                  }else{
                       jQuery('.update_code_partner').val(id);
                       jQuery('.type_partner').val(type);
                       jQuery('.edit_part_name').val(res.par_name);
                       jQuery('.partner_website').val(res.par_web);
                        jQuery('#des_partner').val(res.par_desc);
                       //var activeEditorSponsors= tinyMCE.get('des_partner');                      
                      // activeEditorSponsors.setContent(res.par_desc);
                        tmce_setContent(res.par_desc,'des_partner','des_partner');
                       jQuery('.edit_partner_logo').attr('src',res.par_logo);
                       jQuery('#partner_logo').removeAttr("required");
                       jQuery('#popup_add_edit_partner .popup').show();
                       jQuery('#popup_add_edit_partner .popup_label').text('Update Partner').show();
                  }
               }
           });

          return false;
       });

});

  /* delete post here */
jQuery(function($){
         jQuery('.partner_delete >a').click(function(){
         var id    = jQuery(this).attr('data-id');

      //if(confirm_modal()){

           jQuery.ajax({
               type:"POST",
               url: ajaxurl,
               dataType: "json",
               data: {"action": "delete_partner_data", 'id':id },
               success:function(res){
                  console.log(res);
                  if(res.status=="fail"){
                  }else{
                     jQuery('.partnert_hide_'+id).fadeOut('slow');
                     window.location.reload();
                  }
               }
           });
        //}


      });
});     
</script>
