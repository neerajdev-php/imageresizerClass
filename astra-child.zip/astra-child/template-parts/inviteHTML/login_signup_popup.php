<div id="popup_login"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1 class="popup_label">Login</h1>
				 	<div class="popup_sub_label"></div>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				   		<div class="popup_warnings"></div>

					    <div id="login_frm_section">			
						  <form class="login_frm" id="login_frm" method="post">
						       <div class="popup-form-group">
						  		<label for="username">Username or E-mail</label>
						  		<input type="text" name="username" id="username">
						  		</div>
						  		<div class="popup-form-group">
						  		<label for="password">Password</label>
						  		<input type="password" name="password" id="password">
						  		</div>
						  	<div class="popup-form-group">	
						  		<div class="g-recaptcha" data-sitekey="6LeWIkEUAAAAAEGI-L-tHFg3KOCmSFD4N8dl3veR"></div>
						   </div>
						   <div class="popup-form-group">
                             <input type="hidden" name="action" value="custom_auth_login">	 	
                             <input type="hidden" name="_login_nonce" value="<?php echo wp_create_nonce( 'log-auth-nonce' ); ?>">	 	
						  		<input type="submit" name="submit_login" id="submit_login" value="Login">
						  	</div> 
							<div class="social_login">
						  		<p>Social connect:</p>
						  		<div class="login_social_button"><?php echo do_shortcode('[apsl-login-lite]'); ?></div>
							</div>
						</form>
						<div class="forget_pass"><a href="javascript:void();" class="forget_pass_btn" data-section="#forget_frm_section">Forgot your password?</a></div>  
						</div> 
						 <div id="forget_frm_section" class="hide_section">
						 <div class="sub_title">Enter your e-mail below to receive your pasword reset instructions.</div>
						  <form class="forget_frm" id="forget_frm" method="post">
						  
						   <input type="hidden" name="action" value="custom_reset_password">	 
						   <input type="hidden" name="_reset_nonce" value="<?php echo wp_create_nonce( 'log-reset-nonce' ); ?>">	
						  
						  <div class="popup-form-group">
						        <label for="email">E-mail</label>
						  		<input type="email" name="email" id="email">
						  </div>
						  	<div class="popup-form-group">	
						  		<div class="g-recaptcha" data-sitekey="6LeWIkEUAAAAAEGI-L-tHFg3KOCmSFD4N8dl3veR"></div>
						   </div>

						  <div class="popup-form-group">

						      <div class="login_section_back"><a href="javascript:void();" class="login_pass_btn" data-section="#login_frm_section"><i class="go_back"></i> Go back</a></div>		
						  		<input type="submit" name="submit_forget" id="submit_forget" class="send_password_btn" value="Send Password">
						  	</div>
						  </form>
							
						   
						 </div>	
						 <div id="forget_message_section" class="hide_section popup_site_message">
						 	  <img src="<?php echo get_stylesheet_directory_uri() ?>/images/login-key-icon.png" class="forget_message_img">
						 	  <div class="reset_message popup_success_msg">The recovery instructions were sent to your e-mail address! </div>

						 	 <div class="login_section"><a href="javascript:void();" data-popup-close="popup-1" class="popup_close">Close</a></div> 
						 </div>

				 </div>
			 </div>
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>
<div id="popup_signup"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner">
			<div class="ast-container11">
			 <div class="ast-row"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1>Sign Up</h1>
				 </div>
			 </div>
			 <div class="ast-row">				 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				 <ul class="participants_list">				
				 	<?php $participants= get_total_participents_event($event_id); 
				 	if($participants){
				 		foreach ($participants as $key => $value) {				 		
				 			$name= get_user_meta($value->ID,'first_name',true)." ".get_user_meta($value->ID,'last_name',true);				 			
				 		 ?>
				 			<li> <div class="imge_section"><?php echo bp_activity_avatar( array( 'user_id' => $value->ID ) ); ?></div>
				 				 <div class="participant_name"><?php echo $name; ?></div>	
				 			 </li>	
				 	<?php	}
				 	}
				 	?>
					</ul>

				 </div>
			 </div>			 
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>
