<div id="popup_add_friend_share"> 
	<div class="popup" data-popup="popup-1">
    	<div class="popup-inner">
			<div class="ast-container11">
			 	<div class="ast-row invite_main_form"> 
					<div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 		<h1 class="popup_label"></h1><br>
				 		<div class="popup_sub_label"></div>
				 	</div>
				 	<div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
						<div class="popup_warnings"></div>
					    <div id="add_share_section" class="add_share_section">
					        <form class="add_share" id="add_share" method="post">
                            	<input type="hidden" name="action" value="custom_share_post_activity">	
                            	<input type="hidden" name="userid1" id="userid1" value="">
                            	<input type="hidden" name="pId" id="shareId" value="">
                            	<input type="hidden" name="" id="return_activity_id" value="">
								<div class="popup-form-group">
									<label for="full_name">Friend Name <span>( Full name or Username )</span></label>
								    <input type="text" name="uname" id="search-box1" class="add_friend1_uname" value="">
								    <div class="alert-empty" style="display: none;"></div>
								</div>
								 
								<div class="popup-form-group-btn">						 	
						  			<input type="submit" name="submit_form" id="submit_form_friends" class="submit_add_edit_discount" value="Share Post">
						  		</div> 
						  		<div class="error_alredy"></div>
						  		<div class="sucess_asdded"></div>
						  	</form>
						</div> 
						<div id="dis_new_message_section" class="hide_section popup_site_message">
							<div class="dis_message popup_success_msg"></div>
						</div>
                	</div>
				</div>
			</div>
        	<a class="popup-close" data-popup-close="popup-1" href="#">x</a>
    	</div>
	</div>
</div>