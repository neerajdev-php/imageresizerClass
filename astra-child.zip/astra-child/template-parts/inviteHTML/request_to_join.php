<div id="popup_request_join"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1 class="popup_label"></h1>
				 	<div class="popup_sub_label"></div>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				   		<div class="popup_warnings"></div>

					    <div id="request_join_section">
					         <div class="sub_title">Submit your details below to request an invitation.</div>			
                            	 <form class="request_frm" id="request_frm" method="post">
                            	  <input type="hidden" name="action" value="custom_request_now">	 
							  
							     <input type="hidden" name="_reset_nonce" value="<?php echo wp_create_nonce( 'log-request-nonce' ); ?>">	
								 <div class="popup-form-group">
								  <label for="full_name">Full Name</label>
								    <input type="text" name="full_name">
								</div>
								 <div class="popup-form-group">
								  <label for="email">E-mail</label>
								    <input type="email" name="email">
								</div>
								 <div class="popup-form-group">
								  <label for="message">Your Message</label>
								    <textarea name="message" id="message" rows="1" cols="2"></textarea>
								</div>
								<div class="popup-form-group">
									<div data-sitekey="6LeWIkEUAAAAAEGI-L-tHFg3KOCmSFD4N8dl3veR" class="g-recaptcha"></div>
							   </div>
						     <div class="popup-form-group-btn">						 	
						  		<input type="submit" name="submit_form" id="submit_form" class="submit_request" value="Send">
						  	</div>   
						  	</form>
					   
						</div> 
						 <div id="request_new_message_section" class="hide_section popup_site_message">
						 	  <img src="<?php echo get_stylesheet_directory_uri() ?>/images/open_envelope_icon.png" class="forget_message_img">
						 	  <div class="reset_message popup_success_msg">Your request was sent successfully!
Keep an eye on your inbox :)</div>

						 	 <div class="forget_pass"><a href="javascript:void();" data-popup-close="popup-1" class="popup_close forget_pass_btn">Close</a></div> 
						 </div>

				 </div>
			 </div>
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>
 <script type="text/javascript">
 	jQuery(function($){
 		 jQuery('.bp-request-join >.request_join_me').click(function(){ 

 		 	  jQuery('#request_new_message_section').addClass('hide_section');
 		 	  jQuery('#request_join_section').removeClass('hide_section');
 		 	  jQuery('#popup_request_join .popup').show();
 		 	  jQuery('#popup_request_join .popup_label').text('Request to join!').show();
 		 	  jQuery('#popup_request_join .popup_sub_label').text('Become a part of Tri community!');
             return false;
 		 });



 		 	jQuery('body').on('submit','#request_frm',function(){

 		 	  var formData= jQuery(this).serialize();
 		 	  jQuery.ajax({
 		 	  		type:"POST",
 		 	  		url: ajaxurl,
 		 	  		data:formData,
 		 	  		dataType: "json",
 		 	  		beforeSend:function(){
 		 	  			jQuery('#popup_request_join .popup_warnings').addClass('ast-alert-info').text('Please wait...');
 		 	  		},
 		 	  		success:function(res){
 		 	  			console.log(res);
 		 	  			if(res.status=="fail"){
                           jQuery('#popup_request_join .popup_warnings').removeClass('ast-alert-info').addClass('ast-alert-danger').text(res.message);
 		 	  			}else{
						 	   jQuery('#popup_request_join .popup_warnings').removeClass('ast-alert-info').removeClass('ast-alert-danger').removeClass('ast-alert-success').text('');
				 		 	   jQuery('#popup_request_join .popup_label').hide(); 		 
				 		 	   jQuery('#popup_request_join .popup_sub_label').hide(); 		  				
 		 	  				 jQuery('#request_new_message_section').removeClass('hide_section');
 		 	  				 jQuery('#request_join_section').addClass('hide_section');
 		 	  			}
 		 	  			
 		 	  		}
 		 	  });
 		 	  return false;
 		 });

 		 jQuery('.send_new_btn').click(function(){
				jQuery('#popup_request_join .popup_label').show(); 		 
				jQuery('#popup_request_join .popup_sub_label').show(); 	
 		 	jQuery('#popup_request_join .popup_warnings').removeClass('ast-alert-info').removeClass('ast-alert-danger').removeClass('ast-alert-success').text('');
			jQuery('#request_new_message_section').addClass('hide_section');
			jQuery('#request_join_section').removeClass('hide_section');

 		 });


 	});
 </script>