<div id="popup_map_contact"> 
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1>Location</h1>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">

				     <?php echo do_shortcode('[wpgmza id="1"]');?>
				 </div>
			 </div>
		 </div>
        <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>



 <script type="text/javascript">
 	jQuery(function($){
 		 jQuery('.open_map_contact').click(function(){
 		 	 jQuery('#popup_map_contact > .popup').show();
              //jQuery( "#wpgmza_map").trigger( 'wpgooglemaps_loaded' );
              InitMap();
 		 });



 	})
 </script>