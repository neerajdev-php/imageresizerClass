<div id="invite_sent_popup">
 <div class="popup" data-popup="popup-1">
    <div class="popup-inner">
			<div class="ast-container11">
			 <div class="ast-row invite_main_form"> 
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 hide_heading">
				 	<h1>Invite to Excel Multisport</h1>
				 </div>
				 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12">
				    <div class="form_element">
				    	<div class="alert_message"></div>
						 <form id="invite_mail" method="post">
						 <div class="form_ele_group">
						     <label for="recipient_name">Recipient's Name</label>
                             <input type="text" name="recipient_name" id="recipient_name" required="required" data-id="1" onclick="remove_error();" class="custom_remove_error"> 
                           </div>  

                       <div class="form_ele_group">
                             <label for="email">Recipient's E-mail Address</label>
						 	 <input type="email" name="email" id="email" required="required" data-id="1" onclick="remove_error();" class="custom_remove_error">
						</div>  	
						<?php 
						     global $bp;
			                 $vgroups = $groups = BP_Groups_Group::get(array(
			                    'type'=>'alphabetical',
			                    ));
							
							if ( count($vgroups['groups']) > 0 ) { ?>
							<div class="form_ele_group">
						 	<label for="invite_anyone_groups">Invite to Chapter</label>
						 	<select name='invite_anyone_groups' id="invite_anyone_groups" required="required" class="remove_other_val">
						 		<option value="">Select Chapter</option>
						 		<?php  foreach ($vgroups['groups'] as $key => $value) { ?>
						 			<option value="<?php echo $value->id; ?>" ><?php echo $value->name; ?></option>
						 	    <?php } ?>
						 	</select>
						 	</div>
							<?php }else{ ?>
							<div class="widget-error"><?php _e( 'No current groups.', 'my-groups-widget' ); ?></div>
							<?php } ?>
							<div class="form_ele_group">
						 	<label for="user_role">User Role</label>
						 	<select name='user_role' id="user_role" required="required" onchange="remove_required_chapter(this);">
						 		<option value="">Select Role</option>
						 		<option value="bbp_keymaster">Administrator</option>
						 		<option value="bbp_moderator">Chapter Head</option>
						 		<option value="bbp_participant">Member</option>
						 	</select>	
						 	</div>
						 	<div class="form_ele_group_btn">
						 	<input type="submit" name="invite_send" id="invite_send" value="Send Invite" class="disable_button">
						 	</div>

						 	</form>

						 </div>	

						 <div class="ast-col-lg-12 ast-col-md-12 ast-col-sm-12 ast-col-xs-12 after_message">
					 	  	
					 	  	 <div class="invite_error"></div>
					 	  	 <div class="invite_sucess"></div>

					 	  	 <div class="image_loader"><img src="<?php echo get_stylesheet_directory_uri();?>/images/common-loader.gif" style="display: none;height: 50px;"></div>

					 	   </div>	 
				 </div>
			 </div>
             <div class="ast-row11 sent_invite_form" style="display: none;">
             			 <div class="invite_sucess">
             			 	 <div class="invite_sucess_icon"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/invite_sucess_icon.png" class="img_responsive"></div>
             			 	  <span> Your Invitaion has been sent successfully!</span>
             			 </div>


             			<div class="form_ele_group_btn">
						 	<button class="disable_button send_new_one">Send a new one</button>
						</div>

             </div> 

		 </div>
        <a class="popup-close closed_invite_popup" data-popup-close="popup-1" href="#">x</a>
        </div>
 </div>
 </div>
<script>
jQuery(function($){
   jQuery('#user-invite-anyone').on('click', function(e)  {
        var targeted_popup_class = 'popup-1';
       jQuery('#invite_sent_popup > .popup').fadeIn(350);
 		 	return false;

    });

jQuery('#invite_mail').submit(function(event) {

  var email   = jQuery('#email').val();
  //var incontent = jQuery('#invitcontent').val();

  

 if(email != ''){

  	  if(isEmail(email)){

  	  	var formdata = jQuery('#invite_mail').serialize();
        formdata = formdata+'&nonce='+rwbObj.nonce+'&action=send_invit_email';


    


       	jQuery('.disable_button').prop('disabled', true);
        jQuery('.image_loader img').css('display','block');

        jQuery.ajax({
            type: "post",
            url: rwbObj.ajaxurl,
          	//data: "action=send_invit_email&email="+email+"&incontent="+incontent+"&nonce="+rwbObj.nonce,  
            data: formdata,
           	success: function(response){
			 var obj = jQuery.parseJSON(response)
			 //console.log(obj);
			 if(obj.status == 'sent'){
			 	jQuery('.invite_main_form').hide();
				jQuery('.sent_invite_form').show();
/*				jQuery('.form_element').hide('slow');
				jQuery('.hide_heading').hide('slow');*/
				jQuery('#invite_mail')[0].reset();
				jQuery('.image_loader img').css('display','none');
				setTimeout(function(){ location.reload(); }, 1000);
			 }else{
			 	jQuery('.invite_error').text(obj.message);
			 	jQuery('.image_loader img').css('display','none');

			 }
                
            }
        });

        return false;
  	
	  }else{

	  	jQuery('.invite_error').text('Please fill valid email address');
	  	return false;
	  }

}else{

  	jQuery('.invite_error').text('Please fill all valid fields');
  	return false;
  }
	event.preventDefault();
});
jQuery('.send_new_one').click(function(){
    jQuery('.sent_invite_form').hide();
    jQuery('.invite_main_form').show();
});

function isEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}

});


function remove_error(){
 var erroch  =  jQuery('.invite_error').text();
 if(erroch != ''){

       jQuery('.disable_button').prop('disabled', false);
       jQuery('.invite_error').text('');
   }
}


jQuery('.custom_remove_error').keyup(function(){

	var erroch  =  jQuery('.invite_error').text();
 if(erroch != ''){

       jQuery('.disable_button').prop('disabled', false);
       jQuery('.invite_error').text('');
   }


});

jQuery('body').on('click','.closed_invite_popup',function(){

	jQuery('#invite_mail')[0].reset();
	var erroch  =  jQuery('.invite_error').text();

	if(erroch !=''){
		jQuery('.invite_error').text('');

	}

});

function remove_required_chapter(a){

	var chap  =  jQuery(a).val();

	if(chap == 'bbp_keymaster'){

         	jQuery('.remove_other_val').removeAttr("required");
     }else{

     	jQuery('.remove_other_val').prop('required',true);

     }
}
</script>