<?php


die('ddddddd');

?>