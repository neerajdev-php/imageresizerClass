<?php
/**
 * The header for Astra Theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Astra
 * @since 1.0.0
*/
?>
<!DOCTYPE html>
<?php astra_html_before(); ?>
<html <?php language_attributes(); ?>>
<head>
<?php astra_head_top(); ?>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">

<?php astra_head_bottom(); ?>
<?php wp_head(); ?>

<style type="text/css">
	.ui-autocomplete {
z-index: 99999999999;
}

</style>
</head>

<body <?php astra_schema_body(); ?> <?php body_class(); ?>>

<?php astra_body_top(); 

if(is_front_page() || is_page('contact') || is_page('the-team'))
{
	$specialClass =  "excelspecialbanner";
}
else
{
	$specialClass =  "excelspecial";	
}

?>
<div id="page" class="hfeed site <?php echo $specialClass;?>">
	<a class="skip-link screen-reader-text" href="#content"><?php echo esc_html( astra_default_strings( 'string-header-skip-link', false ) ); ?></a>

	<?php astra_header_before(); ?>

	<?php astra_header(); ?>

	<?php astra_header_after(); ?>

	<?php astra_content_before(); ?>

	<div id="content" class="site-content">
<?php global $post; 
if($post->post_type=="post" || is_page('bulk-invite') || is_page('chapters'))
{?>
	<div class="news_header">
		<div class="ast-container">
			<?php if($post->post_type=="post"){?> 
			 
					<h1 class="default_heading">News
					 <span class="rss_feed">

					 	<!-- <a href="<?php echo site_url('rss'); ?>" target="_black">Rss Feed</a> -->

					 </span>
					</h1>

					<?php }else{ ?>

					<h1 class="default_heading"><?php echo $post->post_title;?></h1>



					<?php } ?>
		</div>
	</div>     
	<?php 	
	if(is_single())
	{
 		global $post; ?>			
		<div class="ast-container custom_bottom_title">
    		<div class="header_bott12">
				<div class="news_title_left"><a href="javascript:void(0)" class="prevoius_page">	<i class="event_arocircle_icon_map"></i></a><?php echo $post->post_title;?>
				</div>
				<div class="news_social_icon">
				<?php 
					echo do_shortcode('[Sassy_Social_Share]');
					if ( is_user_logged_in() ) 
					{ ?>
						<a class="fist_iteram_btn edit_partner_section share_post_activity" data-id="<?php echo $post->ID;?>">Share</a>
			<?php 	} ?>
				</div>
			</div>
		</div>
<?php
 	}
}?>

<?php if($post->post_type=="mpp-gallery" || $post->post_type=="forum"){?>

	<div class="news_header">
		 <div class="ast-container"><h1 class="default_heading"><?php echo $post->post_title;?></h1>

		</div>
	 </div>
	 <?php } ?>
	 
<?php if(bp_is_group_create()){?>

	<div class="news_header gg_creater">
		 <div class="ast-container"><h1 class="default_heading">Create New Chapter</h1>

		</div>
	 </div>
	 <?php } 
$astClass='ast-container';
if ( is_singular( 'event' ) ) 
{
$astClass='ast-container-custom';
}
if(bp_is_group())
{
	$astClass='ast-container-custom';
}
if(bbp_is_single_topic())
{
	$astClass='ast-container-custom';
} 
global  $post;
$posttype = get_post_type($post );
if($posttype == 'post' && !is_single() && !is_category())
{
	$current_user = wp_get_current_user();
	$role  = $current_user->roles;
	if(in_array('administrator', $role))
	{ ?>
		<div class="custom_bottom_title news_custom_title">
			<div class="custom-container">
				<ul class="custom-page-subheading">
					<li class="custom_page_listing"><a class="fist_iteram_btn_new-event add_new_news" style="cursor: pointer;">Add New</a></li>
					<li class="edit_partner_code"><a class="fist_iteram_btn edit_news_section">Edit</a></li>
				</ul>
			</div>
		</div>
	<?php
	}
} ?>
<div class="<?php echo $astClass; ?>">
<?php astra_content_top(); ?>