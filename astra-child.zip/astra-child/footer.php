<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Astra
 * @since 1.0.0
 */
$user = wp_get_current_user();
$role = ( array ) $user->roles;
if (!in_array('administrator', $role))
{

  echo '<style>
        .add_new_partner{display:none;}
        .edit_partner_code{display:none;}
      </style>';
}
echo do_shortcode('[NEW_FRIEND_CODE]');
echo do_shortcode('[NEW_SHARE_CODE]');
echo do_shortcode('[NEW_NEWS_CODE]');

if(is_user_logged_in()){

  if (in_array('subscriber', $role) || in_array('bbp_participant', $role) ||  in_array('bbp_moderator', $role))
  {

    echo '<style>
          a.fist_iteram_btn_new-event {
             display: none;
          }
        </style>';
  }
}else{

     echo '<style>
          a.fist_iteram_btn_new-event {
             display: none;
          }
        </style>';

}

if(is_user_logged_in())
{
  if (in_array('bbp_moderator', $role) || in_array('administrator', $role) || in_array('bbp_keymaster', $role))
  {
    echo '<style>li#group-create-nav{display: block;}</style>';
  }
  else
  {
    echo '<style>li#group-create-nav{display: none;}</style>';
  }
}
else
{
  echo '<style>li#group-create-nav{display: none;}</style>';
}

?>  
<!-- <script src="<?php echo get_template_directory_uri();?>/iziModal/js/custombox.min.js"></script> -->
<!-- <script src="<?php echo get_template_directory_uri();?>/iziModal/js/iziScript.js"></script> -->
            <?php astra_content_bottom(); ?>

            </div> <!-- ast-container -->

        </div><!-- #content -->


        <?php astra_content_after(); ?>

        <?php astra_footer_before(); ?>

        <?php astra_footer(); ?>

        <?php astra_footer_after(); ?>

    </div><!-- #page -->


    <?php astra_body_bottom(); ?>
    
    <?php wp_footer(); ?>
</body>
</html>


