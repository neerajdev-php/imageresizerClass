<?php
/**
 * BuddyPress - Members Single Profile
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

/** This action is documented in bp-templates/bp-legacy/buddypress/members/single/settings/profile.php */
do_action( 'bp_before_member_settings_template' ); ?>

<h2 class="bp-screen-reader-text"><?php
	/* translators: accessibility text */
	_e( 'Account settings', 'buddypress' );
?></h2>
<div class="custom-container-header">
	<div class="custom-container">
		<div class="ast-row">
			<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
			 <h3><?php _e( 'General Settings', 'buddypress' ); ?></h3>
			</div>

			<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
			 <h3><?php _e( 'E-mail Notifications', 'buddypress' ); ?></h3>
			</div>
		</div>
	</div>
</div>

<form action="<?php echo bp_displayed_user_domain() . bp_get_settings_slug() . '/general'; ?>" method="post" class="standard-form" id="settings-form" enctype="multipart/form-data">
<div class="custom-container">

<div class="ast-row">
	<div class="ast-col-lg-4 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
     <label for="file">Profile Photo</label>
	   <div class="img_file_container">	
	   <div class="img_preview"><?php 
         echo bp_core_fetch_avatar(array('item_id' => bp_displayed_user_id(), 'type' => 'thumb', 'width' => 100, 'height' => 100, 'class' => 'profile-avatar','html'=>true)); ?></div>

	<input type="file" name="file" id="file">
    <p><?php _e( 'Your profile photo will be used on your profile and throughout the site. If there is a <a href="http://gravatar.com">Gravatar</a> associated with your account email we will use that, or you can upload an image from your computer.', 'buddypress' ); ?></p>
    </div>


	<?php /*if ( !is_super_admin() ) : ?>

		<label for="pwd"><?php _e( 'Current Password <span>(required to update email or change current password)</span>', 'buddypress' ); ?></label>
		<input type="password" name="pwd" id="pwd" size="16" value="" class="settings-input small" <?php bp_form_field_attributes( 'password' ); ?>/> &nbsp;<a href="<?php echo wp_lostpassword_url(); ?>"><?php _e( 'Lost your password?', 'buddypress' ); ?></a>

	<?php endif;*/ ?>

	<label for="email"><?php _e( 'Account Email', 'buddypress' ); ?></label>
	<input type="email" name="email" id="email" value="<?php echo bp_get_displayed_user_email(); ?>" class="settings-input" <?php bp_form_field_attributes( 'email' ); ?>/>

	<label for="pass1"><?php _e( 'Change Password <span>(leave blank for no change)</span>', 'buddypress' ); ?></label>
	<input type="password" name="pass1" id="pass1" size="16" value="" class="settings-input small password-entry" <?php bp_form_field_attributes( 'password' ); ?>/>
	<div id="pass-strength-result"></div>
	<label for="pass2"><?php _e( 'Repeat New Password', 'buddypress' );
	?></label>
	<input type="password" name="pass2" id="pass2" size="16" value="" class="settings-input small password-entry-confirm" <?php bp_form_field_attributes( 'password' ); ?>/>

	<?php 

	 	$current_user = wp_get_current_user();

	 	//echo '<pre>'; print_r($current_user->roles);
	 	if(in_array('bbp_keymaster', $current_user->roles) || in_array('administrator', $current_user->roles)){
	 	?>

<!-- 	<div class="form_ele_group">
	 	<label for="user_role">User Role</label>
	 	
	 	<select name='user_role' id="user_role" required="required">
	 		<option value="">Select Role</option>
<option value="administrator" <?php if(in_array('administrator', $current_user->roles)){ echo 'selected';}?>>Administrator</option>
	 		<option value="bbp_moderator" <?php if(in_array('bbp_moderator', $current_user->roles)){ echo 'selected';}?>>Chapter Head</option>
	 		<option value="bbp_participant" <?php if(in_array('bbp_participant', $current_user->roles)){ echo 'selected';}?>>Member</option>
	 	</select>	
	</div> -->

	<?php
	}

			/**
			 * Fires before the display of the submit button for user general settings saving.
			 *
			 * @since 1.5.0
			 */
	     do_action( 'bp_core_general_settings_before_submit' ); ?>
	</div>
	<div class="ast-col-lg-6 ast-col-md-6 ast-col-sm-6 ast-col-xs-12 ast-col-lg-offset-2">
	     <label for=""><?php _e( 'Send an email notice when:', 'buddypress' ); ?></label>
	   <?php 	do_action( 'bp_notification_settings' ); ?>
	</div>
</div>
<div class="ast-row">
<div class="ast-col-lg-4 ast-col-md-6 ast-col-sm-6 ast-col-xs-12">
	<div class="submit">
		<input type="submit" name="submit" value="<?php esc_attr_e( 'Save Changes', 'buddypress' ); ?>" id="submit" class="auto" />
	</div>
	</div>
	</div>
		</div>

	<?php

	/**
	 * Fires after the display of the submit button for user general settings saving.
	 *
	 * @since 1.5.0
	 */
	do_action( 'bp_core_general_settings_after_submit' );
	 ?>


	<?php wp_nonce_field( 'bp_settings_general' ); ?>

</form>
<?php
/** This action is documented in bp-templates/bp-legacy/buddypress/members/single/settings/profile.php */
do_action( 'bp_after_member_settings_template' );
?>




