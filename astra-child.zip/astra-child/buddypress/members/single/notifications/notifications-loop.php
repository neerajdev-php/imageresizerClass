<?php
/**
 * BuddyPress - Members Notifications Loop
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

?>
<form action="" method="post" id="notifications-bulk-management">
	
	      <ul class="notifications">
	

			<?php while ( bp_the_notifications() ) : bp_the_notification();?>

				<li class="custom_noti_main hide_noti_<?php bp_the_notification_id(); ?>">

					<input id="<?php bp_the_notification_id(); ?>"  name="notifications[]" value="<?php bp_the_notification_id(); ?>" class="notification-check" type="hidden">
			
					<div class="noti_avtar"><?php echo bp_get_the_notification_image();?></div>


					<div class="combine_two_dib_noti">

						<div class="notification-since"><?php bp_the_notification_time_since();?></div>
						<div class="notification-description"><?php bp_the_notification_description();?></div>


					</div>

					<div class="notification-actions"><?php bp_the_notification_action_links(); ?></div>

				</li>

			<?php endwhile; ?>

			</ul>

<!--<div class="notifications-options-nav">
		<?php bp_notifications_bulk_management_dropdown(); ?>
	</div>-->

	<?php //wp_nonce_field( 'notifications_bulk_nonce', 'notifications_bulk_nonce' ); ?>
</form>
