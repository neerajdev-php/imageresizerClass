<?php
/**
 * BuddyPress - Users Cover Image Header
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

?>
<?php

/**
 * Fires before the display of a member's header.
 *
 * @since 1.2.0
 */


do_action( 'bp_before_member_header' ); ?>
<?php $member_id = get_current_user_id(); ?>

<div id="cover-image-container">
  <a id="header-cover-image" href="<?php echo bp_core_get_user_domain( $member_id ) ?>"></a>

  <div id="item-header-cover-image">
    <div id="item-header-avatar">



            <a href="<?php echo bp_core_get_user_domain( $member_id ) ?>" 

            title="<?php echo bp_core_get_user_displayname( $member_id ); ?>">

            <?php echo bp_core_fetch_avatar ( array( 'item_id' => $member_id, 'type' => 'full' ) ) ?>       


            </a>


        <?php //bp_displayed_user_avatar( 'type=full,user_id' ); ?>

      </a>
    </div><!-- #item-header-avatar -->

    <div id="item-header-content">

      <?php if ( bp_is_active( 'activity' ) && bp_activity_do_mentions() ) : ?>
        <span class="user-nicename">@<?php echo bp_core_get_user_displayname( $member_id ); ?> -   

            <?php if(is_user_logged_in()){

              echo '<span class="custom_time_online">Active now</span>';
                }else{
                  echo '<span class="offline_time">Offline</span>';
                } ?>
            </span>




        <h2 class="user-name"><?php echo get_the_title(); ?></h2>


      <?php endif; 

      //echo bp_current_component();
        
      //echo bp_current_action();

      //if(bp_current_component() == 'activity'){?>

      <div id="item-buttons"><?php  //do_action( 'bp_member_header_actions' );  ?> </div><!-- #item-buttons -->




          <?php //}else{ ?>


        <!-- <div id="latest-update">
           <div class="profile_extra_buttons">
             
             <span class="add_custom_friends"> <a href="javascript:void(0)" class="public_message_btn">Add Friend</a></span>
              <a href="javascript:void(0)" class="public_message_btn">Send Message</a>
              <a href="javascript:void(0)" class="public_message_btn">Mention</a>
            </div>


          </div>-->

          <?php //} ?>




        <!--<span class="custom_time" data-livestamp="<?php bp_core_iso8601_date( bp_get_user_last_activity( bp_displayed_user_id() ) ); ?>"></span>-->

      <?php //bp_last_activity( bp_displayed_user_id() ); ?>

      <?php //if(bp_current_component() == 'notifications'){

        //echo bp_current_component();
        //echo $url =  bp_core_get_user_domain(bp_displayed_user_id());

        //$nonUser =  bp_displayed_user_mentionname();

        //$current_user = wp_get_current_user();

        //$loguinUser =  $current_user->user_nicename;

        //if(bp_displayed_user_mentionname() == $loguinUser) {

        //if(is_user_logged_in()){

          //if(!bp_current_component('activity')){

        ?>


           <!--<div id="latest-update">
           <div class="profile_extra_buttons">
             
              <a href="javascript:void(0)" class="public_message_btn">Add Friend</a>
              <a href="javascript:void(0)" class="public_message_btn">Send Message</a>
              <a href="javascript:void(0)" class="public_message_btn">Mention</a>
            </div>

            <?php //bp_activity_latest_update( bp_displayed_user_id() ); ?>

          </div> -->


      <?php

        //}

    //}?>


      <?php

      /**
       * Fires before the display of the member's header meta.
       *
       * @since 1.2.0
       */
      do_action( 'bp_before_member_header_meta' ); ?>

      <div id="item-meta">

        <?php if ( bp_is_active( 'activity' ) ) : 

        //echo bp_current_component();

        ?>

          <!--<div id="latest-update">
           <div class="profile_extra_buttons">
              <a href="#" class="active_now_deactive_btn">Active Now</a>
              <a href="#" class="public_message_btn">Send Public Message</a>
            </div>

            <?php //bp_activity_latest_update( bp_displayed_user_id() ); ?>

          </div>-->

        <?php endif; ?>

        <?php

         /**
          * Fires after the group header actions section.
          *
          * If you'd like to show specific profile fields here use:
          * bp_member_profile_data( 'field=About Me' ); -- Pass the name of the field
          *
          * @since 1.2.0
          */
         do_action( 'bp_profile_header_meta' );

         ?>

      </div><!-- #item-meta -->

    </div><!-- #item-header-content -->

  </div><!-- #item-header-cover-image -->
</div><!-- #cover-image-container -->

<?php

/**
 * Fires after the display of a member's header.
 *
 * @since 1.2.0
 */
do_action( 'bp_after_member_header' ); ?>

<div id="template-notices" role="alert" aria-atomic="true">
  <?php

  /** This action is documented in bp-templates/bp-legacy/buddypress/activity/index.php */
  do_action( 'template_notices' ); ?>

</div>
