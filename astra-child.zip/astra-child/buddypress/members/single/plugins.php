<?php
/**
 * BuddyPress - Users Plugins Template
 *
 * 3rd-party plugins should use this template to easily add template
 * support to their plugins for the members component.
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

		/**
		 * Fires at the start of the member plugin template.
		 *
		 * @since 1.2.0
		 */

		  $actioon1  = bp_current_action();
		  $com1      = bp_current_component();


		do_action( 'bp_before_member_plugin_template' ); ?>

		<?php if ( ! bp_is_current_component_core() ) : ?>

		<div class="item-list-tabs no-ajax" id="subnav" aria-label="<?php esc_attr_e( 'Member secondary navigation', 'buddypress' ); ?>" role="navigation">
		 <div class="custom-container">
			
			<ul>

				<?php if($com1 == 'forums'){ ?>

				<li class="noti_cus_heading custom_discount_menu cuustom_inbox"><strong class="fist_iteram_heading">Forums</strong></li>

				 <?php 

				 if(is_user_logged_in()){

				 $user = wp_get_current_user();
				 $role = ( array ) $user->roles;
				 	if (in_array('administrator', $role) || in_array('bbp_moderator', $role))
					{
				 ?>

				<li class="edit_partner_code custom_discount_menu cuustom_inbox"><a href="<?php echo site_url('create-forums');?>">Create New Forum</a></li>

				<?php } } } ?>
				<?php if($com1 == 'events'){ ?>
				<li class="edit_partner_code custom_discount_menu cuustom_inbox"><a href="<?php echo site_url('create-new-event');?>">Add New</a></li>
				<?php } ?>

				<?php bp_get_options_nav(); 


				 $action  = bp_current_action();
				 $com     = bp_current_component(); 

                if($com == 'discount-codes' && $action == 'discount-codes'){

				?>

				<li class="noti_cus_heading custom_discount_menu"><strong>Discount Code</strong></li> <?php } ?>

					<?php if(bp_current_component() == 'discount-codes'){

						$user = wp_get_current_user();
                        $role = ( array ) $user->roles;

                        if (in_array('administrator', $role))
    					{

				    ?>
				 
						<li class="new_discount_code"><span class="add_discount_code"><a href="javascript:void(0)">New code</a></span></li>
						<li class="edit_discount_code"><span class="edit_discount_code"><a href="javascript:void(0)">Edit</a></span></li>

				<?php } } ?>
				<?php

				/**
				 * Fires inside the member plugin template nav <ul> tag.
				 *
				 * @since 1.2.2
				 */
				do_action( 'bp_member_plugin_options_nav' ); ?>
			</ul>
		 </div>
		</div><!-- .item-list-tabs -->

		<?php endif; ?>

		<div class="custom-container <?php if($com1 == 'events'){?>my_event_em_list<?php } ?>"><!-- custom-contanier (for content) -->

		<?php if ( has_action( 'bp_template_title' ) ) : ?>
			<h3><?php

			/**
			 * Fires inside the member plugin template <h3> tag.
			 *
			 * @since 1.0.0
			 */
			do_action( 'bp_template_title' ); ?></h3>

		<?php endif; ?>

		<?php

		/**
		 * Fires and displays the member plugin template content.
		 *
		 * @since 1.0.0
		 */
		do_action( 'bp_template_content' ); ?>

		<?php

		/**
		 * Fires at the end of the member plugin template.
		 *
		 * @since 1.2.0
		 */
		do_action( 'bp_after_member_plugin_template' );
		?>
		</div><!-- custom-contanier (for content) end -->
