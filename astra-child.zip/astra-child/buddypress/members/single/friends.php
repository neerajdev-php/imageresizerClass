<?php
/**
 * BuddyPress - Users Friends
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

$current_user          = wp_get_current_user();
$active_couint  = get_total_friends( $current_user->ID );
?>
<div class="item-list-tabs no-ajax" id="subnav" aria-label="<?php esc_attr_e( 'Member secondary navigation', 'buddypress' ); ?>" role="navigation">

	<div class="custom-container">
		<ul>
		<?php 

		if ( bp_is_my_profile() ) bp_get_options_nav(); ?>

		<?php if ( !bp_is_current_action( 'requests' ) ) : ?>

			<!--<li id="members-order-select" class="last filter">

				<label for="members-friends"><?php _e( 'Order By:', 'buddypress' ); ?></label>
				<select id="members-friends">
					<option value="active"><?php _e( 'Last Active', 'buddypress' ); ?></option>
					<option value="newest"><?php _e( 'Newest Registered', 'buddypress' ); ?></option>
					<option value="alphabetical"><?php _e( 'Alphabetical', 'buddypress' ); ?></option>

					<?php

					/**
					 * Fires inside the members friends order options select input.
					 *
					 * @since 2.0.0
					 */
					do_action( 'bp_member_friends_order_options' ); ?>

				</select>
			</li>-->

			<?php if(is_user_logged_in()){?>
			<li class="add_custom_friends align-right-menu"><span class="add_custom_friends"><a href="javascript:void(0)">Add New</a></span></li>
			<li class="right_custom_nav_text"> <strong> <?php echo $active_couint;?> Friends</strong></li>
			

			<?php } ?>
			

		<?php endif; ?>

	</ul>
	</div>

</div>

<?php
switch ( bp_current_action() ) :

	// Home/My Friends
	case 'my-friends' :

		/**
		 * Fires before the display of member friends content.
		 *
		 * @since 1.2.0
		 */
		do_action( 'bp_before_member_friends_content' ); ?>

		<?php if (is_user_logged_in() ) : ?>
			<h2 class="bp-screen-reader-text"><?php
				/* translators: accessibility text */
				_e( 'My friends', 'buddypress' );
			?></h2>
		<?php else : ?>
			<h2 class="bp-screen-reader-text"><?php
				/* translators: accessibility text */
				_e( 'Friends', 'buddypress' );
			?></h2>
		<?php endif ?>
		<div class="custom-container">
			<div class="membermbers friends">

				<?php bp_get_template_part( 'members/members-loop' ) ?>

			</div><!-- .members.friends -->
		</div>
		<?php

		/**
		 * Fires after the display of member friends content.
		 *
		 * @since 1.2.0
		 */
		do_action( 'bp_after_member_friends_content' );
		break;

	case 'requests' :
	    echo  '<div class="custom-container">';
			bp_get_template_part( 'members/single/friends/requests' );
		echo '</div>';
		break;

	// Any other
	default :
	 	echo  '<div class="custom-container">';
		 	bp_get_template_part( 'members/single/plugins' );
		echo '</div>';
		break;
endswitch;
