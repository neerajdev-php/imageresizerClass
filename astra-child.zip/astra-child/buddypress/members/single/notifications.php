<?php
/**
 * BuddyPress - Users Notifications
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

$unread = get_current_user_unread_notification_count();
$read = get_current_user_read_notification_count();

?>
<div class="item-list-tabs no-ajax custom_bottm_notifi" id="subnav" aria-label="<?php esc_attr_e( 'Member secondary navigation', 'buddypress' ); ?>" role="navigation">
	<div class="custom-container">
	<ul>
		<li class="notifications-my-notifications-personal-li noti_cus_heading custom_membership_menu"><a href="#">Notifications</a></li>
		<?php bp_get_options_nav(); ?>

		<!--<li id="members-order-select" class="last filter">
			<?php bp_notifications_sort_order_form(); ?>
		</li>-->


		<?php if(bp_current_action() == 'unread'){ //if($unread > 0){?>

			
	
				<li class="delete_all_read_unread"><a href="javascript:void(0)" data-id="<?php echo bp_displayed_user_id();?>" data-action="<?php echo bp_current_action();?>">Delete All</a></li>

				<li class="mark_read_unread"><a href="javascript:void(0)" data-id="<?php echo bp_displayed_user_id();?>" data-action="<?php echo bp_current_action();?>">Mark all as Read</a></li>

			 


		<?php //} 
	} else{ //if($read > 0){?>

			<li class="delete_all_read_unread"><a href="javascript:void(0)" data-id="<?php echo bp_displayed_user_id();?>" data-action="<?php echo bp_current_action();?>">Delete All</a></li>

		   <li class="mark_read_unread"><a href="javascript:void(0)" data-id="<?php echo bp_displayed_user_id();?>" data-action="<?php echo bp_current_action();?>">Mark all as Unread</a></li>

		


		<?php //} 
	} ?>

	</ul>
</div>
</div>
<?php
switch ( bp_current_action() ) :

	case 'unread' :
		bp_get_template_part( 'members/single/notifications/unread' );
		break;

	case 'read' :
		bp_get_template_part( 'members/single/notifications/read' );
		break;

	// Any other actions.
	default :
		bp_get_template_part( 'members/single/plugins' );
		break;
endswitch;
