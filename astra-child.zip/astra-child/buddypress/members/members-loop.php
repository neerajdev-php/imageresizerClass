<?php
/**
 * BuddyPress - Members Loop
 *
 * Querystring is set via AJAX in _inc/ajax.php - bp_legacy_theme_object_filter()
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

/**
 * Fires before the display of the members loop.
 *
 * @since 1.2.0
 */
do_action( 'bp_before_members_loop' ); ?>

<?php if ( bp_get_current_member_type() ) : ?>
	<p class="current-member-type"><?php bp_current_member_type_message() ?></p>
<?php endif; ?>

<?php if ( bp_has_members( bp_ajax_querystring( 'members' ) ) ) : ?>

	<!--<div id="pag-top" class="pagination">

		<div class="pag-count" id="member-dir-count-top">

			<?php bp_members_pagination_count(); ?>

		</div>

		<div class="pagination-links" id="member-dir-pag-top">

			<?php bp_members_pagination_links(); ?>

		</div>

	</div>-->

	<?php

	/**
	 * Fires before the display of the members list.
	 *
	 * @since 1.1.0
	 */
	do_action( 'bp_before_directory_members_list' ); ?>

	<ul id="members-list" class="item-list custom_group_member_listing" aria-live="assertive" aria-relevant="all">

	<?php 


	$current_user          = wp_get_current_user();
	$latestId              =  $current_user->user_nicename;
	$currwent_user_domain  = bp_core_get_user_domain( $current_user->ID );


	while ( bp_members() ) : bp_the_member();

			$userid  =  bp_get_member_user_id();
			$user_info = get_userdata(  $userid );

			$msgUrl  =  $currwent_user_domain.'messages/compose/?r='.$user_info->user_nicename.'&_wpnonce=2dc29b7084';

	 ?>

		<li <?php bp_member_class(); ?>>

			<div class="main_user_listing">

					<div class="member_image">

							<div class="item-avatar">
								<a href="<?php bp_member_permalink(); ?>"><?php bp_member_avatar(); ?></a>
							</div>
					</div>

					<div class="member_list_name">
							<h5><a href="<?php bp_member_permalink(); ?>"><?php bp_member_name(); ?></a></h5>

							<span class="user_nikname"><?php echo '@'.$user_info->user_nicename;?></span>
					</div>

					<?php do_action( 'bp_directory_members_item' ); ?>

						
					

					<div class="action">

						<?php if(is_user_logged_in()){?>

							<span class="custom_member_message"><a href="<?php  echo $msgUrl;?>">Msg</a></span>

						<?php } ?>

						<?php do_action( 'bp_directory_members_actions' ); ?>

					</div>

					<div class="clear"></div>


				</div>


		</li>

	<?php endwhile; ?>

	</ul>

	<?php

	/**
	 * Fires after the display of the members list.
	 *
	 * @since 1.1.0
	 */
	do_action( 'bp_after_directory_members_list' ); ?>

	<?php bp_member_hidden_fields(); ?>

	<div id="pag-bottom" class="pagination">

		<!--<div class="pag-count" id="member-dir-count-bottom">

			<?php bp_members_pagination_count(); ?>

		</div>-->

		<div class="pagination-links" id="member-dir-pag-bottom">

			<?php bp_members_pagination_links(); ?>

		</div>

	</div>

<?php else: ?>

	<div id="message" class="info">
		<p><?php _e( "Sorry, no members were found.", 'buddypress' ); ?></p>
	</div>

<?php endif; ?>

<?php

/**
 * Fires after the display of the members loop.
 *
 * @since 1.2.0
 */
do_action( 'bp_after_members_loop' );
