<?php
/**
 * Forums Loop
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<?php do_action( 'bbp_template_before_forums_loop' ); ?>

<ul id="forums-list-<?php bbp_forum_id(); ?>" class="forum-table-ul">

	<li class="mobile_hidden">
		
		<div class="forum-table-topic-title">
            <strong class="desk_for_header">Forum</strong>
         </div>

         <div class="forum-table-topic-voice-count">
            <strong>Topics</strong>
         </div>

         <div class="forum-table-topic-reply-count">
            <strong><?php bbp_show_lead_topic() ? _e( 'Replies', 'bbpress' ) : _e( 'Posts', 'bbpress' ); ?></strong>
         </div>

         <div class="forum-table-topic-freshness">
            <strong>Freshness</strong>
         </div>



	</li><!-- .bbp-header -->

	
		<?php 

		if(is_user_logged_in()){

		 while ( bbp_forums() ) : bbp_the_forum();  

		 	
			bbp_get_template_part( 'loop', 'single-forum' ); 


		 	 endwhile;

			}else{

					echo "<div class='erro_forum'>Please login to access the forrum's threads.</div>";

				}
			?>

	<!--<li class="bbp-footer">

		<div class="tr">
			<p class="td colspan4">&nbsp;</p>
		</div>

	</li>-->

	<!-- .bbp-footer -->

</ul><!-- .forums-directory -->



<?php do_action( 'bbp_template_after_forums_loop' ); ?>
