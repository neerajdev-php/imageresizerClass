<?php

/**
 * Replies Loop - Single Reply
 *
 * @package bbPress
 * @subpackage Theme
			*/
$getLinks='';
ob_start();
bbp_reply_admin_links();
$getLinks= ob_get_contents();
ob_get_clean();

$act =  bp_current_action();
$com =  bp_current_component();
$topic_id        = bbp_get_topic_id();
$topic_author_id = get_post_field( 'post_author', bbp_get_topic_id() );
?>
<li class="bbp-body-repeat">
	<!-- #post-<?php bbp_reply_id(); ?> -->
<?php 
			$author 		  = get_the_author();
			$repluy_author_id = get_post_field( 'post_author', bbp_get_reply_id() );
			$userData         = get_userdata( $repluy_author_id );
			$role             = $userData->roles;
			$myRole = '';
			if(in_array('administrator', $role) || in_array('bbp_keymaster', $role)){
				$myRole  = 'Administrator';
			}elseif (in_array('bbp_moderator', $role) ) {
				$myRole  = 'Chapter Head';
			}elseif (in_array('bbp_participant', $role) ) {
				$myRole  = 'Member';
			}
?>
<div class="forum-reply-author">
			  <div class="forum-reply-author-inner">

				<?php do_action( 'bbp_theme_before_reply_author_details' ); ?>

				<?php
				$bbp_reply_author_link='';

				   ob_start();

				 bbp_reply_author_link( array( 'sep' => '', 'show_role' => true ) );
				$bbp_reply_author_link= ob_get_contents();
				 ob_get_clean();

				 $bbp_reply_author_link = preg_replace('#<div class="bbp-author-role">(.*?)</div>#', '', $bbp_reply_author_link);

				 echo  $bbp_reply_author_link;

				  ?>

				<div class="bbp-author-role"><?php echo $myRole;?></div>

				<?php

						$user = get_userdata( bbp_get_reply_author_id() );
						if ( !empty( $user->user_nicename ) ) {
						$user_nicename = $user->user_nicename;
						echo "@".$user_nicename;
						}

                 ?>

				<?php if ( bbp_is_user_keymaster() ) : ?>

					<?php do_action( 'bbp_theme_before_reply_author_admin_details' ); ?>


				<!-- 	<div class="bbp-reply-ip"><?php bbp_author_ip( bbp_get_reply_id() ); ?></div> -->

					<?php do_action( 'bbp_theme_after_reply_author_admin_details' ); ?>

				<?php endif; ?>

				<?php do_action( 'bbp_theme_after_reply_author_details' ); ?>
				</div>

			</div><!-- .bbp-reply-author -->

			<div class="forum-reply-content">
				<div class="forum-reply-content-inner">
						<div class="forum-reply-content-inner-left">
									<?php do_action( 'bbp_theme_before_reply_content' ); ?>
									<span class="bbp-reply-post-date"><?php bbp_reply_post_date(); ?></span>

									<?php bbp_reply_content(); ?>

									<?php do_action( 'bbp_theme_after_reply_content' ); ?>

						</div>			

					<div id="post-<?php bbp_reply_id(); ?>" class="bbp-reply-header">
							<div class="bbp-meta">	


								<?php if ( bbp_is_single_user_replies() ) : ?>

									<span class="bbp-header">
										<?php _e( 'in reply to: ', 'bbpress' ); ?>
										<a class="bbp-topic-permalink" href="<?php bbp_topic_permalink( bbp_get_reply_topic_id() ); ?>"><?php bbp_topic_title( bbp_get_reply_topic_id() ); ?></a>
									</span>

								<?php endif; ?>


								<?php do_action( 'bbp_theme_before_reply_admin_links' ); ?>

								<?php if($act == 'replies' && $com == 'forums'){ 


			                 		}else{


			                 			echo '<a href="javascript:void(0);" class="bbp-actions-toggle action_toggle"></a>';
			                 		}


								echo  str_replace(' | ', '',$getLinks) ; ?>

								<?php do_action( 'bbp_theme_after_reply_admin_links' ); ?>

								<a href="<?php bbp_reply_url(); ?>" class="bbp-reply-permalink">#<?php bbp_reply_id(); ?></a>
							</div>
	                  </div> 


				 </div>

			</div><!-- .bbp-reply-content -->
	</li>	
