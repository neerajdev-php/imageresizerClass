<?php

/**
 * Topics Loop
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<?php do_action( 'bbp_template_before_topics_loop' ); ?>

<div class="forum-table" id="bbp-forum-<?php bbp_forum_id(); ?>">
   <ul class="forum-table-ul">
      <li>
         <div class="forum-table-topic-title">
            <strong><?php _e( 'Topic', 'bbpress' ); ?></strong>
         </div>
         <div class="forum-table-topic-voice-count">
            <strong><?php _e( 'Voices', 'bbpress' ); ?></strong>
         </div>
         <div class="forum-table-topic-reply-count">
            <strong><?php bbp_show_lead_topic() ? _e( 'Replies', 'bbpress' ) : _e( 'Posts', 'bbpress' ); ?></strong>
         </div>
         <div class="forum-table-topic-freshness">
            <strong><?php _e( 'Freshness', 'bbpress' ); ?></strong>
         </div>

      </li>
       <?php while ( bbp_topics() ) : bbp_the_topic(); ?>

			<?php bbp_get_template_part( 'loop', 'single-topic' ); ?>

		<?php endwhile; ?>
  

   </ul>
</div>

<?php do_action( 'bbp_template_after_topics_loop' ); ?>