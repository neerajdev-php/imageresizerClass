<?php

/**
 * Forums Loop - Single Forum
 *
 * @package bbPress
 * @subpackage Theme
 */

$forum_id =  bbp_get_forum_id();

?>

<li class="bbp-body hide_delete_forum_<?php echo $forum_id;?>">



		<div class="forum-table-topic-title">
			<strong class="forum_mobile_active">Forum</strong>
         	<div class="forum-table-topic-title-box">

		<?php if ( bbp_is_user_home() && bbp_is_subscriptions() ) : ?>

			<span class="bbp-row-actions">

				<?php do_action( 'bbp_theme_before_forum_subscription_action' ); ?>

				<?php bbp_forum_subscription_link( array( 'before' => '', 'subscribe' => '+', 'unsubscribe' => '&times;' ) ); ?>

				<?php do_action( 'bbp_theme_after_forum_subscription_action' ); ?>

			</span>

		<?php endif; ?>

		<?php do_action( 'bbp_theme_before_forum_title' ); ?>

		<a class="bbp-forum-title" href="<?php bbp_forum_permalink(); ?>"><?php bbp_forum_title(); ?></a>

		<?php 
			if(current_user_can('administrator') || current_user_can('bbp_keymaster'))
			{?>
				<span class="news_delete forum_delete" data-id="<?php echo $forum_id;?>" style="float: right;"><a href="javascript:void(0);">Delete</a></span>
			<?php }
		?>
		

		<?php do_action( 'bbp_theme_after_forum_title' ); ?>

		<?php do_action( 'bbp_theme_before_forum_description' ); ?>

		<div class=""><?php bbp_forum_content(); ?></div>

		<?php do_action( 'bbp_theme_after_forum_description' ); ?>

		<?php do_action( 'bbp_theme_before_forum_sub_forums' ); ?>

		<?php bbp_list_forums(); ?>

		<?php do_action( 'bbp_theme_after_forum_sub_forums' ); ?>

		<?php bbp_forum_row_actions(); ?>



	</div></div>

	


		  <div class="forum-table-topic-voice-count">
		  	<strong class="forum_mobile_active">Topic</strong>
            <div class="forum-table-box">
			<?php bbp_forum_topic_count(); ?>
				
		</div>
		</div>
   

		
		<div class="forum-table-topic-reply-count"> 
				<strong class="forum_mobile_active">Posts</strong>
            <div class="forum-table-box">

		<?php bbp_show_lead_topic() ? bbp_forum_reply_count() : bbp_forum_post_count(); ?>

	</div></div>
			

		

	

		<div class="forum-table-topic-freshness"> 

			<strong class="forum_mobile_active">Freshness</strong>
            <div class="forum-table-box-reply">	

		<?php do_action( 'bbp_theme_before_forum_freshness_link' ); ?>

		<?php bbp_forum_freshness_link(); ?>

		<?php do_action( 'bbp_theme_after_forum_freshness_link' ); ?>

		<p class="bbp-topic-meta">

			<?php do_action( 'bbp_theme_before_topic_author' ); ?>

			<span class="bbp-topic-freshness-author"><?php bbp_author_link( array( 'post_id' => bbp_get_forum_last_active_id(), 'size' => 14 ) ); ?></span>

			<?php do_action( 'bbp_theme_after_topic_author' ); ?>

		</p>



	</div></div>

	</li><!-- .bbp-body -->
	
