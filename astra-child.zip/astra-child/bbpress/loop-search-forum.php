<?php

/**
 * Search Loop - Single Forum
 *
 * @package bbPress
 * @subpackage Theme
 */
 $profileURl=  home_url( '/members/' . bp_core_get_username(get_the_author_id()) . '/' );


?>

<li class="bbp-body hide_delete_forum_<?php bbp_forum_id(); ?>">
  <div class="forum-table-topic-freshness">
    <?php do_action( 'bbp_theme_before_forum_title' ); ?>
   <div class="forum-table-box-reply">   <a class="bbp-forum-title" href="<?php echo $profileURl; ?>"  ><?php echo get_the_author(); ?></a> </div>
     <?php do_action( 'bbp_theme_after_forum_title' ); ?>
  </div>
   
	<div class="forum-table-topic-title-box">
		<?php do_action( 'bbp_theme_before_forum_content' ); ?>
		 <a class="bbp-forum-title" href="<?php bbp_forum_permalink(); ?>"><?php bbp_forum_title(); ?></a><div class="ast-clearfix"></div>
		<?php bbp_forum_content(); ?>
		<?php do_action( 'bbp_theme_after_forum_content' ); ?>
    </div>


</li>


