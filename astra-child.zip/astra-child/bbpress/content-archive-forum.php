<?php

/**
 * Archive Forum Content Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>
<div id="bbpress-forums">



	<?php bbp_breadcrumb(); 

	if(is_user_logged_in()){

	 $user = wp_get_current_user();
	 $role = ( array ) $user->roles;
	 	if (in_array('administrator', $role) || in_array('bbp_moderator', $role))
		{
	?>
	<div class="create_custom_foruin_page custom-page-subheading">
	 	<a  href="<?php echo site_url('create-forums');?>" class="button submit">Create New</a>
	</div>
	<?php if ( bbp_allow_search() ) : ?>

		<div class="bbp-search-form">

			<?php bbp_get_template_part( 'form', 'search' ); ?>

		</div>

	<?php endif; ?>
	
	<?php } } bbp_forum_subscription_link(); ?>

	<?php do_action( 'bbp_template_before_forums_index' ); ?>

	<?php if ( bbp_has_forums() ) : ?>

		<?php bbp_get_template_part( 'loop',     'forums'    ); ?>

	<?php else : ?>

		<?php bbp_get_template_part( 'feedback', 'no-forums' ); ?>

	<?php endif; ?>

	<?php do_action( 'bbp_template_after_forums_index' ); 

	if(is_user_logged_in()){

	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		echo custom_pagination(bbpress()->forum_query->max_num_pages,"",$paged);

    }
?>
</div>
