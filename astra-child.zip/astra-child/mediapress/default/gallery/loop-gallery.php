<?php
// Exit if the file is accessed directly over web
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * List all galleries for the current component
 *
 */
?>
<!-- <div class=""><a href="javascript:void(0);" class="edit_gallery">Edit</a></div> -->

<?php if ( mpp_have_galleries() ) : ?>
	 <div class="gallery_warnings"></div>
	<div class='mpp-g mpp-item-list mpp-galleries-list cust_gal_list'>
	
	 <form name="galler_loop_frm" id="galler_loop_frm" method="post"> 
		<?php while ( mpp_have_galleries() ) : mpp_the_gallery(); ?>

			<div class="<?php mpp_gallery_class( mpp_get_gallery_grid_column_class() ); ?>" id="mpp-gallery-<?php mpp_gallery_id(); ?>">

				<?php do_action( 'mpp_before_gallery_entry' ); ?>

				<div class="mpp-item-meta mpp-gallery-meta mpp-gallery-meta-top">
					<?php do_action( 'mpp_gallery_meta_top' ); ?>
				</div>

				<div class="mpp-item-entry mpp-gallery-entry">
					<div class="edit_del_area hide_section"><span class="delete_single_album" data-id="<?php echo mpp_get_current_gallery_id() ?>"></span></div>
					<a href="<?php mpp_gallery_permalink(); ?>" <?php mpp_gallery_html_attributes( array( 'class' => 'mpp-item-thumbnail mpp-gallery-cover' ) ); ?>>
						<img src="<?php mpp_gallery_cover_src( 'thumbnail' ); ?>" alt="<?php echo esc_attr( mpp_get_gallery_title() ); ?>"/>
					</a>
				</div>

				<div class="mpp_gal_count">
					<?php
					$gcount = 0;
					$gcount = get_post_meta(mpp_get_current_gallery_id(),'_mpp_media_count',true); 
					if($gcount > 0){
						echo ($gcount > 1) ? $gcount.' Photos' : $gcount.' Photo';
					}else{
						echo '0 Photo';
					}
					?>
				</div>

				<?php do_action( 'mpp_before_gallery_title' ); ?>

				<a href="<?php mpp_gallery_permalink(); ?>" class="mpp-gallery-title"><?php mpp_gallery_title(); ?></a>
				<textarea name="galleryTitle[<?php echo mpp_get_current_gallery_id() ?>]" id="galleryTitle_<?php echo mpp_get_current_gallery_id() ?>" class="hide_section editable_title"><?php mpp_gallery_title() ?></textarea>
				<span id="galleryTitle_error_<?php echo mpp_get_current_gallery_id() ?>" class="err_line"></span>




				<?php do_action( 'mpp_before_gallery_actions' ); ?>
				<?php if(is_user_logged_in()){ ?>
					<!-- View, Delete, Upload actions disabled (on client requirenment) -->
					<!-- <div class="mpp-item-actions mpp-gallery-actions">
						<?php mpp_gallery_action_links(); ?>
					</div> -->
				<?php } ?>

				<?php do_action( 'mpp_before_gallery_type_icon' ); ?>

				<div class="mpp-type-icon"><?php do_action( 'mpp_type_icon', mpp_get_gallery_type(), mpp_get_gallery() ); ?></div>

				<div class="mpp-item-meta mpp-gallery-meta mpp-gallery-meta-bottom">
					<?php do_action( 'mpp_gallery_meta' ); ?>
				</div>

				<?php do_action( 'mpp_after_gallery_entry' ); ?>
			</div>

		<?php endwhile; ?>
		</form>

	</div>
	<div class="gal_pagint">
		<?php mpp_gallery_pagination(); ?>
	</div>
	<?php mpp_reset_gallery_data(); ?>
<?php else : ?>
	<div class="mpp-notice mpp-no-gallery-notice">
		<p> <?php _ex( 'There are no galleries available!', 'No Gallery Message', 'mediapress' ); ?>
	</div>
<?php endif; ?>

<script type="text/javascript">
	jQuery(function($){
		$('#custom_edit_gallery').addClass('edit_gallery');
		$('body').on('click','.edit_gallery',function(){
		    $(this).addClass('done_gallery').removeClass('edit_gallery').text('Done');	   
		    $('.edit_del_area').removeClass('hide_section');
		    $('.mpp-gallery-title').hide().next().removeClass('hide_section');
		});


		$('body').on('click','.done_gallery',function(){
			var _this= $(this);
		     var formData= $('#galler_loop_frm').serialize();
		      formData= formData+'&action=save_album_titles';
		     $('.err_line').removeClass('gallery_title_er'); 
		     $('.gallery_warnings').removeClass('ast-alert-danger ast-alert-success').addClass('ast-alert-info').text('Please wait...');
		     $.ajax({
		     		type:"POST",
		     		 url:rwbObj.ajaxurl,
		     		 data:formData,
		     		 dataType: "json",
		     		 beforeSend:function(){

		     		 },
		     		 success:function(res){
		     		 	console.log(res); 
		     		 	if(res.status=="fail"){
		     		 		for( index in res.message){
		     		 			console.log('Index:'+index+'-message'+res.message[index]);
		     		 			$('#galleryTitle_error_'+index).addClass('gallery_title_er').text(res.message[index]);
		     		 		}
		     		 		  $('.gallery_warnings').removeClass('ast-alert-success ast-alert-info').addClass('ast-alert-danger').text('Please check errors..');		     		 		

		     		 	}else{

		     		 		 $('.err_line').removeClass('gallery_title_er'); 
		     		 		 $('.gallery_warnings').removeClass('ast-alert-danger ast-alert-info').addClass('ast-alert-success').text(res.message);
							_this.addClass('edit_gallery').removeClass('done_gallery').text('Edit');			   
							$('.edit_del_area').addClass('hide_section');
							$('.mpp-gallery-title').show().next().addClass('hide_section');
							setTimeout(function(){
							location.reload();
						},500);
		     		 	}


		     		 }
		     })

		});


$('body').on('click','.delete_single_album',function(){
			var _this= $(this);
		     var formData= $('#galler_loop_frm').serialize();
		      formData= formData+'&action=delete_album_frnt';
		     $('.err_line').removeClass('gallery_title_er'); 
		     $('.gallery_warnings').removeClass('ast-alert-danger ast-alert-success').addClass('ast-alert-info').text('Please wait...');
		     $.ajax({
		     		type:"POST",
		     		 url:rwbObj.ajaxurl,
		     		 data:{
		     		 	action:'delete_album_frnt',
		     		 	'post_id':_this.attr('data-id')
		     		 },
		     		 
		     		 beforeSend:function(){

		     		 },
		     		 success:function(res){

	     		 		$('.err_line').removeClass('gallery_title_er'); 
	     		 		$('.gallery_warnings').removeClass('ast-alert-danger ast-alert-info').addClass('ast-alert-success').text("Selected album deleted successfully!");
						_this.addClass('edit_gallery').removeClass('done_gallery').text('Edit');			   
						$('.edit_del_area').addClass('hide_section');
						$('.mpp-gallery-title').show().next().addClass('hide_section');
						setTimeout(function(){
							location.reload();
						},500);
						
		     		 	


		     		 }
		     });

		});






	});
</script>
