<?php
// Exit if the file is accessed directly over web
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * @package mediapress
 *
 * Single Gallery template
 * If you need specific template for various types, you can copy this file and create new files with name like
 * This comes as the fallback template in our template hierarchy
 * Before loading this file, MediaPress will search for
 * single-{type}-{status}.php
 * single-{type}.php
 * and then fallback to
 * single.php
 * Where type=photo|video|audio|any active type
 *         status =public|private|friendsonly|groupsonly|any registered status
 *
 *
 * Please create your template if you need specific templates for photo, video etc
 *
 *
 *
 * Fallback single Gallery View
 */
?>
<?php
$gallery = mpp_get_current_gallery();
$type    = $gallery->type;

if($gallery->id){
	$gl_media_count = get_post_meta($gallery->id,'_mpp_media_count',true);
	if($gl_media_count && $gl_media_count > 0){
		$gl_count = ($gl_media_count > 1) ? $gl_media_count.' Photos' : $gl_media_count.' Photo';
	}else{
		$gl_count = '';
	}
	$cover_img_id = get_post_meta($gallery->id,'_mpp_cover_id',true);
	$imgUrl = wp_get_attachment_image_src( $cover_img_id, 'full', true);

	/* Edit or Add LINKS */
	$links = '';
	if(is_user_logged_in()){
		if ( mpp_user_can_upload( $gallery->component, $gallery->component_id, $gallery ) ) {
			$links .= sprintf( '<li><a href="%1$s" title ="%2$s"> %3$s</a></li>', mpp_get_gallery_add_media_url( mpp_get_current_gallery() ), _x( 'Add Media', 'Profile context menu rel attribute', 'mediapress' ), _x( 'Upload Photos', 'Profile contextual add media  menu label', 'mediapress' ) );
		}

		if ( mpp_user_can_edit_gallery( mpp_get_current_gallery_id() ) ) {
			$url = mpp_get_gallery_edit_media_url( mpp_get_current_gallery() ); // bulk edit media url.
			$links .= sprintf( '<li><a href="%1$s" title ="%2$s"> %3$s</a></li>', $url, _x( 'Edit Gallery', 'Profile context menu rel attribute', 'mediapress' ), _x( 'Edit', 'Profile contextual edit gallery menu label', 'mediapress' ) );
		}
	}

	?>
	<div class="single_gl_over" style="background:rgba(0, 0, 0, 0) url('<?php echo $imgUrl[0];?>') no-repeat scroll center center "> 
		<div class="single_gl_detail">
			<div class="gl_media_count"><?php echo 	$gl_count ?></div>
			<div class="single_gl_title"><?php echo $gallery->title ?></div>
			<div class="gl_actns">
				<ul>
					<?php echo $links; ?>
				</ul>
			</div>
		</div>
	</div>
	<?php
}
?>
<?php if ( mpp_have_media() ) : ?>

  <div class="gl-media-container">

	<?php if ( mpp_user_can_list_media( mpp_get_current_gallery_id() ) ) : ?>

		<?php do_action( 'mpp_before_single_gallery' ); ?>

		<?php if ( mpp_show_gallery_description() ) : ?>
			<div class="mpp-gallery-description mpp-single-gallery-description mpp-<?php echo $type; ?>-gallery-description mpp-clearfix">
				<?php mpp_gallery_description(); ?>
			</div>
		<?php endif; ?>

		<div class='mpp-g mpp-item-list mpp-media-list mpp-<?php echo $type; ?>-list mpp-single-gallery-media-list mpp-single-gallery-<?php echo $type; ?>-list' data-gallery-id="<?php echo mpp_get_current_gallery_id();?>">
			<?php mpp_load_gallery_view( $gallery ); ?>
			<?php //mpp_get_template_part( 'buddypress/members/gallery/content-single',  $type ); ?>
		</div>

		<?php do_action( 'mpp_after_single_gallery' ); ?>

		<div class="gal_pagint">
			<?php mpp_media_pagination(); ?>
		</div>

		<?php do_action( 'mpp_after_single_gallery_pagination' ); ?>

		<?php mpp_locate_template( array( 'buddypress/members/gallery/activity.php' ), true ); ?>

		<?php do_action( 'mpp_after_single_gallery_activity' ); ?>

	<?php else : ?>
		<div class="mpp-notice mpp-gallery-prohibited">
			<p><?php printf( __( 'The privacy policy does not allow you to view this.', 'mediapress' ) ); ?></p>
		</div>
	<?php endif; ?>

	<?php mpp_reset_media_data(); ?>

<?php else : ?>
	<?php // we should seriously think about adding create gallery button here. ?>

	<?php if ( mpp_user_can_upload( mpp_get_current_component(), mpp_get_current_component_id() ) ) : ?>
		<?php mpp_get_template( 'gallery/manage/add-media.php' ); ?>
	<?php else : ?>
		<div class="mpp-notice mpp-no-gallery-notice">
			<p> <?php _ex( 'Nothing to see here!', 'No media Message', 'mediapress' ); ?></p>
		</div>
	<?php endif; ?>

  </div>

<?php endif; ?>
