<?php
// Exit if the file is accessed directly over web.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * @package mediapress
 *
 * Single Gallery template
 * If you need specific template for various types, you can copy this file and create new files with name like
 * This comes as the fallback template in our template hierarchy
 * Before loading this file, MediaPress will search for
 * single-{type}-{status}.php
 * single-{type}.php
 * and then fallback to
 * single.php
 * Where type=photo|video|audio|any active type
 *         status =public|private|friendsonly|groupsonly|any registered status
 *
 *
 * Please create your template if you need specific templates for photo, video etc
 *
 *
 *
 * Fallback single Gallery View
 */
?>
<?php

$gallery = mpp_get_current_gallery();
$type    = $gallery->type;

global $wpdb;
if($gallery->id){
	$gl_media_count = get_post_meta($gallery->id,'_mpp_media_count',true);
	if($gl_media_count && $gl_media_count > 0){
		$gl_count = ($gl_media_count > 1) ? $gl_media_count.' Photos' : $gl_media_count.' Photo';
	}else{
		$gl_count = '';
	}
	$cover_img_id = get_post_meta($gallery->id,'_mpp_cover_id',true);
	$imgUrl = wp_get_attachment_image_src( $cover_img_id, 'full', true);

	/* Edit or Add LINKS */
	$links = '';
	if(is_user_logged_in()){
		if ( mpp_user_can_upload( $gallery->component, $gallery->component_id, $gallery ) ) {
			$links .= sprintf( '<li><a href="%1$s" title ="%2$s"> %3$s</a></li>', mpp_get_gallery_add_media_url( mpp_get_current_gallery() ), _x( 'Add Media', 'Profile context menu rel attribute', 'mediapress' ), _x( 'Upload Photos', 'Profile contextual add media  menu label', 'mediapress' ) );
		}

		if ( mpp_user_can_edit_gallery( mpp_get_current_gallery_id() ) ) {
			$url = mpp_get_gallery_edit_media_url( mpp_get_current_gallery() ); // bulk edit media url.
			$links .= sprintf( '<li><a href="%1$s" title ="%2$s" class="edit_gallery_single"> %3$s</a></li>', $url, _x( 'Edit Gallery', 'Profile context menu rel attribute', 'mediapress' ), _x( 'Edit', 'Profile contextual edit gallery menu label', 'mediapress' ) );
		}
	}


	?>
	<div class="single_gl_over" style="background:rgba(0, 0, 0, 0) url('<?php echo $imgUrl[0];?>') no-repeat scroll center center "> 
		<div class="single_gl_detail">
			<div class="gl_media_count"><?php echo 	$gl_count ?></div>
			<div class="single_gl_title"><?php echo $gallery->title ?></div>
			<div class="gl_actns">
				<ul>
					<?php echo $links; ?>
				</ul>
			</div>
		</div>
	</div>
	<?php
}
?>

<?php if ( mpp_have_media() ) : ?>

  <div class="gl-media-container">
  	 <div class="gallery_warnings"></div>
 <form id="single_media_gallery_frnt" method="post">	
	<?php if ( mpp_user_can_list_media( mpp_get_current_gallery_id() ) ) : ?>

		<?php do_action( 'mpp_before_single_gallery' ); ?>

		<?php if ( mpp_show_gallery_description() ) : ?>
			<div class="mpp-gallery-description mpp-single-gallery-description mpp-<?php echo $type; ?>-gallery-description mpp-clearfix">
				<?php mpp_gallery_description(); ?>
			</div>
		<?php endif; ?>

		<div class='mpp-g mpp-item-list mpp-media-list mpp-<?php echo $type; ?>-list mpp-single-gallery-media-list mpp-single-gallery-<?php echo $type; ?>-list' data-gallery-id="<?php echo mpp_get_current_gallery_id();?>">
			<?php mpp_load_gallery_view( $gallery ); ?>
			<?php //mpp_get_template_part( 'buddypress/members/gallery/content-single',  $type ); ?>
		</div>

		<?php do_action( 'mpp_after_single_gallery' ); ?>
		
		<div class="gal_pagint">
			<?php mpp_media_pagination(); ?>
		</div>

		</form>

		<?php do_action( 'mpp_after_single_gallery_pagination' ); ?>

		<?php mpp_locate_template( array( 'buddypress/members/gallery/activity.php' ), true ); ?>

		<?php do_action( 'mpp_after_single_gallery_activity' ); ?>

	<?php else : ?>
		<div class="mpp-notice mpp-gallery-prohibited">
			<p><?php printf( __( 'The privacy policy does not allow you to view this.', 'mediapress' ) ); ?></p>
		</div>
	<?php endif; ?>

	<?php mpp_reset_media_data(); ?>
<?php else : ?>
	<?php // we should seriously think about adding create gallery button here. ?>

	<?php if ( mpp_user_can_upload( mpp_get_current_component(), mpp_get_current_component_id() ) ) : ?>
		<?php ///mpp_get_template( 'gallery/manage/add-media.php' ); ?>
		<div class="mpp-notice mpp-no-gallery-notice">
			<p> <?php _ex( 'Nothing to see here!', 'No media Message', 'mediapress' ); ?></p>
		</div>
		
	<?php else : ?>
		<div class="mpp-notice mpp-no-gallery-notice">
			<p> <?php _ex( 'Nothing to see here!', 'No media Message', 'mediapress' ); ?></p>
		</div>
	<?php endif; ?>

  </div>

<?php endif; ?>


<script type="text/javascript">
	jQuery(function($){
		
		$('body').on('click','.edit_gallery_single',function(){
		    $(this).addClass('done_gallery_single').removeClass('edit_gallery_single').text('Done');	   
		    $('.edit_del_area').removeClass('hide_section');
		    $('.editable_title_single').removeClass('hide_section');
		    return false;
		});


    $('body').on('click','.done_gallery_single',function(){
			var _this= $(this);
		     var formData= $('#single_media_gallery_frnt').serialize();
		      formData= formData+'&action=save_album_single_titles';
		     $('.err_line').removeClass('gallery_title_er'); 
		     $('.gallery_warnings').removeClass('ast-alert-danger ast-alert-success').addClass('ast-alert-info').text('Please wait...');
		     $.ajax({
		     		type:"POST",
		     		 url:rwbObj.ajaxurl,
		     		 data:formData,
		     		 dataType: "json",
		     		 beforeSend:function(){

		     		 },
		     		 success:function(res){
		     		 	console.log(res); 
		     		 	if(res.status=="fail"){
		     		 		for( index in res.message){
		     		 			console.log('Index:'+index+'-message'+res.message[index]);
		     		 			$('#galleryTitle_error_'+index).addClass('gallery_title_er').text(res.message[index]);
		     		 		}
		     		 		  $('.gallery_warnings').removeClass('ast-alert-success ast-alert-info').addClass('ast-alert-danger').text('Please check errors..');		     		 		

		     		 	}else{

		     		 		 $('.err_line').removeClass('gallery_title_er'); 
		     		 		 $('.gallery_warnings').removeClass('ast-alert-danger ast-alert-info').addClass('ast-alert-success').text(res.message);
							_this.addClass('edit_gallery_single').removeClass('done_gallery_single').text('Edit');			   
							$('.edit_del_area').addClass('hide_section');
							$('.editable_title_single').addClass('hide_section');
							setTimeout(function(){
							location.reload();
						},500);
		     		 	}


		     		 }
		     });
		     return false;

		});


$('body').on('click','.delete_single_album',function(){
			var _this= $(this);
		     var formData= $('#galler_loop_frm').serialize();
		      formData= formData+'&action=delete_album_single_frnt';
		     $('.err_line').removeClass('gallery_title_er'); 
		     $('.gallery_warnings').removeClass('ast-alert-danger ast-alert-success').addClass('ast-alert-info').text('Please wait...');
		     $.ajax({
		     		type:"POST",
		     		 url:rwbObj.ajaxurl,
		     		 data:{
		     		 	action:'delete_album_single_frnt',
		     		 	'post_id':_this.attr('data-id')
		     		 },
		     		 
		     		 beforeSend:function(){

		     		 },
		     		 success:function(res){

	     		 		$('.err_line').removeClass('gallery_title_er'); 
	     		 		$('.gallery_warnings').removeClass('ast-alert-danger ast-alert-info').addClass('ast-alert-success').text("Selected album deleted successfully!");
						_this.addClass('edit_gallery').removeClass('done_gallery').text('Edit');			   
						$('.edit_del_area').addClass('hide_section');
						$('.mpp-gallery-title').show().next().addClass('hide_section');
						setTimeout(function(){
							location.reload();
						},500);
		     		 }
		     });

		});

	});
</script>