<?php


  /*Create schedule for date multi meta fields*/
  function schedule_meta_box_init() {
		add_meta_box(
			'schedule_meta_box', // $id
			'Schedule event for dates', // $title
			'schedule_meta_box_fnc', // $callback
			'event', // $screen
			'normal', // $context
			'high' // $priority
		);
	}
	add_action( 'add_meta_boxes', 'schedule_meta_box_init' );

function schedule_meta_box_fnc(){
	$html='<div class="custom_meta_group_extend fieldGroup"></div>';
	echo $html;
}

function custom_fields_js_init() {

 wp_enqueue_style( 'schedule_meta_box_fnccss', get_stylesheet_directory_uri() . '/lib/cutsom-fields/custom-fields-init1.css', array(), '1.1');	
   wp_enqueue_script( 'schedule_meta_box_fnc', get_stylesheet_directory_uri() . '/lib/cutsom-fields/custom-fields-init1.js', array( 'jquery' ), '1.0', true );

	$translation_array = array(
				'ajaxurl' => admin_url('admin-ajax.php'),
				'site_url' => site_url(),
				'post_id' => !empty($_GET['post']) ? $_GET['post'] : 0
				);
				wp_localize_script( 'schedule_meta_box_fnc', 'rwbObj', $translation_array );

}

add_action('admin_enqueue_scripts', 'custom_fields_js_init');

add_action('wp_ajax_get_scheduler_fields_val','get_scheduler_fields_val');
add_action('wp_ajax_nopriv_get_scheduler_fields_val','get_scheduler_fields_val');
function get_scheduler_fields_val(){

	 $getFields=  get_post_meta($_GET['post_id'],'schedular',true);
	
	 echo json_encode($getFields);

	die;
}

function save_scheduler_data($post_id){

	if(!empty($_POST['schedular'])){
		$arr = array_values($_POST['schedular']);

		update_post_meta($post_id,'schedular',$arr);
	}

}

add_action('save_post','save_scheduler_data');

 ?>