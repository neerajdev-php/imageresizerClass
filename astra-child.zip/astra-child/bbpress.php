<?php
 
/*
*
* The template for displaying all bbPress pages
*
* This is the template that displays all bbPress pages by default.
* Please note that this is the template of all bbPress pages
* and that other 'pages' on your WordPress site will use a
* different template.
*
* @package WordPress
* @subpackage Theme
*/
 
 
/*
Self explanatory its a functions that gets your header template.
*/
 
get_header(); 

?>
 <?php
/*
Surrounding Classes for the site
 
These are different every theme and help with structure and layout
 
These could be SPANs or DIVs and with entirely different classes.
*/
?> 
<div id="" class="content-area primary"> 
<div id="content" class="site-main" role="main">
<?php
/*
Start the Loop
*/
?>

 
<?php while ( have_posts() ) : the_post(); 

global $bbp;
?> 
 
<?php
/*
This is the start of the page and also the insertion of the post classes.
 
Post classes are very handy to style your forums.
*/

?>
 
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="entry-content clear" itemprop="text">
<div id="buddypress">
  <?php
  do_action( 'bp_before_member_home_content' ); ?>
   <?php if(bbp_is_single_topic()){ ?>
  <div id="item-nav">
    <div class="item-list-tabs no-ajax" id="object-nav" aria-label="<?php esc_attr_e( 'Member primary navigation', 'buddypress' ); ?>" role="navigation">
      <ul class="custom_member_navigation">
        <?php //bp_get_displayed_user_nav(); ?>
        <?php
        /**
         * Fires after the display of member options navigation.
         *
         * @since 1.2.4
         */
        do_action( 'bp_member_options_nav' ); ?>
      </ul>
    </div>
  </div><!-- #item-nav -->

 
  <div id="item-header" role="complementary">
    <?php
       bp_get_template_part( 'members/single/cover-image-header-single-forum' );

    ?>
  
     </div><!-- #item-header -->
   

        <div class="item-list-tabs" id="subnav">
              <div class="custom-container">                
                  <div class="left_message_part_view"><a href="javascript:void(0)" class="prevoius_page"><i class="back_message"></i></a><h2 id="message-subject" class="custom_single_subject"><?php bbp_topic_title(); ?></div>
                  <div class="right_single_view_message_delete_forums">
                  <?php bbp_topic_subscription_link(); ?>
                  <?php bbp_user_favorites_link(); ?>
                  <?php if(is_user_logged_in()){?>
                  <span class="remove_forum_topic"><a href="javascript:void(0)" data-id="<?php echo get_the_ID();?>">Delete</a></span>
                  <?php } ?>
                  </div>              
              </div>
            </div>
              <?php } ?>

    </div>

 
<?php
/*
This is the title wrapped in a header tag
 
and a class to better style the title for your theme
*/
?>
 
<!-- <header class="entry-header">
 
<h1 class="entry-title"><?php the_title(); ?></h1>
 
</header> --> 
 
<?php
/*
This is the content wrapped in a div
 
and class to better style the content
*/
?>
 
<div class="entry-content">
<?php the_content(); ?>
</div>
 
<!-- .entry-content -->
 
 
<?php
/*
End of Page
*/
?>

 
</article>
 
<!-- #post -->
<?php endwhile; // end of the loop. ?>
 
</div>
 
<!-- #content -->
 
</div>
 
<!-- #primary -->
 
 
<?php
/*
This is code to display the sidebar and the footer.
 
Remove the sidebar code to get full-width forums.
 
This would also need CSS to make it actually full width.
*/
?>
 
<?php get_sidebar(); ?>
<?php get_footer(); ?>